<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}
// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

if(isset($_GET['delete_product'])){
  $action_id = $_GET['product_id'];
  
  $sql = "DELETE FROM tbl_product WHERE product_id = :id";
  $sent_po = "product-all.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);
}


if(isset($_POST['add_new_product'])){
    $obj_admin->add_product_or_services_data($_POST);
}

if(isset($_POST['add_new_category'])){
    $obj_admin->add_product_category($_POST);
}

$page_name="Banking";
include("include/header.php");

?> 

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-6 col-md-offset-3">
              <div class="btn-group">
                
                <div class="btn-group">
                  <a href="admin-banking.php" class="btn btn-success btn-menu">Banking Home</a>
                </div>
                <div class="btn-group">
                  <a href="admin-banking-accounts.php" class="btn btn-success btn-menu active">Manage Account</a>
                </div>
                <div class="btn-group">
                  <a href="admin-banking-transactions.php" class="btn btn-success btn-menu">Manage Transaction</a>
                </div>
              </div>
            </div>
          </div>

          <h1 class="text-center">Accounts Information</h1>
          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Account Name</th>
                  <th>Account No.</th>
                  <th>Bank</th>
                  <th>Available Balance</th>
                  <th>Bank Contact</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>

              <?php 

              $sql = "SELECT * FROM tbl_bank_account order by account_id desc";
              $info = $obj_admin->manage_all_info($sql);
              $serial = 1;
              $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="7">No Data found</td></tr>';
                  }
              while ( $row = $info->fetch(PDO::FETCH_ASSOC) ) {
               
              ?>

                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['account_name'];?></td>
                  <td><?php echo $row['account_number'];?></td>
                  <td><?php echo $row['bank_name'];?></td>
                  <td><?php echo $obj_admin->formatMoney($row['available_balance'], true); ?></td>
                  <td><?php echo $row['bank_contact'];?></td> 
                  <td>
                  <a title="View" href="admin-banking-acc-edit.php?account_id=<?php echo $row['account_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>
                </tr>

                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

if(isset($_SESSION['add_bank'])){
  echo '<script>alert("Bank Added successfully");</script>';
  unset($_SESSION['add_bank']);
}

if(isset($_SESSION['update_acc_info'])){
  echo '<script>alert("Info Updated successfully");</script>';
  unset($_SESSION['update_acc_info']);
}

?>

<script type="text/javascript">

$( ".with-dep-both" ).attr("disabled","");
$( ".with-only" ).attr("disabled",""); 

$( "#transaction_type" ).change(function() {
  if($( "#transaction_type" ).val()=="Withdrawal"){
    $( ".with-dep-both" ).removeAttr("disabled","");
    $( ".with-only" ).removeAttr("disabled","");
  }else if($( "#transaction_type" ).val()=="Deposit"){
    $( ".with-dep-both" ).removeAttr("disabled","");
    $( ".with-only" ).attr("disabled",""); 
  }else{
    $( ".with-dep-both" ).attr("disabled","");
    $( ".with-only" ).attr("disabled",""); 
  }
});

</script>