<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}
// see user role
$user_role = $_SESSION['user_role'];
if(isset($_GET['delete_product'])){
  $action_id = $_GET['product_id'];
  
  $sql = "DELETE FROM tbl_product WHERE product_id = :id";
  $sent_po = "product-all.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);
}


if(isset($_POST['add_new_product'])){
    $obj_admin->add_product_or_services_data($_POST);
}

if(isset($_POST['add_new_category'])){
    $obj_admin->add_product_category($_POST);
}

$page_name="Products";
include("include/header.php");

?>

<!-- moddal for product category add -->

  <!-- Modal -->
  <div class="modal fade" id="catModal" role="dialog" style="z-index: 2000">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Category</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                <div class="form-group">
                  <label class="control-label col-sm-5">Category Name</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Product Name" name="category_name" list="expense" class="form-control input-custom" id="default" required>
                  </div>
                </div>
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    <button type="submit" name="add_new_category" class="btn btn-success-custom">Add Category</button>
                  </div>
                  <div class="col-sm-3">
                    <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- moddal for product category add -->

<!--modal for customer add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg add-category-modal">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Product</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form role="form" action="" method="post" autocomplete="off">
                <div class="form-horizontal">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="control-label col-sm-5">Product Name</label>
                        <div class="col-sm-7">
                          <input type="text" placeholder="Enter Product Name" name="product_name" list="expense" class="form-control input-custom" id="default" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Product Code</label>
                        <div class="col-sm-7">
                          <input type="text" placeholder="Enter Product Code" name="product_code" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class='cat-action'>
                          <a class="action-button" style="padding:2px 0px 3px 8px;" data-toggle="modal" data-target="#catModal"><span class='glyphicon glyphicon-plus plus-rotate'></span></a>
                        </div>
                        <label class="control-label col-sm-5">Category</label>
                        <div class="col-sm-7">
                          <select name="product_category" class="form-control input-custom" required>
                          <?php 
                            $sql = "SELECT * FROM tbl_product_category";
                            $info = $obj_admin->manage_all_info($sql);
                            while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                          ?>
                            <option value="<?php echo $row['category_id']; ?>"><?php echo $row['category_name']; ?></option>
                          <?php 
                            }
                          ?>
                          </select>
                          
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Unit Sale Price</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Unit sale Price" name="unit_sale_price" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Whole Sale Quantity</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Whole Sale Quantity" name="unit_per_lot" class="form-control input-custom" required>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="control-label col-sm-5">Whole Sale Price</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Whole Sale Price" name="lot_sale_price" class="form-control input-custom" required>
                        </div>
                      </div>
                      
                      <div class="form-group">
                        <label class="control-label col-sm-5">Product Total Quantity</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Product Total Quantity" name="product_total_quantity" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Total Product Buying Price</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Total Product Buying Price" name="total_product_buying_price" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Incoming Date</label>
                        <div class="col-sm-7">
                          <!-- <input type="text" placeholder="Enter Product Incoming Date" name="product_incoming_date" class="form-control input-custom" required> -->
                          <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                              <input class="form-control input-custom" type="text" name="product_incoming_date" placeholder="Enter Product Incoming Date" required>
                              <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                          </div>

                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Expire Date</label>
                        <div class="col-sm-7">
                          <!-- <input type="text" placeholder="Enter Product Expire Date" name="product_expire_date" class="form-control input-custom" required> -->
                          <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                              <input class="form-control input-custom" type="text" name="product_expire_date" placeholder="Enter Product Expire Date" required>
                              <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                          </div>

                        </div>
                      </div>

                    </div>
                  </div>
                    

                  
                  <div class="form-group">
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-3">
                      <button type="submit" name="add_new_product" class="btn btn-success-custom">Add Product</button>
                    </div>
                    <div class="col-sm-3">
                      <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                    </div>
                  </div>
                </div>
              </form> 
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>


<div class='multi-action'>
  <button class="action-button" data-toggle="modal" data-target="#myModal"><span class='glyphicon glyphicon-plus plus-rotate'></span></button>
</div>

<!--modal for customer add-->



    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="product-available.php">Available</a></li>
            <li><a href="product-stocked.php">Low Stock</a></li>
            <li class="active"><a href="product-all.php">All</a></li>
            <li class=""><a href="product-category.php">Manage Category</a></li>
          </ul>
          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Product Name</th>
                  <th>Product Code</th>
                  <th>Unit sale Price</th>
                  <th>product Quantity</th>
                  <th>All Actions</th>
                </tr>
              </thead>
              <tbody>

              <?php 
                $sql = "SELECT * FROM tbl_product";
                    $info = $obj_admin->manage_all_info($sql);
                    $serial  = 1;
                    $total_expense = 0.00;
                    $num_row = $info->rowCount();
                    if($num_row==0){
                      echo '<tr><td colspan="6">No Data found</td></tr>';
                    }
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['product_name']; ?></td>
                  <td><?php echo $row['product_code']; ?></td>
                  <td><?php echo $row['unit_sale_price']; ?></td>
                  <td><?php echo $row['product_total_quantity']; ?></td>
                  <td>
                  <a title="Add Stock" href="add-stock.php?product_id=<?php echo $row['product_id']; ?>" ><span class="glyphicon glyphicon-plus"></span></a>&nbsp;&nbsp;
                  <a title="Update Product" href="update-products.php?product_id=<?php echo $row['product_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>&nbsp;&nbsp;
                  <a title="View" href="product-details.php?product_id=<?php echo $row['product_id']; ?>"><span class="glyphicon glyphicon-folder-open"></span></a>&nbsp;&nbsp;<a title="Delete" href="?delete_product=delete_product&product_id=<?php echo $row['product_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a></td>
                </tr>
                
              <?php  } ?>


                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");


if(isset($_SESSION['product_updated'])){
  echo '<script>alert("Product Updated successfully");</script>';
  unset($_SESSION['product_updated']);
}

if(isset($_SESSION['add_product'])){
  echo '<script>alert("Product Added successfully");</script>';
  unset($_SESSION['add_product']);
}

?>