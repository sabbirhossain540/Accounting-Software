<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

$supplier_id = $_GET['supplier_id'];
if(isset($_POST['update_supplier'])){
    $obj_admin->update_new_supplier_account($_POST,$supplier_id);
}

$page_name="Suppliers";
include("include/header.php");

$sql = "SELECT * FROM tbl_add_supplier WHERE supplier_id='$supplier_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);

?>

<!--modal for customer add-->

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li class="active"><a href="accounts-supplier-panel.php">Manage Supplier</a></li>
            <li><a href="accounts-supplier-product.php">Manage Supplier Product</a></li>
          </ul>
          <div class="gap"></div>
          
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="well">
                <h3 class="text-center bg-primary" style="padding: 7px;">Edit Supplier</h3><br>


                      <div class="row">
                        <div class="col-md-12">
                          <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                            <div class="form-group">
                              <label class="control-label col-sm-5">Suppliers Name</label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['supplier_name']; ?>" placeholder="Enter supplier Name" name="supplier_name" list="expense" class="form-control input-custom" id="default" required>
                              </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-sm-5">Suppliers Contact</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['supplier_contact']; ?>" placeholder="Enter Supplier Contact" name="supplier_contact" class="form-control input-custom" required>
                              </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-sm-5">Suppliers E-mail</label>
                              <div class="col-sm-7">
                                <input type="email" value="<?php echo $row['supplier_email']; ?>" placeholder="Enter Supplier E-mail" name="supplier_email" class="form-control input-custom">
                              </div>
                            </div>
                            
                            <div class="form-group">
                              <label class="control-label col-sm-5">Suppliers Address</label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['supplier_details']; ?>" placeholder="Enter Supplier Description" name="supplier_details" class="form-control input-custom" >
                              </div>
                            </div>
                            
                            <div class="form-group">
                            </div>
                            <div class="form-group">
                              <div class="col-sm-offset-3 col-sm-3">
                                
                              </div>
                              <div class="col-sm-3">
                                <button type="submit" name="update_supplier" class="btn btn-success-custom">Update Now</button>
                              </div>
                            </div>
                          </form> 
                        </div>
                      </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </div>


<?php

if(isset($_SESSION['add_permanent_customer'])){
  echo '<script>alert("New Customer Added Successfully");</script>';
  unset($_SESSION['add_permanent_customer']);
}

include("include/footer.php");

?>