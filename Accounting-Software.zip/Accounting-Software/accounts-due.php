<?php
require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

$page_name="Accounts";
include("include/header.php");

?>

<script type="text/javascript">

   function changeFunc() {

     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/accounts-due.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="accounts-expense.php">Expense</a></li>
            <li class="active"><a href="accounts-due.php">Transaction</a></li>
            <li><a href="accounts-sales.php">Sales</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-12">
              <form class="form-inline" action="" name="data_search" id="data_search" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="default">Customer Type</label>
                  <select name="category_name" class="form-control" onchange="changeFunc();">
                    <option value="Dealer">Dealer</option>
                    <option value="Irregular">Irregular</option>
                  </select>
                  
                </div>
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                
              </form> 
            </div>
          </div>
          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
            <?php 
              $sql = "SELECT * FROM tbl_customer_due order by due_id desc";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $total_amount = 0.00;
                  $total_paid = 0.00;
                  $due_remain = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_amount += $row['total_amount'];
                    $total_paid += $row['total_paid'];
                    $due_remain += $row['due_remain'];
                  }
            ?>
            <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Amount :
              <?php echo $obj_admin->formatMoney($total_amount, true); ?> BDT &nbsp;&nbsp;&nbsp; Total Paid : <span style="color: #;"><?php echo $obj_admin->formatMoney($total_paid, true); ?></span> BDT &nbsp;&nbsp;&nbsp; Total Due : <?php echo $obj_admin->formatMoney($due_remain, true); ?> BDT </caption>
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Customer Details</th>
                  <th>Product Details</th>
                  <th>Total Amount</th>
                  <th>Total Paid</th>
                  <th>Due Remain</th>
                  <th>Due Paid Date</th>
                  <th>Product Buy Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                  $sql = "SELECT * FROM tbl_customer_due order by due_id desc";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $total_amount = 0.00;
                  $total_paid = 0.00;
                  $due_remain = 0.00;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="9">No Data found</td></tr>';
                  }
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                 ?>

                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  $customer_id = $row['customer_id'];
                  $sql1 = "SELECT * FROM tbl_permanent_customer WHERE customer_id='$customer_id' ";
                  $info1 = $obj_admin->manage_all_info($sql1);
                  $row1 = $info1->fetch(PDO::FETCH_ASSOC);
                  echo $row1['customer_name']. "<br>";
                  echo $row1['customer_contact']. "<br>";
                  ?></td>
                  <td><?php 
                  echo $row['product_name']; ?></td>
                  <td><?php 
                    $total_amount += $row['total_amount'];
                    echo $obj_admin->formatMoney($row['total_amount'], true); ?></td>
                  <td><?php 
                  $total_paid += $row['total_paid'];
                  echo $obj_admin->formatMoney($row['total_paid'], true);  ?></td>
                  <td><?php
                  $due_remain += $row['due_remain'];
                   echo $obj_admin->formatMoney($row['due_remain'], true); ?></td>
                  <td><?php echo $row['due_paid_date']; ?></td>
                  <td><?php echo $row['sale_date']; ?></td>
                  <td><a title="Due Adjust" href="pay-due.php?due_id=<?php echo $row['due_id']; ?>"><span class="glyphicon glyphicon-adjust"></span></a>&nbsp;&nbsp;</td>
                </tr>

                <?php } ?>

                <tr>
                  <td colspan="1"></td>
                  <td colspan="3"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_amount, true);
                  echo "Total Amount: ".$remain_amount;?> BDT</td>
                  <td colspan="3"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_paid, true);
                  echo "Total Paid: ".$remain_amount;?> BDT</td>
                  <td colspan="2"><?php 
                   $remain_amount = $obj_admin->formatMoney($due_remain, true);
                  echo "Total Due: ".$remain_amount;?> BDT</td>
                  
                </tr>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

if(isset($_SESSION['due_fully_paid'])){
  echo '<script>alert("Due Paid Successfully");</script>';
  unset($_SESSION['due_fully_paid']);
}

if(isset($_SESSION['due_partially_paid'])){
  echo '<script>alert("Due Partially Paid Successfully");</script>';
  unset($_SESSION['due_partially_paid']);
}

?>