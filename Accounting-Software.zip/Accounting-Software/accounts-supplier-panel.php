<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

if(isset($_POST['add_supplier'])){
    $obj_admin->add_new_supplier_account($_POST);
}

if(isset($_GET['delete_supplier'])){
  $action_id = $_GET['supplier_id'];
  $sql = "DELETE FROM tbl_add_supplier WHERE supplier_id = :id";
  $sent_po = "accounts-supplier-panel.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);

}

$page_name="Suppliers";
include("include/header.php");

?>

<script type="text/javascript">

   function changeFunc() {

     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/accounts-supplier-panel.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>




<!--modal for supplier add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Supplier</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form class="form-horizontal" role="form" action="" method="post">
                <div class="form-group">
                  <label class="control-label col-sm-5">Supplier Name*</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Customer Name" name="supplier_name" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Contact Number*</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Supplier Contact Number" name="supplier_contact" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Supplier Email</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Supplier Email Address" name="supplier_email" class="form-control input-custom">
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Supplier Address*</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Supplier Supplier" name="supplier_details" class="form-control input-custom">
                  </div>
                </div>
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    <button type="submit" class="btn btn-success-custom" name="add_supplier">Add Supplier</button>
                  </div>
                  <div class="col-sm-3">
                    <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </form> 
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>



<div class='multi-action'>
  <button class="action-button" data-toggle="modal" data-target="#myModal"><span class='glyphicon glyphicon-plus plus-rotate'></span></button>
</div>

<!--modal for customer add-->

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li class="active"><a href="accounts-supplier-panel.php">Manage Supplier</a></li>
            <li><a href="accounts-supplier-product.php">Manage Supplier Product</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-12">
              <form class="form-inline" action="" name="data_search" id="data_search" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="default">Supplier Name</label>
                  <input type="text" class="form-control" name="category_name" onkeypress="changeFunc();" placeholder="e.g. Hashem Uddin" list="languages" id="default">
                  <datalist id="languages">
                    <datalist id="languages">
                    <?php 
                    $sql = "SELECT * FROM tbl_add_supplier order by supplier_id desc";
                    $info = $obj_admin->manage_all_info($sql);
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  ?>
                    <option value="<?php echo $row['supplier_name']; ?>">
                  <?php 
                    }
                  ?>
                  </datalist>
                </div>
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                
              </form> 
            </div>
          </div>
          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Supplier Name</th>
                  <th>Supplier Contact</th>
                  <th>Supplier Email</th>
                  <th>Supplier Address</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                <?php 
                  $sql = "SELECT * FROM tbl_add_supplier";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="6">No Data found</td></tr>';
                  }
                  $total_expense = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['supplier_name'];?></td>
                  <td><?php echo $row['supplier_contact'];?></td>
                  <td><?php echo $row['supplier_email'];?></td>
                  <td><?php echo $row['supplier_details'];?></td>
                  <td>
                  <a title="Update Customer" href="update-supplier.php?supplier_id=<?php echo $row['supplier_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>
                  
                  &nbsp;&nbsp;<a title="Delete" href="?delete_supplier=delete_supplier&supplier_id=<?php echo $row['supplier_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>

                  </td>
                </tr>
                <?php } ?>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

<?php

if(isset($_SESSION['add_supplier'])){
  echo '<script>alert("Supplier Added Successfully");</script>';
  unset($_SESSION['add_supplier']);
}
include("include/footer.php");



if(isset($_SESSION['update_supplier'])){
  echo '<script>alert("Supplier Info Updated Successfully");</script>';
  unset($_SESSION['update_supplier']);
}

?>