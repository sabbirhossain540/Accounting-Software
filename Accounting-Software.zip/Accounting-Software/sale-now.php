<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

$page_name="Sale Now";
include("include/header.php");

if (isset($_POST['process_sale'])) {
  $product_code = $_POST['product_code'];
  $product_quantity = $_POST['product_quantity'];
  $customer_type = $_POST['customer_type'];
  $code_split = explode("/", $product_code);
  $len = count($code_split);
  //echo $len;
  if($len==1){
    echo '<script>alert("wrong Product Code");</script>';
  }else{
    $new_product_code = $code_split[1];
    $sql = "SELECT * FROM tbl_product WHERE product_code='$new_product_code' ";
    $info = $obj_admin->manage_all_info($sql);
    $row_count = $info->rowCount();
    if($row_count==0){
      echo '<script>alert("wrong Product Code");</script>';
    }else{
      $data = $info->fetch(PDO::FETCH_ASSOC);
      $current_stock = $data['product_total_quantity'];
      if($current_stock<$product_quantity){
        echo '<script>alert("Product is out of stock");</script>';
      }else{

        // send data for processing sale
        header('Location: sale-process.php?product_code='.$new_product_code.'&product_quantity='.$product_quantity.'&customer_type='.$customer_type);
      }

    }
    
  }
  
  //echo '<script>alert("wrong Product Code");</script>';
}

?>
  
    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <h2 class="text-center text-success">Sale Product</h2><hr/>
          <div class="row">
            <div class="col-md-7 col-md-offset-2">

              <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                <div class="form-group">
                  <label class="control-label col-sm-5">Product Name/Code</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Your Product name/code" name="product_code" class="form-control input-custom" id="default" list="languages" required>
                    <datalist id="languages">
                    <?php 
                      $sql = "SELECT * FROM tbl_product";
                      $info = $obj_admin->manage_all_info($sql);
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    ?>

                    <option value="<?php echo $row['product_name']; ?>/<?php echo $row['product_code']; ?>">
                    <?php 
                      }
                    ?>
                    
                  </datalist>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Product Quantity</label>
                  <div class="col-sm-7">
                    <input type="number" name="product_quantity" value="1" min="1" placeholder="Enter Number of product" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Customer Type</label>
                  <div class="col-sm-7">
                    <select class="form-control input-custom" name="customer_type">
                      <option value="regular_customer">Irregular Customer</option>
                      <option value="permanent_customer">Dealer</option>
                    </select>
                    
                  </div>
                </div>
                
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    
                  </div>
                  <div class="col-sm-3">
                    
                  </div>
                  <div class="col-sm-3">
                    <button type="submit" class="btn btn-success-custom" name="process_sale">Process Sale</button>
                  </div>
                </div>
              </form> 

            </div>
          </div>
        </div>
      </div>
    </div>

   

<?php

include("include/footer.php");

?>