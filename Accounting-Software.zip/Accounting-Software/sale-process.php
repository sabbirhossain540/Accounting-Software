<?php

require 'authentication.php'; // admin authentication check 



// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}


if(isset($_POST['process_regular_sale'])){
    $obj_admin->add_regular_product_sale($_POST);
}

if(isset($_POST['process_regular_sale_print'])){
    $obj_admin->add_regular_product_sale($_POST);
}

if(isset($_POST['process_permanent_customer_sale'])){
  $customer_id = $_POST['customer_id'];
  $code_split = explode("/", $customer_id);
  $len = count($code_split);
  if($len==1){
    echo '<script>alert("wrong Product Code");</script>';
  }else{
    $new_customer_id = $code_split[1];
    $sql = "SELECT * FROM tbl_permanent_customer WHERE customer_id='$new_customer_id' ";
    $info = $obj_admin->manage_all_info($sql);
    $count_row = $info->rowCount();
    if($count_row==0){
      echo '<script>alert("Customer not found");</script>';
    }else{
      // add sales
      $obj_admin->product_sale_for_permanent_customer($_POST,$new_customer_id);
    }
    
  }
    
}


$page_name="Sale Now";
include("include/header.php");
$product_code = $_GET['product_code'];
$product_quantity = $_GET['product_quantity'];
$customer_type = $_GET['customer_type'];

$sql = "SELECT * FROM tbl_product WHERE product_code='$product_code' ";
$info = $obj_admin->manage_all_info($sql);

$product_details = $info->fetch(PDO::FETCH_ASSOC);

if($customer_type=='regular_customer'){
  // for regular customer
?>


    <div class="row">
      
      <div class="col-md-12">
        <div class="well well-custom">
          <h2 class="text-center text-success">Product Sale Process (Regular Customer)</h2><hr/>
          <div class="row">
          <div class="col-md-7">
            
            <div class="table-responsive" id="content">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Product Code</th>
                  <th>product Quantity</th>
                  <th>Product Price</th>
                </tr>
              </thead>
              <tbody>
                <tr>  
                  <td><?php echo $product_details['product_name']; ?></td>
                  <td><?php echo $product_details['product_code']; ?></td>
                  <td><?php echo $product_quantity; ?></td>
                  <td><?php echo $product_details['unit_sale_price']; ?></td>
                </tr>
                <tr>
                  <td colspan="3">Sub Total</td>
                  <td>
                    <?php $sub_total = $product_quantity * $product_details['unit_sale_price'];
                    echo $sub_total;
                    ?>
                  </td>
                </tr>
                <tr>
                  <td colspan="3">Discount</td>
                  <td>0.0</td>
                </tr>
                <tr>
                  <td colspan="3">Grand Total</td>
                  <td><?php echo $sub_total; ?></td>
                </tr>

                
              </tbody>
            </table>
          </div>

          </div>

            <div class="col-md-5">

              <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                
                
                <div class="form-group">
                  <h4 class="text-center">Irregular Customer</h4><br>
                  <label class="control-label col-sm-5">Customer Name</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Customer Name" name="customer_name" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Customer Contact</label>
                  <div class="col-sm-7">
                    <input type="number" name="customer_contact" placeholder="Customer Contact" class="form-control input-custom" required>
                  </div>
                </div>                       
            </div>
            <div class="col-md-7">
               <div class="form-group">
                  <label class="control-label col-sm-5"></label>
                  <div class="col-sm-7">
                    <input type="hidden" placeholder="0.0" min="0" name="product_discount" class="form-control input-custom">
                  </div>
                </div>
                <div class="form-group">     
                  <div class="col-sm-7">
                    <input type="hidden" name="product_total" min="0" placeholder="0.0" class="form-control input-custom" required>
                    <input type="hidden" name="product_name" value="<?php echo $product_details['product_name']; ?>">
                    <input type="hidden" name="product_code" value="<?php echo $product_details['product_code']; ?>">
                    <input type="hidden" name="product_price" value="<?php echo $product_details['unit_sale_price']; ?>">
                    <input type="hidden" name="product_quantity" value="<?php echo $product_quantity; ?>">
                    <input type="hidden" name="product_total_quantity" value="<?php echo $product_details['product_total_quantity']; ?>">
                  </div>
                </div>
                
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    
                  </div>
                  <div class="col-sm-3">
                   <button type="submit" name="process_regular_sale_print" class="btn btn-success-custom">Sale & Print</button>
                  </div>
                  <div class="col-sm-3">
                    <a href="sale-now.php" class="btn btn-danger-custom">
                    Cancel</a>
                  </div>
                </div>

                </form> 

            </div>
          </div>
        </div>
      </div>
    </div>
<?php

}else if($customer_type=='permanent_customer'){
  // for permanent customer
?>
    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <h2 class="text-center text-success">Product Sale Process (Permanent Customer)</h2><hr/>
          <div class="row">
          <div class="col-md-7">
            
            <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Product Code</th>
                  <th>product Quantity</th>
                  <th>Product Price</th>
                </tr>
              </thead>
              <tbody>
                <tr>    
                  <td><?php echo $product_details['product_name']; ?></td>
                  <td><?php echo $product_details['product_code']; ?></td>
                  <td><?php echo $product_quantity; ?></td>
                  <td><?php echo $product_details['unit_sale_price']; ?></td>
                </tr>
                <tr>
                  <td colspan="3">Sub Total</td>
                  <td>
                    <?php $sub_total = $product_quantity * $product_details['unit_sale_price'];
                    echo $sub_total;
                    ?>
                  </td>
                </tr>
                <tr>
                  <td colspan="3">Discount</td>
                  <td>0.0</td>
                </tr>
                <tr>
                  <td colspan="3">Grand Total</td>
                  <td><?php echo $sub_total; ?></td>
                </tr>
                
              </tbody>
            </table>
          </div>

          </div>

            <div class="col-md-5">

              <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">             
                
                <div class="form-group">
                  <h4 class="text-center">Dealer</h4><br>
                  <label class="control-label col-sm-5">Choose Dealer</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Search Customer" name="customer_id" class="form-control input-custom" id="default" list="languages" required>
                    <datalist id="languages">
                    <?php 
                      $sql = "SELECT * FROM tbl_permanent_customer";
                      $info = $obj_admin->manage_all_info($sql);
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    ?>

                    <option value="<?php echo $row['customer_name']. "-".$row['customer_contact']; ?>/<?php echo $row['customer_id']; ?>">
                    <?php 
                      }
                    ?>
                    
                  </datalist>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Due Amount</label>
                  <div class="col-sm-7">
                    <input type="number" name="due_amount" min="0" placeholder="0.0" class="form-control input-custom">
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label col-sm-5">Due pay Date</label>
                  <div class="col-sm-7">
                    <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control input-custom" type="text" name="due_paid_date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                    </div>
                  </div>
                </div>
                
            </div>

            <div class="col-md-7">
               <div class="form-group">
                  <label class="control-label col-sm-5">Discount Amount</label>
                  <div class="col-sm-7">
                    <input type="number" placeholder="0.0" min="0" name="product_discount" class="form-control input-custom">
                  </div>
                </div>
                <div class="form-group">
                  
                  <div class="col-sm-7">
                    <input type="hidden" name="product_total" min="0" placeholder="0.0" class="form-control input-custom" required>
                    <input type="hidden" name="product_name" value="<?php echo $product_details['product_name']; ?>">
                    <input type="hidden" name="product_code" value="<?php echo $product_details['product_code']; ?>">
                    <input type="hidden" name="product_price" value="<?php echo $product_details['unit_sale_price']; ?>">
                    <input type="hidden" name="product_quantity" value="<?php echo $product_quantity; ?>">
                    <input type="hidden" name="product_total_quantity" value="<?php echo $product_details['product_total_quantity']; ?>">
                  </div>
                </div>
                
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    
                  </div>
                  <div class="col-sm-3">
                     <button type="submit" name="process_permanent_customer_sale" class="btn btn-success-custom">Sale & Print</button> </a>
                  </div>
                  <div class="col-sm-3">
                    <a href="sale-now.php" class="btn btn-danger-custom">
                    Cancel</a>
                  </div>
                </div>

                </form> 

            </div>
          </div>
        </div>
      </div>
    </div>
<?php
}

?>
  



    

<?php

include("include/footer.php");

?>