-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2017 at 06:03 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_accounting_software`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_add_supplier`
--

CREATE TABLE `tbl_add_supplier` (
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(200) NOT NULL,
  `supplier_contact` text NOT NULL,
  `supplier_email` text NOT NULL,
  `supplier_details` text NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_add_supplier`
--

INSERT INTO `tbl_add_supplier` (`supplier_id`, `supplier_name`, `supplier_contact`, `supplier_email`, `supplier_details`, `add_date`) VALUES
(1, 'new supplier', '01675350135', 'supplier@yahoo.com', 'mirpur, dhaka', '2017-11-06 05:51:35'),
(2, 'Mr. Karim', '1211', 'karim@live.com', 'dhaka, Bangladesh', '2017-11-06 05:58:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` text NOT NULL,
  `admin_contact` text NOT NULL,
  `admin_password` text NOT NULL,
  `user_role` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_contact`, `admin_password`, `user_role`) VALUES
(2, 'Software Admin', 'admin@yahoo.com', '01675350135', '1dafa20ca26fa3d915cdc0b367489a27', 1),
(3, 'Sales Man', 'sales1@yahoo.com', '01675350135', '827ccb0eea8a706c4c34a16891f84e7b', 2),
(4, 'Mr. Sales Person', 'sale@yahoo.com', '01678653452', '827ccb0eea8a706c4c34a16891f84e7b', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_balance_withdraw`
--

CREATE TABLE `tbl_balance_withdraw` (
  `withdraw_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `withdraw_amount` decimal(10,2) NOT NULL,
  `withdraw_purpose` text NOT NULL,
  `withdraw_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank_account`
--

CREATE TABLE `tbl_bank_account` (
  `account_id` int(11) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_number` varchar(150) NOT NULL,
  `available_balance` decimal(10,2) NOT NULL,
  `initial_balance` decimal(10,2) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `bank_contact` text NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank_deposit`
--

CREATE TABLE `tbl_bank_deposit` (
  `transaction_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `deposit_amount` decimal(10,2) NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_due`
--

CREATE TABLE `tbl_customer_due` (
  `due_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_name` text NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `total_paid` decimal(10,2) NOT NULL,
  `due_remain` decimal(10,2) NOT NULL,
  `due_paid_date` text NOT NULL,
  `sale_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_expense_source`
--

CREATE TABLE `tbl_expense_source` (
  `expense_id` int(11) NOT NULL,
  `expense_source` varchar(250) NOT NULL,
  `expense_amount` decimal(10,2) NOT NULL,
  `responsible_person` varchar(200) NOT NULL,
  `person_designation` varchar(200) NOT NULL,
  `person_contact` text NOT NULL,
  `expense_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_income_source`
--

CREATE TABLE `tbl_income_source` (
  `income_id` int(11) NOT NULL,
  `income_source` text NOT NULL,
  `income_description` text NOT NULL,
  `income_amount` decimal(10,2) NOT NULL,
  `responsible_person` varchar(300) NOT NULL,
  `person_designation` text NOT NULL,
  `product_sale_date` text NOT NULL,
  `income_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_irregular_transaction`
--

CREATE TABLE `tbl_irregular_transaction` (
  `transaction_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_contact` text NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `due_amount` decimal(10,2) NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_irregular_transaction`
--

INSERT INTO `tbl_irregular_transaction` (`transaction_id`, `customer_name`, `customer_contact`, `product_name`, `product_quantity`, `total_amount`, `due_amount`, `transaction_date`) VALUES
(1, 'Estiak Ahmed', '01675350135', 'Coconut Oil', 4, '880.00', '0.00', '2017-11-09 12:26:49'),
(2, 'afsdfs', '14324', 'Coconut Oil', 1, '220.00', '0.00', '2017-11-11 07:24:34'),
(3, 'dfsagh', '45869', 'Coconut Oil', 1, '220.00', '0.00', '2017-12-04 07:24:48'),
(4, 'rwe', '324134', 'Coconut Oil', 1, '220.00', '0.00', '2017-12-05 06:32:50'),
(5, 'fsdfsa', '2133', 'Coconut Oil', 1, '220.00', '0.00', '2017-12-05 06:36:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_permanent_customer`
--

CREATE TABLE `tbl_permanent_customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `customer_email` varchar(200) NOT NULL,
  `customer_contact` text NOT NULL,
  `customer_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_permanent_customer`
--

INSERT INTO `tbl_permanent_customer` (`customer_id`, `customer_name`, `customer_email`, `customer_contact`, `customer_description`) VALUES
(1, 'Mr. Shahadat Hossain', 'shahadat01@live.com', '01675350156', 'Mirpur, Dhaka, Bangladesh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `product_category` text NOT NULL,
  `unit_sale_price` decimal(10,2) NOT NULL,
  `unit_per_lot` int(11) NOT NULL,
  `lot_sale_price` decimal(10,2) NOT NULL,
  `product_total_quantity` int(11) NOT NULL,
  `total_product_buying_price` decimal(10,2) NOT NULL,
  `product_incoming_date` text NOT NULL,
  `product_expire_date` text NOT NULL,
  `initial_product_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_name`, `product_code`, `product_category`, `unit_sale_price`, `unit_per_lot`, `lot_sale_price`, `product_total_quantity`, `total_product_buying_price`, `product_incoming_date`, `product_expire_date`, `initial_product_quantity`) VALUES
(1, 'Coconut Oil', 'product-001', '1', '220.00', 3, '212.00', 12, '3000.00', '2017-11-08', '2017-11-24', 15);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_category`
--

CREATE TABLE `tbl_product_category` (
  `category_id` int(11) NOT NULL,
  `category_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product_category`
--

INSERT INTO `tbl_product_category` (`category_id`, `category_name`) VALUES
(1, 'Cosmetics'),
(2, 'Garments');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_regular_customer`
--

CREATE TABLE `tbl_regular_customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `customer_contact` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_regular_customer`
--

INSERT INTO `tbl_regular_customer` (`customer_id`, `customer_name`, `customer_contact`) VALUES
(1, 'Estiak Ahmed', '01675350135'),
(2, 'afsdfs', '14324'),
(3, 'dfsagh', '45869'),
(4, 'rwe', '324134'),
(5, 'fsdfsa', '2133');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sales_product`
--

CREATE TABLE `tbl_sales_product` (
  `sale_id` int(11) NOT NULL,
  `product_name` varchar(300) NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `total_sale_price` decimal(10,2) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `customer_type` text NOT NULL,
  `due_trans_id` int(11) NOT NULL,
  `product_sale_date` text NOT NULL,
  `sale_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sales_product`
--

INSERT INTO `tbl_sales_product` (`sale_id`, `product_name`, `product_code`, `total_sale_price`, `product_quantity`, `customer_type`, `due_trans_id`, `product_sale_date`, `sale_date`) VALUES
(1, 'Coconut Oil', 'product-001', '880.00', 4, 'Irregular', 1, '2017-11-09', '2017-11-09 12:26:49'),
(2, 'Coconut Oil', 'product-001', '220.00', 1, 'Irregular', 2, '2017-11-11', '2017-11-11 07:24:35'),
(3, 'Coconut Oil', 'product-001', '220.00', 1, 'Irregular', 3, '2017-12-04', '2017-12-04 07:24:48'),
(4, 'Coconut Oil', 'product-001', '220.00', 1, 'Irregular', 4, '2017-12-05', '2017-12-05 06:32:50'),
(5, 'Coconut Oil', 'product-001', '220.00', 1, 'Irregular', 5, '2017-12-05', '2017-12-05 06:36:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier_product`
--

CREATE TABLE `tbl_supplier_product` (
  `product_id` int(11) NOT NULL,
  `supplier_id` varchar(100) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `original_price` decimal(10,2) NOT NULL,
  `product_discount` decimal(10,2) NOT NULL,
  `due_amount` decimal(10,2) NOT NULL,
  `short_description` text NOT NULL,
  `sale_product_id` int(11) NOT NULL,
  `product_incoming_date` text NOT NULL,
  `product_expire_date` text NOT NULL,
  `supply_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_add_supplier`
--
ALTER TABLE `tbl_add_supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admin_email` (`admin_email`(200));

--
-- Indexes for table `tbl_balance_withdraw`
--
ALTER TABLE `tbl_balance_withdraw`
  ADD PRIMARY KEY (`withdraw_id`);

--
-- Indexes for table `tbl_bank_account`
--
ALTER TABLE `tbl_bank_account`
  ADD PRIMARY KEY (`account_id`),
  ADD UNIQUE KEY `account_number` (`account_number`,`bank_name`);

--
-- Indexes for table `tbl_bank_deposit`
--
ALTER TABLE `tbl_bank_deposit`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `tbl_customer_due`
--
ALTER TABLE `tbl_customer_due`
  ADD PRIMARY KEY (`due_id`);

--
-- Indexes for table `tbl_expense_source`
--
ALTER TABLE `tbl_expense_source`
  ADD PRIMARY KEY (`expense_id`);

--
-- Indexes for table `tbl_income_source`
--
ALTER TABLE `tbl_income_source`
  ADD PRIMARY KEY (`income_id`);

--
-- Indexes for table `tbl_irregular_transaction`
--
ALTER TABLE `tbl_irregular_transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `tbl_permanent_customer`
--
ALTER TABLE `tbl_permanent_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_code` (`product_code`);

--
-- Indexes for table `tbl_product_category`
--
ALTER TABLE `tbl_product_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_regular_customer`
--
ALTER TABLE `tbl_regular_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_sales_product`
--
ALTER TABLE `tbl_sales_product`
  ADD PRIMARY KEY (`sale_id`);

--
-- Indexes for table `tbl_supplier_product`
--
ALTER TABLE `tbl_supplier_product`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_add_supplier`
--
ALTER TABLE `tbl_add_supplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_balance_withdraw`
--
ALTER TABLE `tbl_balance_withdraw`
  MODIFY `withdraw_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_bank_account`
--
ALTER TABLE `tbl_bank_account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_bank_deposit`
--
ALTER TABLE `tbl_bank_deposit`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_customer_due`
--
ALTER TABLE `tbl_customer_due`
  MODIFY `due_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_expense_source`
--
ALTER TABLE `tbl_expense_source`
  MODIFY `expense_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_income_source`
--
ALTER TABLE `tbl_income_source`
  MODIFY `income_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_irregular_transaction`
--
ALTER TABLE `tbl_irregular_transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_permanent_customer`
--
ALTER TABLE `tbl_permanent_customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_product_category`
--
ALTER TABLE `tbl_product_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_regular_customer`
--
ALTER TABLE `tbl_regular_customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_sales_product`
--
ALTER TABLE `tbl_sales_product`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_supplier_product`
--
ALTER TABLE `tbl_supplier_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
