<?php

class Admin_Class
{	

/* -------------------------set_database_connection_using_PDO---------------------- */

	public function __construct()
	{ 
        $host_name='localhost';
		$user_name='root';
		$password='';
		$db_name='db_accounting_software';

		try{
			$connection=new PDO("mysql:host={$host_name}; dbname={$db_name}", $user_name,  $password);
			$this->db = $connection; // connection established
		} catch (PDOException $message ) {
			echo $message->getMessage();
		}
	}

/* ---------------------- test_form_input_data ----------------------------------- */
	
	public function test_form_input_data($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
	return $data;
	}

// showing data into money format
	public function formatMoney($number, $fractional=false) {
		
	  if ($fractional) {
	    $number = sprintf('%.2f', $number);
	  }
	  while (true) {
	    $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
	    if ($replaced != $number) {
	      $number = $replaced;
	    } else {
	      break;
	    }
	  }
	  return $number;
	}
 
 
/* ---------------------- Admin Login Check ----------------------------------- */

    public function admin_login_check($data) {
        
        $upass = $this->test_form_input_data(md5($data['admin_password']));
		$uemail = $this->test_form_input_data($data['admin_email']);

        try
       {
          $stmt = $this->db->prepare("SELECT * FROM tbl_admin WHERE admin_email=:uname AND admin_password=:upass LIMIT 1");
          $stmt->execute(array(':uname'=>$uemail, ':upass'=>$upass));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
                session_start();
                $_SESSION['admin_id'] = $userRow['admin_id'];
                $_SESSION['admin_name'] = $userRow['admin_name'];
                $_SESSION['admin_contact'] = $userRow['admin_contact'];
                $_SESSION['security_key'] = 'rewsgf@%^&*nmghjjkh';
                $_SESSION['user_role'] = $userRow['user_role'];
                
                header('Location: dashboard.php');
             
          }else{
			  $message = 'Invalid user name or Password';
              return $message;
		  }
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }	
		
    }


/* -------------------- Admin Logout ----------------------------------- */

    public function admin_logout() {
        
        session_start();
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_name']);
        unset($_SESSION['security_key']);
        unset($_SESSION['user_role']);
        header('Location: index.php');
    }

/*----------- add_new_user--------------*/

	public function add_new_user($data){
		$admin_name  = $this->test_form_input_data($data['admin_name']);
		$admin_email = $this->test_form_input_data($data['admin_email']);
		$admin_contact = $this->test_form_input_data($data['admin_contact']);
		$admin_password = $this->test_form_input_data(md5($data['admin_password']));
		$user_role = 2;
		try{
			$add_user = $this->db->prepare("INSERT INTO tbl_admin (admin_name, admin_email, admin_contact, admin_password, user_role) VALUES (:x, :y, :z, :a, :b) ");

			$add_user->bindparam(':x', $admin_name);
			$add_user->bindparam(':y', $admin_email);
			$add_user->bindparam(':z', $admin_contact);
			$add_user->bindparam(':a', $admin_password);
			$add_user->bindparam(':b', $user_role);

			$add_user->execute();

			$_SESSION['add_new_user'] = 'add_new_user';

			//header('Location: product-all.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ---------update_user_data----------*/

	public function update_user_data($data, $id){
		$admin_name  = $this->test_form_input_data($data['admin_name']);
		$admin_email = $this->test_form_input_data($data['admin_email']);
		$admin_contact = $this->test_form_input_data($data['admin_contact']);
		try{
			$update_user = $this->db->prepare("UPDATE tbl_admin SET admin_name = :x, admin_email = :y, admin_contact = :z WHERE admin_id = :id ");

			$update_user->bindparam(':x', $admin_name);
			$update_user->bindparam(':y', $admin_email);
			$update_user->bindparam(':z', $admin_contact);
			$update_user->bindparam(':id', $id);
			
			$update_user->execute();

			$_SESSION['update_user'] = 'update_user';

			header('Location: admin-manage-salesman.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ------------update_admin_data-------------------- */

	public function update_admin_data($data, $id){
		$admin_name  = $this->test_form_input_data($data['admin_name']);
		$admin_email = $this->test_form_input_data($data['admin_email']);
		$admin_contact = $this->test_form_input_data($data['admin_contact']);
		try{
			$update_user = $this->db->prepare("UPDATE tbl_admin SET admin_name = :x, admin_email = :y, admin_contact = :z WHERE admin_id = :id ");

			$update_user->bindparam(':x', $admin_name);
			$update_user->bindparam(':y', $admin_email);
			$update_user->bindparam(':z', $admin_contact);
			$update_user->bindparam(':id', $id);
			
			$update_user->execute();

			$_SESSION['update_user'] = 'update_user';

			header('Location: manage-admin.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ------update_user_password------------------*/
	
	public function update_user_password($data, $id){
		$admin_password  = $this->test_form_input_data(md5($data['admin_password']));
		
		try{
			$update_user_password = $this->db->prepare("UPDATE tbl_admin SET admin_password = :x WHERE admin_id = :id ");

			$update_user_password->bindparam(':x', $admin_password);
			$update_user_password->bindparam(':id', $id);
			
			$update_user_password->execute();

			$_SESSION['update_user_pass'] = 'update_user_pass';

			header('Location: admin-manage-salesman.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}




/* -------------admin_password_change------------*/

	public function admin_password_change($data, $id){
		$admin_old_password  = $this->test_form_input_data(md5($data['admin_old_password']));
		$admin_new_password  = $this->test_form_input_data(md5($data['admin_new_password']));
		$admin_cnew_password  = $this->test_form_input_data(md5($data['admin_cnew_password']));
		$admin_raw_password = $this->test_form_input_data($data['admin_new_password']);
		
		try{

			// old password matching check 

			$sql = "SELECT * FROM tbl_admin WHERE admin_id = '$id' AND admin_password = '$admin_old_password' ";

			$query_result = $this->manage_all_info($sql);

			$total_row = $query_result->rowCount();
			$all_error = '';
			if($total_row == 0){
				$all_error = "Invalid old password";
			}
			

			if($admin_new_password != $admin_cnew_password ){
				$all_error .= '<br>'."New and Confirm New password do not match";
			}

			$password_length = strlen($admin_raw_password);

			if($password_length < 8){
				$all_error .= '<br>'."Password length must be more then 8 character";
			}

			if(empty($all_error)){
				$update_admin_password = $this->db->prepare("UPDATE tbl_admin SET admin_password = :x WHERE admin_id = :id ");

				$update_admin_password->bindparam(':x', $admin_new_password);
				$update_admin_password->bindparam(':id', $id);
				
				$update_admin_password->execute();

				$_SESSION['update_user_pass'] = 'update_user_pass';

				header('Location: admin-manage-salesman.php');

			}else{
				return $all_error;
			}

			
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* -------------------add_product_or_services_data----------- */

	public function add_product_or_services_data($data){
		// data insert   
		$product_name  = $this->test_form_input_data($data['product_name']);
		$product_code = $this->test_form_input_data($data['product_code']);
		$product_category = $this->test_form_input_data($data['product_category']);
		$unit_sale_price = $this->test_form_input_data($data['unit_sale_price']);
		$unit_per_lot  = $this->test_form_input_data($data['unit_per_lot']);
		$lot_sale_price = $this->test_form_input_data($data['lot_sale_price']);
		$product_total_quantity = $this->test_form_input_data($data['product_total_quantity']);
		$total_product_buying_price = $this->test_form_input_data($data['total_product_buying_price']);
		$product_incoming_date = $this->test_form_input_data($data['product_incoming_date']);
		$product_expire_date = $this->test_form_input_data($data['product_expire_date']);

		try{
			$add_product = $this->db->prepare("INSERT INTO tbl_product (product_name, product_code, product_category, unit_sale_price, unit_per_lot, lot_sale_price, product_total_quantity, total_product_buying_price, product_incoming_date, product_expire_date, initial_product_quantity) VALUES (:x, :y, :z, :a, :b, :c, :d, :e, :f, :g, :h) ");

			$add_product->bindparam(':x', $product_name);
			$add_product->bindparam(':y', $product_code);
			$add_product->bindparam(':z', $product_category);
			$add_product->bindparam(':a', $unit_sale_price);
			$add_product->bindparam(':b', $unit_per_lot);
			$add_product->bindparam(':c', $lot_sale_price);
			$add_product->bindparam(':d', $product_total_quantity);
			$add_product->bindparam(':e', $total_product_buying_price);
			$add_product->bindparam(':f', $product_incoming_date);
			$add_product->bindparam(':g', $product_expire_date);
			$add_product->bindparam(':h', $product_total_quantity);

			$add_product->execute();

			$_SESSION['add_product'] = 'add_product';

			header('Location: product-all.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ---------------add_product_category----------------- */

	public function add_product_category($data){
		$category_name  = $this->test_form_input_data($data['category_name']);

		try{
			$add_category = $this->db->prepare("INSERT INTO tbl_product_category (category_name) VALUES (:x) ");

			$add_category->bindparam(':x', $category_name);

			$add_category->execute();

			//$_SESSION['add_product'] = 'add_product';

			//header('Location: product-all.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ---------------update_product_or_services_data--------- */

	public function update_product_or_services_data($data,$product_id){
		// data insert   
		$product_name  = $this->test_form_input_data($data['product_name']);
		//$product_code = $this->test_form_input_data($data['product_code']);
		$product_category = $this->test_form_input_data($data['product_category']);
		$unit_sale_price = $this->test_form_input_data($data['unit_sale_price']);
		$unit_per_lot  = $this->test_form_input_data($data['unit_per_lot']);
		$lot_sale_price = $this->test_form_input_data($data['lot_sale_price']);
		$product_total_quantity = $this->test_form_input_data($data['product_total_quantity']);
		$total_product_buying_price = $this->test_form_input_data($data['total_product_buying_price']);
		$product_incoming_date = $this->test_form_input_data($data['product_incoming_date']);
		$product_expire_date = $this->test_form_input_data($data['product_expire_date']);

		try{
			$update_product = $this->db->prepare("UPDATE tbl_product SET product_name= :x, product_category = :y, unit_sale_price = :z, unit_per_lot = :a, lot_sale_price = :b, product_total_quantity = :c, total_product_buying_price = :d, product_incoming_date = :e, product_expire_date = :f, initial_product_quantity = :g  WHERE  product_id = :id ");

			$update_product->bindparam(':x', $product_name);
			$update_product->bindparam(':y', $product_category);
			$update_product->bindparam(':z', $unit_sale_price);
			$update_product->bindparam(':a', $unit_per_lot);
			$update_product->bindparam(':b', $lot_sale_price);
			$update_product->bindparam(':c', $product_total_quantity);
			$update_product->bindparam(':d', $total_product_buying_price);
			$update_product->bindparam(':e', $product_incoming_date);
			$update_product->bindparam(':f', $product_expire_date);
			$update_product->bindparam(':g', $product_total_quantity);
			$update_product->bindparam(':id', $product_id);

			$update_product->execute();
			$_SESSION['product_updated'] = "product_updated";

			header('Location: product-all.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* -----------------update_product_current_stock------------*/

	public function update_product_current_stock($data, $product_id){
		$stock_amount  = $this->test_form_input_data($data['product_stock_number']);
		$sql = "SELECT * FROM tbl_product WHERE product_id='$product_id' ";
		$info = $this->manage_all_info($sql);
		$row = $info->fetch(PDO::FETCH_ASSOC);
		$product_previous_quantity = $row['product_total_quantity'];

		$product_new_quantity = $stock_amount + $product_previous_quantity;

		try{

			$update_stock = $this->db->prepare("UPDATE tbl_product SET product_total_quantity = :x, initial_product_quantity = :y WHERE  product_id = :id");

			$update_stock->bindparam(':x', $product_new_quantity);
			$update_stock->bindparam(':y', $product_new_quantity);
			$update_stock->bindparam(':id', $product_id);

			$update_stock->execute();
			$_SESSION['quantity_added'] = "quantity_added";
			
			header('Location: product-stocked.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ----------------update_or_delete_due_payment--------------- */

	public function update_or_delete_due_payment($data, $due_id){

		$paying_amount  = $this->test_form_input_data($data['paying_amount']);
		$next_payment_date  = $this->test_form_input_data($data['next_payment_date']);

		try{

			$sql = "SELECT * FROM tbl_customer_due WHERE due_id='$due_id' ";
			$info = $this->manage_all_info($sql);
			$row = $info->fetch(PDO::FETCH_ASSOC);

			$due_remain = $row['due_remain'];
			$total_paid = $row['total_paid'];
			$paid_amount = $this->formatMoney($paying_amount, true);
			$new_due_amount = $due_remain - $paid_amount;
			$new_total_paid = $total_paid + $paying_amount;

			if ($due_remain == $paid_amount) {
				
				$update_due = $this->db->prepare("UPDATE tbl_customer_due SET total_paid = :x, due_remain = :y, due_paid_date = :z WHERE  due_id = :id");

				$update_due->bindparam(':x', $new_total_paid);
				$update_due->bindparam(':y', $new_due_amount);
				$update_due->bindparam(':z', $next_payment_date);
				$update_due->bindparam(':id', $due_id);

				$update_due->execute();
				$_SESSION['due_fully_paid'] = "due_fully_paid";
				header('Location: accounts-due.php');

			}else if($due_remain >= $paid_amount){
				//echo "due is not fully clear";

				$update_due = $this->db->prepare("UPDATE tbl_customer_due SET total_paid = :x, due_remain = :y, due_paid_date = :z WHERE  due_id = :id");

				$update_due->bindparam(':x', $new_total_paid);
				$update_due->bindparam(':y', $new_due_amount);
				$update_due->bindparam(':z', $next_payment_date);
				$update_due->bindparam(':id', $due_id);

				$update_due->execute();
				$_SESSION['due_partially_paid'] = "due_partially_paid";
				header('Location: accounts-due.php');

			}else{
				echo '<script>alert("try again!! paid amout is bigger than due amount");</script>';
			}

		}catch (PDOException $e) {
			echo $e->getMessage();
		}

	}


/* ----------------dealer_due_amount_paid------------------- */

	public function dealer_due_amount_paid($data, $due_id){

		$paying_amount  = $this->test_form_input_data($data['paying_amount']);
		$next_payment_date  = $this->test_form_input_data($data['next_payment_date']);

		try{

			$sql = "SELECT * FROM tbl_customer_due WHERE due_id='$due_id' ";
			$info = $this->manage_all_info($sql);
			$row = $info->fetch(PDO::FETCH_ASSOC);

			$due_remain = $row['due_remain'];
			$total_paid = $row['total_paid'];
			$paid_amount = $this->formatMoney($paying_amount, true);
			$new_due_amount = $due_remain - $paid_amount;
			$new_total_paid = $total_paid + $paying_amount;

			if ($due_remain == $paid_amount) {
				
				$update_due = $this->db->prepare("UPDATE tbl_customer_due SET total_paid = :x, due_remain = :y, due_paid_date = :z WHERE  due_id = :id");

				$update_due->bindparam(':x', $new_total_paid);
				$update_due->bindparam(':y', $new_due_amount);
				$update_due->bindparam(':z', $next_payment_date);
				$update_due->bindparam(':id', $due_id);

				$update_due->execute();
				$_SESSION['due_fully_paid'] = "due_fully_paid";
				header('Location: view-single-dealer.php?customer_id='.$row['customer_id']);

			}else if($due_remain >= $paid_amount){
				//echo "due is not fully clear";

				$update_due = $this->db->prepare("UPDATE tbl_customer_due SET total_paid = :x, due_remain = :y, due_paid_date = :z WHERE  due_id = :id");

				$update_due->bindparam(':x', $new_total_paid);
				$update_due->bindparam(':y', $new_due_amount);
				$update_due->bindparam(':z', $next_payment_date);
				$update_due->bindparam(':id', $due_id);

				$update_due->execute();
				$_SESSION['due_partially_paid'] = "due_partially_paid";
				header('Location: view-single-dealer.php?customer_id='.$row['customer_id']);

			}else{
				echo '<script>alert("try again!! paid amout is bigger than due amount");</script>';
			}

		}catch (PDOException $e) {
			echo $e->getMessage();
		}

	}



/* --------------------add_expense_data----------------- */

	public function add_expense_data($data){
		// data insert   
		$expense_source  = $this->test_form_input_data($data['expense_source']);
		$expense_amount = $this->test_form_input_data($data['expense_amount']);
		$responsible_person = $this->test_form_input_data($data['responsible_person']);
		$person_designation = $this->test_form_input_data($data['person_designation']);
		$person_contact = $this->test_form_input_data($data['person_contact']);
		$expense_date = $this->test_form_input_data($data['expense_date']);

		try{
			$add_expense = $this->db->prepare("INSERT INTO tbl_expense_source (expense_source, expense_amount, responsible_person, person_designation, person_contact, expense_date) VALUES (:x, :y, :z, :a, :b, :c) ");

			$add_expense->bindparam(':x', $expense_source);
			$add_expense->bindparam(':y', $expense_amount);
			$add_expense->bindparam(':z', $responsible_person);
			$add_expense->bindparam(':a', $person_designation);
			$add_expense->bindparam(':b', $person_contact);
			$add_expense->bindparam(':c', $expense_date);

			$add_expense->execute();

			$_SESSION['add_expense'] = 'add_expense';

			header('Location: manage_expense.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}	


/* ----------------------add_new_permanent_customer--------------*/

	public function add_new_permanent_customer($data){
		$customer_name  = $this->test_form_input_data($data['customer_name']);
		$customer_email = $this->test_form_input_data($data['customer_email']);
		$customer_contact = $this->test_form_input_data($data['customer_contact']);
		$customer_description = $this->test_form_input_data($data['customer_description']);
		if(empty($customer_email)){
			$customer_email = "No Email";
		}
		if(empty($customer_description)){
			$customer_description = "No Description";
		}
		try{
			$add_new_customer = $this->db->prepare("INSERT INTO tbl_permanent_customer (customer_name, customer_email, customer_contact, customer_description) VALUES (:x, :y, :z, :a) ");

			$add_new_customer->bindparam(':x', $customer_name);
			$add_new_customer->bindparam(':y', $customer_email);
			$add_new_customer->bindparam(':z', $customer_contact);
			$add_new_customer->bindparam(':a', $customer_description);

			$add_new_customer->execute();

			$_SESSION['adding_permanent_customer'] = 'adding_permanent_customer';

			header('Location: accounts-customer-panel.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* =====================update_permanent_customer===================== */

	public function update_permanent_customer($data, $customer_id){
		$customer_name  = $this->test_form_input_data($data['customer_name']);
		$customer_email = $this->test_form_input_data($data['customer_email']);
		$customer_contact = $this->test_form_input_data($data['customer_contact']);
		$customer_description = $this->test_form_input_data($data['customer_description']);
		if(empty($customer_email)){
			$customer_email = "No Email";
		}
		if(empty($customer_description)){
			$customer_description = "No Description";
		}
		try{
			$update_customer = $this->db->prepare("UPDATE tbl_permanent_customer SET customer_name = :x, customer_email = :y, customer_contact = :z, customer_description = :a WHERE customer_id = :id ");

			$update_customer->bindparam(':x', $customer_name);
			$update_customer->bindparam(':y', $customer_email);
			$update_customer->bindparam(':z', $customer_contact);
			$update_customer->bindparam(':a', $customer_description);
			$update_customer->bindparam(':id', $customer_id);

			$update_customer->execute();

			$_SESSION['update_permanent_customer'] = 'update_permanent_customer';

			header('Location: accounts-customer-panel.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}

	}

/* ====================add_regular_product_sale=================== */

	public function add_regular_product_sale($data){

		$product_name  = $this->test_form_input_data($data['product_name']);
		$product_code = $this->test_form_input_data($data['product_code']);
		$product_sale_price = $this->test_form_input_data($data['product_price']);
		$product_quantity = $this->test_form_input_data($data['product_quantity']);

		$product_discount  = $this->test_form_input_data($data['product_discount']);
		$customer_name = $this->test_form_input_data($data['customer_name']);
		$customer_contact = $this->test_form_input_data($data['customer_contact']);
		$product_current_stock = $this->test_form_input_data($data['product_total_quantity']);
		$customer_type = "Irregular";
		if(empty($product_discount)){
			$product_discount = 0;
		}

		$total_price = $product_sale_price * $product_quantity - $product_discount;
		
		try{
			
		$sale_date = date("Y-m-d");
		// sale product
			$cus_id = 0;

			$due_amount = 0.00;
		    if(!empty($customer_name)){
		    	if(empty($customer_contact)){
		    		$customer_contact = "Not Given";
		    	}
		    	$add_irregular_trans = $this->db->prepare("INSERT INTO tbl_irregular_transaction (customer_name, customer_contact, product_name, product_quantity, total_amount, due_amount) VALUES (:x, :y, :z, :a, :b, :c) ");

		    	$add_irregular_trans->bindparam(':x', $customer_name);
				$add_irregular_trans->bindparam(':y', $customer_contact);
				$add_irregular_trans->bindparam(':z', $product_name);
				$add_irregular_trans->bindparam(':a', $product_quantity);
				$add_irregular_trans->bindparam(':b', $total_price);
				$add_irregular_trans->bindparam(':c', $due_amount);

				$add_irregular_trans->execute();

				$last_id = $this->db->lastInsertId();
		    }

			// sale product 
			$add_sale = $this->db->prepare("INSERT INTO tbl_sales_product (product_name, product_code, total_sale_price, product_quantity, customer_type, due_trans_id, product_sale_date) VALUES (:x, :y, :z, :a, :b, :c, :d) ");
			$add_sale->bindparam(':x', $product_name);
			$add_sale->bindparam(':y', $product_code);
			$add_sale->bindparam(':z', $total_price);
			$add_sale->bindparam(':a', $product_quantity);
			$add_sale->bindparam(':b', $customer_type);
			$add_sale->bindparam(':c', $last_id);
			$add_sale->bindparam(':d', $sale_date);

			if( $add_sale->execute() ){

			    // =======update product inventory======== 
			    $product_new_stock = $product_current_stock - $product_quantity;

			    $update_product = $this->db->prepare("UPDATE tbl_product SET product_total_quantity= :x WHERE  product_code = :code");
				$update_product->bindparam(':x', $product_new_stock);
				$update_product->bindparam(':code', $product_code);
				$update_product->execute();

			    // add customer

			    if(!empty($customer_name)){
			    	if(empty($customer_contact)){
			    		$customer_contact = "Not Given";
			    	}
			    	$add_customer = $this->db->prepare("INSERT INTO tbl_regular_customer (customer_name, customer_contact) VALUES (:x, :y) ");

			    	$add_customer->bindparam(':x', $customer_name);
					$add_customer->bindparam(':y', $customer_contact);

					$add_customer->execute();
			    }


			    // income add 
			    $user_name = $_SESSION['admin_name'];
			    $admin_designation = $_SESSION['user_role'];
			    if($admin_designation==1){
			    	$user_designation = "Admin";
			    }else{
			    	$user_designation = "Sales Person";
			    }
			    
			    $add_income = $this->db->prepare("INSERT INTO tbl_income_source (income_source, income_description, income_amount, responsible_person, person_designation, product_sale_date) VALUES (:x, :y, :z, :a, :b, :c) ");
				$add_income->bindparam(':x', $product_name);
				$add_income->bindparam(':y', $product_code);
				$add_income->bindparam(':z', $total_price);
				$add_income->bindparam(':a', $user_name);
				$add_income->bindparam(':b', $user_designation);
				$add_income->bindparam(':c', $sale_date);

			    //$add_income->execute();

			}

			header('Location: sales-print.php?product_code='.$product_code.'&product_quantity='.$product_quantity.'&product_discount='.$product_discount.'&customer_name='.$customer_name.'&customer_contact='.$customer_contact);

		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ===============delete_irregular_customer_data_by_this_method======*/

	public function delete_irregular_customer_data_by_this_method($sale_id){
		// find sale info
		$sql = "SELECT * FROM tbl_sales_product WHERE sale_id = '$sale_id' ";
		$info = $this->manage_all_info($sql);
        $row = $info->fetch(PDO::FETCH_ASSOC);

        $product_quantity = $row['product_quantity'];
        $product_code = $row['product_code'];

		try{

			$sql = "DELETE FROM tbl_sales_product WHERE sale_id = :id";
			
			$delete_product = $this->db->prepare($sql);
			$delete_product->bindparam(':id', $sale_id);
			
			if( $delete_product->execute() ){
				$sql_qty = "SELECT * FROM tbl_product WHERE product_code = '$product_code' ";
				$info_qty = $this->manage_all_info($sql_qty);
        		$row_qty = $info_qty->fetch(PDO::FETCH_ASSOC);
        		$product_qty = $row_qty['product_total_quantity'];

        		$product_new_qty = $product_qty + $product_quantity;

        		// update product
        		$update_product = $this->db->prepare("UPDATE tbl_product SET product_total_quantity= :x WHERE  product_code = :code ");
				$update_product->bindparam(':x', $product_new_qty);
				$update_product->bindparam(':code', $product_code);
				$update_product->execute();

			}
			// delete expense
			header('Location: accounts-sales.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ==================delete_dealer_data_by_this_method================*/


	public function delete_dealer_data_by_this_method($sale_id){
		// find sale info
		$sql = "SELECT * FROM tbl_sales_product WHERE sale_id = '$sale_id' ";
		$info = $this->manage_all_info($sql);
        $row = $info->fetch(PDO::FETCH_ASSOC);

        $product_quantity = $row['product_quantity'];
        $product_code = $row['product_code'];
        $due_trans_id = $row['due_trans_id'];

		try{

			$sql = "DELETE FROM tbl_sales_product WHERE sale_id = :id";
			
			$delete_product = $this->db->prepare($sql);
			$delete_product->bindparam(':id', $sale_id);
			
			if( $delete_product->execute() ){
				$sql_qty = "SELECT * FROM tbl_product WHERE product_code = '$product_code' ";
				$info_qty = $this->manage_all_info($sql_qty);
        		$row_qty = $info_qty->fetch(PDO::FETCH_ASSOC);
        		$product_qty = $row_qty['product_total_quantity'];

        		$product_new_qty = $product_qty + $product_quantity;

        		// update product
        		$update_product = $this->db->prepare("UPDATE tbl_product SET product_total_quantity= :x WHERE  product_code = :code ");
				$update_product->bindparam(':x', $product_new_qty);
				$update_product->bindparam(':code', $product_code);
				$update_product->execute();

				// delete due data

				$sql_due_cus = "DELETE FROM tbl_customer_due WHERE due_id = :id";
			
				$sql_due_cus = $this->db->prepare($sql);
				$sql_due_cus->bindparam(':id', $due_trans_id);
				$sql_due_cus->execute();

			}
			// delete expense
			header('Location: accounts-sales.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}



/* ==============product_sale_for_permanent_customer============= */

	public function product_sale_for_permanent_customer($data,$new_customer_id){

		$product_name  = $this->test_form_input_data($data['product_name']);
		$product_code = $this->test_form_input_data($data['product_code']);
		$product_sale_price = $this->test_form_input_data($data['product_price']);
		$product_quantity = $this->test_form_input_data($data['product_quantity']);

		$product_discount  = $this->test_form_input_data($data['product_discount']);
		$due_paid_date = $this->test_form_input_data($data['due_paid_date']);
		$due_amount = $this->test_form_input_data($data['due_amount']);
		$product_current_stock = $this->test_form_input_data($data['product_total_quantity']);
		$customer_type = "Dealer";
		if(empty($product_discount)){
			$product_discount = 0;
		}
		if(empty($due_amount)){
			$due_amount = 0;
		}

		$total_price = $product_sale_price * $product_quantity - $product_discount;
		$total_paid = $total_price - $due_amount;
		try{

		$sale_date = date("Y-m-d");

			$add_due = $this->db->prepare("INSERT INTO tbl_customer_due (customer_id, product_name, product_code, product_quantity, total_amount, total_paid, due_remain, due_paid_date) VALUES (:x, :y, :z, :a, :b, :c, :d, :e) ");

		    	$add_due->bindparam(':x', $new_customer_id);
				$add_due->bindparam(':y', $product_name);
				$add_due->bindparam(':z', $product_code);
				$add_due->bindparam(':a', $product_quantity);
				$add_due->bindparam(':b', $total_price);
				$add_due->bindparam(':c', $total_paid);
				$add_due->bindparam(':d', $due_amount);
				$add_due->bindparam(':e', $due_paid_date);

				$add_due->execute();
				$last_id = $this->db->lastInsertId();

		// sale product
			$add_sale = $this->db->prepare("INSERT INTO tbl_sales_product (product_name, product_code, total_sale_price, product_quantity, customer_type, due_trans_id, product_sale_date) VALUES (:x, :y, :z, :a, :b, :c, :d) ");
			$add_sale->bindparam(':x', $product_name);
			$add_sale->bindparam(':y', $product_code);
			$add_sale->bindparam(':z', $total_price);
			$add_sale->bindparam(':a', $product_quantity);
			$add_sale->bindparam(':b', $customer_type);
			$add_sale->bindparam(':c', $last_id);
			$add_sale->bindparam(':d', $sale_date);

			if( $add_sale->execute() ){

			    // =====update product inventory====== 
			    $product_new_stock = $product_current_stock - $product_quantity;

			    $update_product = $this->db->prepare("UPDATE tbl_product SET product_total_quantity= :x WHERE  product_code = :code ");
				$update_product->bindparam(':x', $product_new_stock);
				$update_product->bindparam(':code', $product_code);
				$update_product->execute();

			    // add due amount

				
			    
			    // income add 
			    $user_name = $_SESSION['admin_name'];
			    $admin_designation = $_SESSION['user_role'];
			    if($admin_designation==1){
			    	$user_designation = "Admin";
			    }else{
			    	$user_designation = "Sales Person";
			    }
			    $add_income = $this->db->prepare("INSERT INTO tbl_income_source (income_source, income_description, income_amount, responsible_person, person_designation, product_sale_date) VALUES (:x, :y, :z, :a, :b, :c) ");
				$add_income->bindparam(':x', $product_name);
				$add_income->bindparam(':y', $product_code);
				$add_income->bindparam(':z', $total_price);
				$add_income->bindparam(':a', $user_name);
				$add_income->bindparam(':b', $user_designation);
				$add_income->bindparam(':c', $sale_date);

			    $add_income->execute();

			}

		    //$_SESSION['sale_completed'] = "sale completed";
			//header('Location: sale-now.php');

			header('Location: sales-print-permanent.php?product_code='.$product_code.'&product_quantity='.$product_quantity.'&product_discount='.$product_discount.'&customer_id='.$new_customer_id.'&due_amount='.$due_amount);

		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ===================add_new_supplier_account================= */

	public function add_new_supplier_account($data){
		// data insert   
		$supplier_name  = $this->test_form_input_data($data['supplier_name']);
		$supplier_contact = $this->test_form_input_data($data['supplier_contact']);
		$supplier_email = $this->test_form_input_data($data['supplier_email']);
		$supplier_details = $this->test_form_input_data($data['supplier_details']);

		try{
			$add_supplier = $this->db->prepare("INSERT INTO tbl_add_supplier (supplier_name, supplier_contact, supplier_email, supplier_details) VALUES (:x, :y, :z, :a) ");

			$add_supplier->bindparam(':x', $supplier_name);
			$add_supplier->bindparam(':y', $supplier_contact);
			$add_supplier->bindparam(':z', $supplier_email);
			$add_supplier->bindparam(':a', $supplier_details);

			$add_supplier->execute();
			$_SESSION['add_supplier'] = 'add_supplier';

			header('Location: accounts-supplier-panel.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}	
	}

/* ================update_new_supplier_account====================*/

	public function update_new_supplier_account($data, $supplier_id){
		   
		$supplier_name  = $this->test_form_input_data($data['supplier_name']);
		$supplier_contact = $this->test_form_input_data($data['supplier_contact']);
		$supplier_email = $this->test_form_input_data($data['supplier_email']);
		$supplier_details = $this->test_form_input_data($data['supplier_details']);

		try{
			$update_supplier = $this->db->prepare("UPDATE tbl_add_supplier SET supplier_name = :x, supplier_contact = :y, supplier_email = :z, supplier_details = :a WHERE supplier_id = :id");

			$update_supplier->bindparam(':x', $supplier_name);
			$update_supplier->bindparam(':y', $supplier_contact);
			$update_supplier->bindparam(':z', $supplier_email);
			$update_supplier->bindparam(':a', $supplier_details);
			$update_supplier->bindparam(':id', $supplier_id);

			$update_supplier->execute();
			$_SESSION['update_supplier'] = 'update_supplier';

			header('Location: accounts-supplier-panel.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}	
	}


/* ===============add_supplier_product_transaction============= */

	public function add_supplier_product_transaction($data){
		// data insert   
		$supplier_name  = $this->test_form_input_data($data['supplier_name']);
		$supplier_id = explode("/", $supplier_name);
		$product_name = $this->test_form_input_data($data['product_name']);
		$product_code = $this->test_form_input_data($data['product_code']);
		$original_price  = $this->test_form_input_data($data['original_price']);
		$discount_amount = $this->test_form_input_data($data['discount_amount']);
		$due_amount = $this->test_form_input_data($data['due_amount']);
		$short_description = $this->test_form_input_data($data['short_description']);

		$product_category = $this->test_form_input_data($data['product_category']);	
		$unit_sale_price = $this->test_form_input_data($data['unit_sale_price']);
		$whole_sale_quantity = $this->test_form_input_data($data['whole_sale_quantity']);
		$whole_sale_price = $this->test_form_input_data($data['whole_sale_price']);

		$product_total_quantity = $this->test_form_input_data($data['product_total_quantity']);	
		$total_product_buying_price = $this->test_form_input_data($data['total_product_buying_price']);

		$product_incoming_date = $this->test_form_input_data($data['product_incoming_date']);
		$product_expire_date = $this->test_form_input_data($data['product_expire_date']);

		try{
			if( empty($unit_sale_price) ){
				// only supplier transaction add not for sale
				$sale_product_id = 0;
				$add_supplier_product = $this->db->prepare("INSERT INTO tbl_supplier_product (supplier_id, product_name, product_code, product_quantity, original_price, product_discount, due_amount, short_description, sale_product_id, product_incoming_date, product_expire_date) VALUES (:x, :y, :z, :a, :b, :c, :d, :e, :f, :g, :h) ");

				$add_supplier_product->bindparam(':x', $supplier_id[1]);
				$add_supplier_product->bindparam(':y', $product_name);
				$add_supplier_product->bindparam(':z', $product_code);
				$add_supplier_product->bindparam(':a', $product_total_quantity);
				$add_supplier_product->bindparam(':b', $original_price);
				$add_supplier_product->bindparam(':c', $discount_amount);
				$add_supplier_product->bindparam(':d', $due_amount);
				$add_supplier_product->bindparam(':e', $short_description);
				$add_supplier_product->bindparam(':f', $sale_product_id);
				$add_supplier_product->bindparam(':g', $product_incoming_date);
				$add_supplier_product->bindparam(':h', $product_expire_date);

				$add_supplier_product->execute();

				header('Location: accounts-supplier-product.php');

				//echo '<script>alert("add product for sale");</script>';

			}else{

				// add supplier product add add for product sale

				$sql = "SELECT * FROM tbl_product WHERE product_code = '$product_code' ";
                $info = $this->manage_all_info($sql); 
                $row = $info->fetch(PDO::FETCH_ASSOC);

                $product_exist = $info->rowCount();

                if($product_exist<=0){
                	// if not exist in product list add product
                	$add_product = $this->db->prepare("INSERT INTO tbl_product (product_name, product_code, product_category, unit_sale_price, unit_per_lot, lot_sale_price, product_total_quantity, total_product_buying_price, product_incoming_date, product_expire_date, initial_product_quantity) VALUES (:x, :y, :z, :a, :b, :c, :d, :e, :f, :g, :h) ");

					$add_product->bindparam(':x', $product_name);
					$add_product->bindparam(':y', $product_code);
					$add_product->bindparam(':z', $product_category);
					$add_product->bindparam(':a', $unit_sale_price);
					$add_product->bindparam(':b', $whole_sale_quantity);
					$add_product->bindparam(':c', $whole_sale_price);
					$add_product->bindparam(':d', $product_total_quantity);
					$add_product->bindparam(':e', $total_product_buying_price);
					$add_product->bindparam(':f', $product_incoming_date);
					$add_product->bindparam(':g', $product_expire_date);
					$add_product->bindparam(':h', $product_total_quantity);

					$add_product->execute();
					// find last inserted id
					$last_id = $this->db->lastInsertId();
                }else{
                	// update product stock
                	$last_id = $row['product_id'];
                	$previous_quantity = $row['product_total_quantity'];
                	$product_new_quantity = $previous_quantity + $product_total_quantity;

                	$update_stock = $this->db->prepare("UPDATE tbl_product SET product_total_quantity = :x, initial_product_quantity = :y WHERE  product_code = :id");

					$update_stock->bindparam(':x', $product_new_quantity);
					$update_stock->bindparam(':y', $product_new_quantity);
					$update_stock->bindparam(':id', $product_code);

					$update_stock->execute();
                }

                // add supplier product 
				$add_supplier_product = $this->db->prepare("INSERT INTO tbl_supplier_product (supplier_id, product_name, product_code, product_quantity, original_price, product_discount, due_amount, short_description, sale_product_id, product_incoming_date, product_expire_date) VALUES (:x, :y, :z, :a, :b, :c, :d, :e, :f, :g, :h) ");

				$add_supplier_product->bindparam(':x', $supplier_id[1]);
				$add_supplier_product->bindparam(':y', $product_name);
				$add_supplier_product->bindparam(':z', $product_code);
				$add_supplier_product->bindparam(':a', $product_total_quantity);
				$add_supplier_product->bindparam(':b', $original_price);
				$add_supplier_product->bindparam(':c', $discount_amount);
				$add_supplier_product->bindparam(':d', $due_amount);
				$add_supplier_product->bindparam(':e', $short_description);
				$add_supplier_product->bindparam(':f', $last_id);
				$add_supplier_product->bindparam(':g', $product_incoming_date);
				$add_supplier_product->bindparam(':h', $product_expire_date);

				$add_supplier_product->execute();

                $_SESSION['add_supplier_product'] = 'add_supplier_product';
				header('Location: accounts-supplier-product.php');
			}

			$_SESSION['add_supplier_product'] = 'add_supplier_product';
			//header('Location: accounts-supplier-product.php');

		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ===============delete_supplier_product_transaction============*/

	public function delete_supplier_product_transaction($product_id){
		$sql = "SELECT * FROM tbl_supplier_product WHERE product_id = '$product_id' ";
        $info = $this->manage_all_info($sql);
        $row = $info->fetch(PDO::FETCH_ASSOC);
        $product_code = $row['product_code'];
        $product_qty = $row['product_quantity'];
		try{

			$sql = "DELETE FROM tbl_supplier_product WHERE product_id = :id";
			$delete_data = $this->db->prepare($sql);
			$delete_data->bindparam(':id', $product_id);
			if( $delete_data->execute() ){

				$sql_acc = "SELECT * FROM tbl_product WHERE product_code = '$product_code' ";
        		$info_acc = $this->manage_all_info($sql_acc);
        		$row_acc = $info_acc->fetch(PDO::FETCH_ASSOC);

        		$prev_qty = $row_acc['product_total_quantity'];

        		$new_qty = $prev_qty - $product_qty;
        		// update available
        		$update_qty = $this->db->prepare("UPDATE tbl_product SET product_total_quantity = :x WHERE  product_code = :id ");
				$update_qty->bindparam(':x', $new_qty);
				$update_qty->bindparam(':id', $product_code);
				$update_qty->execute();
			}

			header('Location: accounts-supplier-product.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}

	}


/* ================update_supplier_product_transaction============*/

	public function update_supplier_product_transaction($data, $product_id){
		// data insert   
		$supplier_name  = $this->test_form_input_data($data['supplier_name']);
		$supplier_id = explode("/", $supplier_name);
		$product_name = $this->test_form_input_data($data['product_name']);
		$product_code = $this->test_form_input_data($data['product_code']);
		$old_product_code = $this->test_form_input_data($data['old_product_code']);
		$product_quantity = $this->test_form_input_data($data['product_quantity']);
		$product_old_quantity = $this->test_form_input_data($data['product_old_quantity']);
		$original_price = $this->test_form_input_data($data['original_price']);
		$product_discount  = $this->test_form_input_data($data['product_discount']);
		$due_amount = $this->test_form_input_data($data['due_amount']);
		$short_description = $this->test_form_input_data($data['short_description']);
		// product table product id
		$sale_product_id = $this->test_form_input_data($data['sale_product_id']);	
		$product_incoming_date = $this->test_form_input_data($data['product_incoming_date']);
		$product_expire_date = $this->test_form_input_data($data['product_expire_date']);

		try{

			$update_supplier_product = $this->db->prepare("UPDATE tbl_supplier_product SET  supplier_id = :x, product_name = :y, product_code = :z, product_quantity = :a, original_price = :b, product_discount = :c, due_amount = :d, short_description = :e, product_incoming_date = :f, product_expire_date = :g WHERE product_id = :id");

			$update_supplier_product->bindparam(':x', $supplier_id[1]);
			$update_supplier_product->bindparam(':y', $product_name);
			$update_supplier_product->bindparam(':z', $product_code);
			$update_supplier_product->bindparam(':a', $product_quantity);
			$update_supplier_product->bindparam(':b', $original_price);
			$update_supplier_product->bindparam(':c', $product_discount);
			$update_supplier_product->bindparam(':d', $due_amount);
			$update_supplier_product->bindparam(':e', $short_description);
			$update_supplier_product->bindparam(':f', $product_incoming_date);
			$update_supplier_product->bindparam(':g', $product_expire_date);
			$update_supplier_product->bindparam(':id', $product_id);

			$update_supplier_product->execute();

			// update tbl product table 
			$sql_pro = "SELECT * FROM tbl_product WHERE product_id = 'sale_product_id' ";
			$info_pro = $this->manage_all_info($sql_pro);
			$row_pro = $info_pro->fetch(PDO::FETCH_ASSOC);
			$total_product_quantity = $row_pro['total_product_quantity'];
			$initial_product_quantity = $row_pro['initial_product_quantity'];

			$new_total_product_quantity = $total_product_quantity + $product_quantity; 
			$new_initial_product_quantity = $initial_product_quantity + $product_quantity; 

			if($old_product_code == $product_code){
				if($product_old_quantity != $product_quantity){
					// update sale product stock
					$update_product_qty = $this->db->prepare("UPDATE tbl_product SET  product_total_quantity = :x, initial_product_quantity = :y WHERE product_id = :id");

					$update_product_qty->bindparam(':x', $new_total_product_quantity);
					$update_product_qty->bindparam(':y', $new_initial_product_quantity);
					$update_product_qty->bindparam(':id', $sale_product_id);

					$update_product_qty->execute();
				}
			}else{
				// do nothing
			}

			$_SESSION['update_supplier_product'] = 'update_supplier_product';
			header('Location: accounts-supplier-product.php');

		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* =================add_new_bank_account===================== */

	public function add_new_bank_account($data){
		// data insert   
		$account_name  = $this->test_form_input_data($data['account_name']);
		$account_number = $this->test_form_input_data($data['account_number']);
		$available_balance = $this->test_form_input_data($data['available_balance']);
		$bank_name = $this->test_form_input_data($data['bank_name']);
		$bank_contact = $this->test_form_input_data($data['bank_contact']);

		try{
			$add_bank = $this->db->prepare("INSERT INTO tbl_bank_account (account_name, account_number, available_balance, initial_balance, bank_name, bank_contact) VALUES (:x, :y, :z, :a, :b, :c) ");

			$add_bank->bindparam(':x', $account_name);
			$add_bank->bindparam(':y', $account_number);
			$add_bank->bindparam(':z', $available_balance);
			$add_bank->bindparam(':a', $available_balance);
			$add_bank->bindparam(':b', $bank_name);
			$add_bank->bindparam(':c', $bank_contact);

			$add_bank->execute();

			$_SESSION['add_bank'] = 'add_bank';

			header('Location: admin-banking-accounts.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ====================update_bank_account_info==============*/

	public function update_bank_account_info($data,$account_id){
		// data insert   
		$account_name  = $this->test_form_input_data($data['account_name']);
		$account_number = $this->test_form_input_data($data['account_number']);
		$available_balance = $this->test_form_input_data($data['available_balance']);
		$bank_name = $this->test_form_input_data($data['bank_name']);
		$bank_contact = $this->test_form_input_data($data['bank_contact']);

		try{
			$update_info = $this->db->prepare("UPDATE tbl_bank_account SET account_name = :x, account_number = :y, available_balance = :z, bank_name = :a, bank_contact = :b WHERE account_id = :id ");

			$update_info->bindparam(':x', $account_name);
			$update_info->bindparam(':y', $account_number);
			$update_info->bindparam(':z', $available_balance);
			$update_info->bindparam(':a', $bank_name);
			$update_info->bindparam(':b', $bank_contact);
			$update_info->bindparam(':id', $account_id);

			$update_info->execute();

			$_SESSION['update_acc_info'] = 'update_acc_info';

			header('Location: admin-banking-accounts.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* =====================add_bank_deposit===================== */

	public function add_bank_deposit_or_withdraw($data){
		// data insert   
		$transaction_type  = $this->test_form_input_data($data['transaction_type']);
		$account_id = $this->test_form_input_data($data['account_id']);
		$withdraw_purpose = $this->test_form_input_data($data['withdraw_purpose']);
		$transaction_amount = $this->test_form_input_data($data['transaction_amount']);

		$sql = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
		$info = $this->manage_all_info($sql);
		$row = $info->fetch(PDO::FETCH_ASSOC);
		$available_balance = $row['available_balance'];

		try{

			if($transaction_type == 'Withdrawal'){

				$new_available_balance = $available_balance - $transaction_amount;

				$balance_withdraw = $this->db->prepare("INSERT INTO tbl_balance_withdraw (account_id, withdraw_amount, withdraw_purpose) VALUES (:x, :y, :z) ");

				$balance_withdraw->bindparam(':x', $account_id);
				$balance_withdraw->bindparam(':y', $transaction_amount);
				$balance_withdraw->bindparam(':z', $withdraw_purpose);
				if( $balance_withdraw->execute() ){
					$update_balance = $this->db->prepare("UPDATE tbl_bank_account SET available_balance = :x WHERE account_id = :id ");
					$update_balance->bindparam(':x', $new_available_balance);
					$update_balance->bindparam(':id', $account_id);
					$update_balance->execute();
				}
				
				$_SESSION['balance_withdraw'] = 'balance_withdraw';
				header('Location: admin-banking-transactions.php');

			}else if($transaction_type == 'Deposit'){

				$new_available_balance = $available_balance + $transaction_amount;

				$add_deposit = $this->db->prepare("INSERT INTO tbl_bank_deposit (account_id, deposit_amount) VALUES (:x, :y) ");

				$add_deposit->bindparam(':x', $account_id);
				$add_deposit->bindparam(':y', $transaction_amount);

				if( $add_deposit->execute() ){
					$update_balance = $this->db->prepare("UPDATE tbl_bank_account SET available_balance = :x WHERE account_id = :id ");
					$update_balance->bindparam(':x', $new_available_balance);
					$update_balance->bindparam(':id', $account_id);
					$update_balance->execute();
				}
				
				$_SESSION['add_deposit'] = 'add_deposit';
				header('Location: admin-banking-transactions.php');
			}
			
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ==============update_bank_deposit_or_withdraw================*/

	public function update_bank_deposit_or_withdraw($data,$prev_trns_type,$taransaction_id,$account_id){
		// data insert   
		$transaction_type  = $this->test_form_input_data($data['transaction_type']);
		$account_id = $this->test_form_input_data($data['account_id']);
		$withdraw_purpose = $this->test_form_input_data($data['withdraw_purpose']);
		$transaction_amount = $this->test_form_input_data($data['transaction_amount']);

		$sql = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
		$info = $this->manage_all_info($sql);
		$row = $info->fetch(PDO::FETCH_ASSOC);
		$available_balance = $row['available_balance'];

		try{
			if($prev_trns_type == $transaction_type){



			}else{

			}
			if($transaction_type == 'Withdrawal'){

				$new_available_balance = $available_balance - $transaction_amount;

				$balance_withdraw = $this->db->prepare("INSERT INTO tbl_balance_withdraw (account_id, withdraw_amount, withdraw_purpose) VALUES (:x, :y, :z) ");

				$balance_withdraw->bindparam(':x', $account_id);
				$balance_withdraw->bindparam(':y', $transaction_amount);
				$balance_withdraw->bindparam(':z', $withdraw_purpose);
				if( $balance_withdraw->execute() ){
					$update_balance = $this->db->prepare("UPDATE tbl_bank_account SET available_balance = :x WHERE account_id = :id ");
					$update_balance->bindparam(':x', $new_available_balance);
					$update_balance->bindparam(':id', $account_id);
					$update_balance->execute();
				}
				
				$_SESSION['balance_withdraw'] = 'balance_withdraw';
				header('Location: admin-banking-transactions.php');

			}else if($transaction_type == 'Deposit'){

				$new_available_balance = $available_balance + $transaction_amount;

				$add_deposit = $this->db->prepare("INSERT INTO tbl_bank_deposit (account_id, deposit_amount) VALUES (:x, :y) ");

				$add_deposit->bindparam(':x', $account_id);
				$add_deposit->bindparam(':y', $transaction_amount);

				if( $add_deposit->execute() ){
					$update_balance = $this->db->prepare("UPDATE tbl_bank_account SET available_balance = :x WHERE account_id = :id ");
					$update_balance->bindparam(':x', $new_available_balance);
					$update_balance->bindparam(':id', $account_id);
					$update_balance->execute();
				}
				
				$_SESSION['add_deposit'] = 'add_deposit';
				header('Location: admin-banking-transactions.php');
			}
			
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* =====================update_bank_deposit=============== */

	public function update_bank_deposit($data, $deposit_id){
		// data insert   
		$bank_name  = $this->test_form_input_data($data['account_name']);
		$account_name = $this->test_form_input_data($data['account_number']);
		$account_number = $this->test_form_input_data($data['bank_name']);
		$deposit_amount = $this->test_form_input_data($data['branch_name']);

		try{
			$add_deposit = $this->db->prepare("INSERT INTO tbl_bank_deposit (bank_name, account_name, account_number, deposit_amount) VALUES (:x, :y, :z, :a) ");

			$add_deposit->bindparam(':x', $bank_name);
			$add_deposit->bindparam(':y', $account_name);
			$add_deposit->bindparam(':z', $account_number);
			$add_deposit->bindparam(':a', $deposit_amount);

			$add_deposit->execute();

			$_SESSION['add_deposit'] = 'add_deposit';

			header('Location: manage-income.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* ====================add_balance_withdraw==================*/

	public function add_balance_withdraw($data){
		// data insert   
		$bank_name  = $this->test_form_input_data($data['account_name']);
		$account_name = $this->test_form_input_data($data['account_number']);
		$account_number = $this->test_form_input_data($data['bank_name']);
		$withdraw_amount = $this->test_form_input_data($data['withdraw_amount']);

		try{
			$balance_withdraw = $this->db->prepare("INSERT INTO tbl_bank_deposit (bank_name, account_name, account_number, withdraw_amount) VALUES (:x, :y, :z, :a) ");

			$balance_withdraw->bindparam(':x', $bank_name);
			$balance_withdraw->bindparam(':y', $account_name);
			$balance_withdraw->bindparam(':z', $account_number);
			$balance_withdraw->bindparam(':a', $withdraw_amount);

			$balance_withdraw->execute();

			$_SESSION['balance_withdraw'] = 'balance_withdraw';

			header('Location: manage-income.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* --------------------add_income_data----------------------- */

	public function add_income_data($data){
		// data insert   
		$income_source  = $this->test_form_input_data($data['income_source']);
		$income_description = $this->test_form_input_data($data['income_description']);
		$responsible_person = $this->test_form_input_data($data['responsible_person']);
		$person_designation = $this->test_form_input_data($data['person_designation']);
		$person_contact = $this->test_form_input_data($data['person_contact']);
		$income_amount = $this->test_form_input_data($data['income_amount']);

		try{
			$add_income = $this->db->prepare("INSERT INTO tbl_income_source (income_source, income_description, responsible_person, person_designation, person_contact, income_amount) VALUES (:x, :y, :z, :a, :b, :c) ");

			$add_income->bindparam(':x', $income_source);
			$add_income->bindparam(':y', $income_description);
			$add_income->bindparam(':z', $responsible_person);
			$add_income->bindparam(':a', $person_designation);
			$add_income->bindparam(':b', $person_contact);
			$add_income->bindparam(':c', $income_amount);

			$add_income->execute();

			$_SESSION['add_income'] = 'add_income';

			header('Location: manage-income.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/*  ---------------update_income_data-------------------- */

	public function update_income_data($data,$income_id){
		// data insert   
		$income_source  = $this->test_form_input_data($data['income_source']);
		$income_description = $this->test_form_input_data($data['income_description']);
		$responsible_person = $this->test_form_input_data($data['responsible_person']);
		$person_designation = $this->test_form_input_data($data['person_designation']);
		$person_contact = $this->test_form_input_data($data['person_contact']);
		$income_amount = $this->test_form_input_data($data['income_amount']);

		try{

			$update_income = $this->db->prepare("UPDATE tbl_income_source SET income_source= :x, income_description = :y, responsible_person = :z, person_designation = :a, person_contact = :b, income_amount = :c WHERE  income_id = :id");

			$update_income->bindparam(':x', $income_source);
			$update_income->bindparam(':y', $income_description);
			$update_income->bindparam(':z', $responsible_person);
			$update_income->bindparam(':a', $person_designation);
			$update_income->bindparam(':b', $person_contact);
			$update_income->bindparam(':c', $income_amount);
			$update_income->bindparam(':id', $income_id);

			$update_income->execute();

			header('Location: manage-income.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}	



/*  ---------------update_expense_data-------------------- */

	public function update_expense_data($data,$expense_id){
		// data insert   
		$expense_source  = $this->test_form_input_data($data['expense_source']);
		$expense_description = $this->test_form_input_data($data['expense_description']);
		$responsible_person = $this->test_form_input_data($data['responsible_person']);
		$person_designation = $this->test_form_input_data($data['person_designation']);
		$person_contact = $this->test_form_input_data($data['person_contact']);
		$expense_amount = $this->test_form_input_data($data['expense_amount']);

		try{

			$update_expense = $this->db->prepare("UPDATE tbl_expense_source SET expense_source= :x, expense_description = :y, responsible_person = :z, person_designation = :a, person_contact = :b, expense_amount = :c WHERE  expense_id = :id");

			$update_expense->bindparam(':x', $expense_source);
			$update_expense->bindparam(':y', $expense_description);
			$update_expense->bindparam(':z', $responsible_person);
			$update_expense->bindparam(':a', $person_designation);
			$update_expense->bindparam(':b', $person_contact);
			$update_expense->bindparam(':c', $expense_amount);
			$update_expense->bindparam(':id', $expense_id);

			$update_expense->execute();

			header('Location: manage-expense.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}




/* ------------------sale_your_product-------------------  */

	

	public function sale_your_product($data){
		// data insert   
		$product_code  = $this->test_form_input_data($data['product_code']);
		$sale_price = $this->test_form_input_data($data['sale_price']);
		$product_quantity = $this->test_form_input_data($data['product_quantity']);

		$total_price = $sale_price * $product_quantity;

		try{

			// sale product
			$add_sale = $this->db->prepare("INSERT INTO tbl_sales_product (product_code, sale_price, product_quantity) VALUES (:x, :y, :z) ");
			$add_sale->bindparam(':x', $product_code);
			$add_sale->bindparam(':y', $total_price);
			$add_sale->bindparam(':z', $product_quantity);
		    $add_sale->execute();

			$sql = "SELECT * FROM tbl_product WHERE product_code = '$product_code'";
			$receive_data = $this->manage_all_info($sql);
			$row = $receive_data->fetch(PDO::FETCH_ASSOC);
			$previous_quantity = $row['product_quantity'];
			$product_id = $row['product_id'];
			$product_code = $row['product_code'];
			$product_name = $row['product_name'];
			$new_quantity = $previous_quantity - $product_quantity;
			

			$update_product = $this->db->prepare("UPDATE tbl_product SET product_quantity= :x WHERE  product_id = :id ");
			$update_product->bindparam(':x', $new_quantity);
			$update_product->bindparam(':id', $product_id);
			$update_product->execute(); 

			$sales_person = 'sales person';
			$add_income = $this->db->prepare("INSERT INTO tbl_income_source (income_source, income_description, responsible_person, income_amount) VALUES (:x, :y, :z, :c) ");

			$add_income->bindparam(':x', $product_code);
			$add_income->bindparam(':y', $product_name);
			$add_income->bindparam(':z', $sales_person);
			$add_income->bindparam(':c', $total_price);

			$add_income->execute();

			header('Location: manage-sale.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}

/* ----------------------manage_all_info--------------------- */

	public function manage_all_info($sql) {
		try{
			$info = $this->db->prepare($sql);
			$info->execute();
			return $info;
		} catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* --------------------delete_data_by_this_method--------------*/

	public function delete_data_by_this_method($sql,$action_id,$sent_po){
		try{
			$delete_data = $this->db->prepare($sql);

			$delete_data->bindparam(':id', $action_id);

			$delete_data->execute();

			header('Location: '.$sent_po);
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}


/* =========delete_withdrawal_by_this_method_method----------------------*/

	public function delete_withdrawal_by_this_method($taransaction_id,$account_id){

		$sql = "SELECT * FROM tbl_balance_withdraw WHERE withdraw_id = '$taransaction_id' ";
        $info = $this->manage_all_info($sql);
        $row = $info->fetch(PDO::FETCH_ASSOC);
        $prev_amount = $row['withdraw_amount'];
		try{
			$sql = "DELETE FROM tbl_balance_withdraw WHERE withdraw_id = :id";
			$delete_data = $this->db->prepare($sql);
			$delete_data->bindparam(':id', $taransaction_id);
			if( $delete_data->execute() ){
				$sql_acc = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
        		$info_acc = $this->manage_all_info($sql_acc);
        		$row_acc = $info_acc->fetch(PDO::FETCH_ASSOC);
        		$prev_available = $row_acc['available_balance'];
        		$new_available = $prev_available + $prev_amount;
        		// update available
        		$update_available = $this->db->prepare("UPDATE tbl_bank_account SET available_balance= :x WHERE  account_id = :id ");
				$update_available->bindparam(':x', $new_available);
				$update_available->bindparam(':id', $account_id);
				$update_available->execute();
			}

			header('Location: admin-banking-transactions.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}

/* =========delete_deposit_by_this_method-method----------------------*/

	public function delete_deposit_by_this_method($taransaction_id,$account_id){
		$sql = "SELECT * FROM tbl_bank_deposit WHERE transaction_id = '$taransaction_id' ";
        $info = $this->manage_all_info($sql);
        $row = $info->fetch(PDO::FETCH_ASSOC);
        $prev_amount = $row['deposit_amount'];
		try{
			$sql = "DELETE FROM tbl_bank_deposit WHERE transaction_id = :id";
			$delete_data = $this->db->prepare($sql);
			$delete_data->bindparam(':id', $taransaction_id);
			if( $delete_data->execute() ){
				$sql_acc = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
        		$info_acc = $this->manage_all_info($sql_acc);
        		$row_acc = $info_acc->fetch(PDO::FETCH_ASSOC);
        		$prev_available = $row_acc['available_balance'];
        		$new_available = $prev_available - $prev_amount;
        		// update available
        		$update_available = $this->db->prepare("UPDATE tbl_bank_account SET available_balance= :x WHERE  account_id = :id ");
				$update_available->bindparam(':x', $new_available);
				$update_available->bindparam(':id', $account_id);
				$update_available->execute();
			}

			header('Location: admin-banking-transactions.php');
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}

/* -----------------------delete_product_data_method--------------- */

	public function delete_product_data_method($action_id,$sent_po){
		$sql = "DELETE FROM tbl_product WHERE product_code = :id";
		$sql1 = "DELETE FROM tbl_expense_source WHERE expense_source = :id";
		try{
			$delete_product = $this->db->prepare($sql);
			$delete_product->bindparam(':id', $action_id);
			$delete_product->execute(); 

			// delete expense

			$delete_expense = $this->db->prepare($sql1);
			$delete_expense->bindparam(':id', $action_id);
			$delete_expense->execute();

			header('Location: '.$sent_po);
		}catch (PDOException $e) {
			echo $e->getMessage();
		}
	}



}
?>