<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}
if(isset($_GET['delete_sale'])){
  $sale_id = $_GET['sale_id'];
  $customer_type = $_GET['customer_type'];
  if($customer_type == "Irregular"){
    // irregular customer
    $obj_admin->delete_irregular_customer_data_by_this_method($sale_id);
  }else if($customer_type == "Dealer"){
    // dealer
    $obj_admin->delete_dealer_data_by_this_method($sale_id);
  }
  
}

$page_name="Accounts";
include("include/header.php");
?>

<script type="text/javascript">

   function changeFunc() {

     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/accounts-sales.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="accounts-expense.php">Expense</a></li>
            <li><a href="accounts-due.php">Transaction</a></li>
            <li class="active"><a href="accounts-sales.php">Sales</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-12">
              <form class="form-inline" action="" name="data_search" id="data_search" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="default"></label>
                  <input type="text" class="form-control" name="category_name" onkeypress="changeFunc();" placeholder="e.g. Product Name" list="category" id="default">
                  <datalist id="category">

                  <?php 
                    $sql = "SELECT * FROM tbl_product";
                    $info = $obj_admin->manage_all_info($sql);
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  ?>

                    <option value="<?php echo $row['product_name']; ?>">
                  <?php 
                    }
                  ?>
                    
                  </datalist>
              </div>
                <div class="form-group">
                <label for="default">Customer Type</label>
                <select class="form-control" name="customer_type" onchange="changeFunc();"> 
                  <option value="Irregular">Irregular</option>
                  <option value="Dealer">Dealer</option>
                </select>
              </div>
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                
              </form> 
            </div>
          </div>
          <div class="gap"></div>
          <div class="table-responsive">

            <table class="table table-codensed table-custom">
              <?php 
              $sql = "SELECT * FROM tbl_sales_product WHERE customer_type ='Irregular' order by sale_id desc";
                $info = $obj_admin->manage_all_info($sql);
                $serial  = 1;
                $total_sales = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){

                      $total_sales += $row['total_sale_price'];
                    }
              ?>
              <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Sale:
              <?php echo $obj_admin->formatMoney($total_sales, true); ?> BDT </caption>

              <thead>
              
                <tr>
                  <th>S.N.</th>
                  <th>Selling Product</th>
                  <th>customer Type</th>
                  <th>Prod Qty.</th>
                  <th>Selling Amount (BDT)</th>
                  <th>Time & Dates</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody id="table_body">

              <?php 
                $sql = "SELECT * FROM tbl_sales_product WHERE customer_type ='Irregular' order by sale_id desc";
                $info = $obj_admin->manage_all_info($sql);
                $serial  = 1;
                $num_row = $info->rowCount();
                if($num_row==0){
                  echo '<tr><td colspan="7">No Data found</td></tr>';
                }
                $total_sales = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['product_name']; ?></td>
                  <td><?php echo $row['customer_type']; ?></td>
                  <td><?php echo $row['product_quantity']; ?></td>
                  <td><?php
                  $total_sales += $row['total_sale_price'];
                   echo $obj_admin->formatMoney($row['total_sale_price'], true); ?></td>
                  <td><?php echo $row['sale_date']; ?></td>
                  <td>
                    <a title="Delete" href="?delete_sale=delete_sale&customer_type=<?php echo $row['customer_type']?>&sale_id=<?php echo $row['sale_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>
                  </td>

                </tr>

              <?php } ?>

              <tr>
                  <td colspan="5">Total Sales</td>
                  <td colspan="2"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_sales, true);

                  echo $remain_amount;?> BDT</td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

?>