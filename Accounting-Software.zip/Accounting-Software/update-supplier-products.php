
<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}


$product_id = $_GET['product_id'];

if(!$product_id){
  header('Location: product-all.php');
}

if(isset($_POST['update_current_product'])){

    $obj_admin->update_supplier_product_transaction($_POST,$product_id);
}

$sql = "SELECT * FROM tbl_supplier_product WHERE product_id='$product_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);
             
$page_name="Suppliers";
include("include/header.php");

?>

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="accounts-supplier-panel.php">Manage Supplier</a></li>
            <li class="active"><a href="accounts-supplier-product.php">Manage Supplier Product</a></li>
          </ul>
          <div class="gap"></div>

          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="well">
                <h3 class="text-center bg-primary" style="padding: 7px;">Edit suplier Product </h3><br>


                      <div class="row">
                        <div class="col-md-12">
                          <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                            <div class="form-group">
                              <label class="control-label col-sm-5">Supplier Name</label>
                              <div class="col-sm-7">
                                <?php 
                                  // find supplier details...
                                  $supplier_id = $row['supplier_id'];
                                  $sql_sup = "SELECT * FROM tbl_add_supplier WHERE supplier_id='$supplier_id' ";
                                  $info_sup = $obj_admin->manage_all_info($sql_sup);
                                  $row_sup = $info_sup->fetch(PDO::FETCH_ASSOC);
                                ?>
                                <input type="text" value="<?php echo $row_sup['supplier_name']."/".$row_sup['supplier_id']; ?>" placeholder="Enter Supplier Name/Id" name="supplier_name" list="languages" class="form-control input-custom" id="default" required>
                                <datalist id="languages">
                                  <?php 
                                    $sql_find = "SELECT * FROM tbl_add_supplier";
                                    $info_find = $obj_admin->manage_all_info($sql_find);
                                    while( $row_find = $info_find->fetch(PDO::FETCH_ASSOC) ){
                                  ?>

                                  <option value="<?php echo $row_find['supplier_name']; ?>/<?php echo $row_find['supplier_id']; ?>">
                                  <?php 
                                    }
                                  ?>        
                                </datalist>
                              </div>
                            </div>
                            
                            <div class="form-group">
                              <label class="control-label col-sm-5">Product Name </label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['product_name']; ?>" placeholder="Enter Product Name" name="product_name" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Product Code</label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['product_code']; ?>" placeholder="Enter Product Code" name="product_code" class="form-control input-custom" required>
                                <input type="hidden" value="<?php echo $row['product_code']; ?>" placeholder="Enter Product Code" name="old_product_code" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Product Quantity</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['product_quantity']; ?>" placeholder="Enter Product Quantity" name="product_quantity" class="form-control input-custom" required>
                                <input type="hidden" value="<?php echo $row['product_quantity']; ?>" placeholder="Enter Product Quantity" name="product_old_quantity" class="form-control input-custom" required>
                              </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-sm-5">Actual Price</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['original_price']; ?>" placeholder="Enter Actual Price" name="original_price" class="form-control input-custom" required>
                              </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-sm-5">Discount</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['product_discount']; ?>" placeholder="Enter Product Discount" name="product_discount" class="form-control input-custom" required>
                              </div>
                            </div>
                            
                            <div class="form-group">
                              <label class="control-label col-sm-5">Due</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['due_amount']; ?>" placeholder="Enter Due Amount" name="due_amount" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Short Description</label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['short_description']; ?>" placeholder="Product short Description" name="short_description" class="form-control input-custom" required>
                                <input type="hidden" value="<?php echo $row['sale_product_id']; ?>" name="sale_product_id" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Incoming Date</label>
                              <div class="col-sm-7">
                                <!-- <input type="text" placeholder="Enter Product Incoming Date" name="product_incoming_date" class="form-control input-custom" required> -->
                                <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                                    <input class="form-control input-custom" value="<?php echo $row['product_incoming_date']; ?>" type="text" name="product_incoming_date" placeholder="Enter Product Incoming Date" required>
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div>

                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Expire Date</label>
                              <div class="col-sm-7">
                                <!-- <input type="text" placeholder="Enter Product Expire Date" name="product_expire_date" class="form-control input-custom" required> -->
                                <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                                    <input class="form-control input-custom" value="<?php echo $row['product_expire_date']; ?>" type="text" name="product_expire_date" placeholder="Enter Product Expire Date" required>
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div>

                              </div>
                            </div>
                            <div class="form-group">
                            </div>
                            <div class="form-group">
                              <div class="col-sm-offset-3 col-sm-3">
                                
                              </div>
                              <div class="col-sm-3">
                                <button type="submit" name="update_current_product" class="btn btn-success-custom">Update Now</button>
                              </div>
                            </div>
                          </form> 
                        </div>
                      </div>

              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

?>