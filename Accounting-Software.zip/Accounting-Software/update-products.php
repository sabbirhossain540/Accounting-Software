
<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}


$product_id = $_GET['product_id'];

if(!$product_id){
  header('Location: product-all.php');
}

if(isset($_POST['update_current_product'])){

    $obj_admin->update_product_or_services_data($_POST,$product_id);
}

$sql = "SELECT * FROM tbl_product WHERE product_id='$product_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);
             
$page_name="Products";
include("include/header.php");

?>


    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="product-available.php">Available</a></li>
            <li><a href="product-stocked.php">Low Stock</a></li>
            <li><a href="product-all.php">All</a></li>
          </ul>
          <div class="gap"></div>

          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="well">
                <h3 class="text-center bg-primary" style="padding: 7px;">Edit Product (Product code: <?php echo $row['product_name']; ?> : <?php echo $row['product_code']; ?>)</h3><br>


                      <div class="row">
                        <div class="col-md-12">
                          <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                            <div class="form-group">
                              <label class="control-label col-sm-5">Product Name</label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['product_name']; ?>" placeholder="Enter Product Name" name="product_name" list="expense" class="form-control input-custom" id="default" required>
                              </div>
                            </div>
                            
                            <div class="form-group">
                              <label class="control-label col-sm-5">Category</label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['product_category']; ?>" placeholder="Enter Product Category" name="product_category" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">unit sale Price</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['unit_sale_price']; ?>" placeholder="Enter Unit sale Price" name="unit_sale_price" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Whole sale amount</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['unit_per_lot']; ?>" placeholder="Enter Number of unit per Lot" name="unit_per_lot" class="form-control input-custom" required>
                              </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-sm-5">Whole sale price</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['lot_sale_price']; ?>" placeholder="Enter Sale Price Per Lot" name="lot_sale_price" class="form-control input-custom" required>
                              </div>
                            </div>
                            
                            <div class="form-group">
                              <label class="control-label col-sm-5">Product Total Quantity</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['product_total_quantity']; ?>" placeholder="Enter Product Total Quantity" name="product_total_quantity" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Total Product Buying Price</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['total_product_buying_price']; ?>" placeholder="Enter Total Product Buying Price" name="total_product_buying_price" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Incoming Date</label>
                              <div class="col-sm-7">
                                <!-- <input type="text" placeholder="Enter Product Incoming Date" name="product_incoming_date" class="form-control input-custom" required> -->
                                <div id="datepicker" class="input-group date" data-date-format="dd-mm-yyyy">
                                    <input class="form-control input-custom" value="<?php echo $row['product_incoming_date']; ?>" type="text" name="product_incoming_date" placeholder="Enter Product Incoming Date" required>
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div>

                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Expire Date</label>
                              <div class="col-sm-7">
                                <!-- <input type="text" placeholder="Enter Product Expire Date" name="product_expire_date" class="form-control input-custom" required> -->
                                <div id="datepicker2" class="input-group date" data-date-format="dd-mm-yyyy">
                                    <input class="form-control input-custom" value="<?php echo $row['product_expire_date']; ?>" type="text" name="product_expire_date" placeholder="Enter Product Expire Date" required>
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div>

                              </div>
                            </div>
                            <div class="form-group">
                            </div>
                            <div class="form-group">
                              <div class="col-sm-offset-3 col-sm-3">
                                
                              </div>
                              <div class="col-sm-3">
                                <button type="submit" name="update_current_product" class="btn btn-success-custom">Update Now</button>
                              </div>
                            </div>
                          </form> 
                        </div>
                      </div>

              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

?>