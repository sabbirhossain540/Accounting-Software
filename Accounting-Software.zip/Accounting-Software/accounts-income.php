<?php
require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

$page_name="Accounts";
include("include/header.php");

?>

<script type="text/javascript">

   function changeFunc() {

     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/accounts-income.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>

<!--modal for customer add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Income</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                <div class="form-group">
                  <label class="control-label col-sm-5">Income Source</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Income Sorce" name="product_code" list="income" class="form-control input-custom" id="default" required>
                    <datalist id="income">

                    <?php 
                    $sql = "SELECT * FROM tbl_income_source";
                    $info = $obj_admin->manage_all_info($sql);
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  ?>

                    <option value="<?php echo $row['income_source']; ?>">
                  <?php 
                    }
                  ?>
                    
                  </datalist>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Ammount</label>
                  <div class="col-sm-7">
                    <input type="number" placeholder="Enter Income Ammount" name="product_code" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Responsible Person</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Responsible Person" name="product_code" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Designation</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Designation" name="product_code" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Time & Dates</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Time & Dates" name="product_code" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    <button type="submit" class="btn btn-success-custom">Add Income</button>
                  </div>
                  <div class="col-sm-3">
                    <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </form> 
            </div>
          </div>


        </div>
      </div>
    </div>
  </div>


<!--modal for customer add-->


    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="accounts-sales.php">Sales</a></li>
            <li><a href="accounts-expense.php">Expense</a></li>
            <li class="active"><a href="accounts-income.php">Income</a></li>
            <li><a href="accounts-due.php">Transaction</a></li>
            <li><a href="accounts-customer-panel.php">Dealer Panel</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-12">
              <form class="form-inline"  name="data_search" id="data_search" action="" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="default">Income Source</label>
                  <input type="text" name="category_name" onkeypress="changeFunc();" class="form-control" placeholder="e.g. T-shirt" list="languages" id="default">
                  <datalist id="languages">

                    <?php 
                    $sql = "SELECT DISTINCT income_description, income_source FROM tbl_income_source";
                    $info = $obj_admin->manage_all_info($sql);
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  ?>

                    <option value="<?php echo $row['income_source']; ?>">
                  <?php 
                    }
                  ?>
                    
                  </datalist>
                </div>
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <button type="submit" class="btn btn-default">Submit</button>
              </form> 
            </div>
          </div>
          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Income Source</th>
                  <th>Description</th>
                  <th>Amount</th>
                  <th>Responsible Person</th>
                  <th>Designation</th>
                  <th>Time & Dates</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                  $sql = "SELECT * FROM tbl_income_source order by income_id desc";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $total_income = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td>Product Sale</td>
                  <td><?php echo "Product Name: ". $row['income_source']."<br>" ."Product_code: ".$row['income_description']; ?></td>
                  <td><?php 
                  $total_income += $row['income_amount'];
                  echo $row['income_amount']; ?></td>
                  <td><?php echo $row['responsible_person']; ?></td>
                  <td><?php echo $row['person_designation']; ?></td>
                  <td><?php echo $row['income_date']; ?></td>
                </tr>

                <?php } ?>

                <tr>
                  <td colspan="6">Total Income</td>
                  <td colspan="2"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_income, true);

                  echo $remain_amount;?></td>
                </tr>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

?>