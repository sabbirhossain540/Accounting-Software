<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

if(isset($_GET['delete_product'])){
  $action_id = $_GET['product_id'];
  
  $sql = "DELETE FROM tbl_product WHERE product_id = :id";
  $sent_po = "product-all.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);
}


$taransaction_id = $_GET['transaction_id'];
$transaction_type = $_GET['transaction_type'];
$account_id = $_GET['account_id'];

if(isset($_POST['update_transaction_info'])){
  //$obj_admin->update_bank_deposit_or_withdraw($_POST,$transaction_type,$taransaction_id,$account_id);
}

$page_name="Banking";
include("include/header.php");

?>


<div class="row">
  <div class="col-md-12">
    <div class="well well-custom">

      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="well">
            <div class="gap"></div>
            <div class="row">
              <div class="col-md-6 col-md-offset-3">
                <div class="btn-group btn-group-justified">
                  
                  <div class="btn-group">
                    <a href="admin-banking.php" class="btn btn-success">Banking Home</a>
                  </div>
                  <div class="btn-group">
                    <a href="admin-banking-accounts.php" class="btn btn-success">Manage Account</a>
                  </div>
                  <div class="btn-group">
                    <a href="admin-banking-transactions.php" class="btn btn-success">Manage Transaction</a>
                  </div>
                </div>
              </div>
            </div>
            <h1 class="text-center">Transaction Information Update</h1>
            <?php 
                $sql = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
                $info = $obj_admin->manage_all_info($sql);
                $row = $info->fetch(PDO::FETCH_ASSOC);

            ?>
            <h3 class="text-center bg-primary" style="padding: 7px;">Account Name: <?php echo $row['account_name']; ?><br>Acc. No: <?php echo $row['account_number']; ?></h3><br>
            <div class="row">
              <div class="col-md-12">
                <form role="form" action="" name="edit_transaction" method="post" autocomplete="off">
                  <div class="form-horizontal">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Transaction Type</label>
                      <div class="col-sm-7">
                        <select id="transaction_type" name="transaction_type"class="form-control input-custom" required>
                          <option value="">Select</option>
                          <option value="Withdrawal">Withdrawal</option>
                          <option value="Deposit" selected>Deposit</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-4">Account Name</label>
                      <div class="col-sm-7">
                        <select class="form-control input-custom with-dep-both" name="account_id" id="account_id">
                          <option value="">Select</option>
                          <?php 
                          $sql = "SELECT * FROM tbl_bank_account";
                          $info = $obj_admin->manage_all_info($sql);
                          
                          while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                            
                          
                          ?>
                          <option value="<?php echo $row['account_id']; ?>"><?php echo $row['account_name']." (". $row['account_number'].")"; ?></option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                    <?php 

                    
                      $sql = "SELECT * FROM tbl_balance_withdraw WHERE withdraw_id = '$taransaction_id' ";
                      $info = $obj_admin->manage_all_info($sql);
                      $row = $info->fetch(PDO::FETCH_ASSOC);
                      ?>
                      <div class="form-group">
                      <label class="control-label col-sm-4">Purpose</label>
                      <div class="col-sm-7">
                        <input type="text" placeholder="Enter Purpose" name="withdraw_purpose" class="form-control input-custom with-only" value="<?php echo $row['withdraw_purpose']; ?>" required>
                      </div>
                    </div>
                    

                    <?php
                      if($transaction_type == "Withdrawal"){
                      $sql = "SELECT * FROM tbl_balance_withdraw WHERE withdraw_id = '$taransaction_id' ";
                      $info = $obj_admin->manage_all_info($sql);
                      $row = $info->fetch(PDO::FETCH_ASSOC);
                    ?>
                      <div class="form-group">
                      <label class="control-label col-sm-4">Ammount</label>
                      <div class="col-sm-7">
                        <input type="number" placeholder="Enter Ammount" name="transaction_amount" class="form-control input-custom with-dep-both" value="<?php echo $row['withdraw_amount'];?>" required>
                      </div>
                    </div>
                    <?php

                    }else if($transaction_type == "Deposit"){
                      $sql = "SELECT * FROM tbl_bank_deposit WHERE transaction_id = '$taransaction_id' ";
                      $info = $obj_admin->manage_all_info($sql);
                      $row = $info->fetch(PDO::FETCH_ASSOC);
                    ?>
                      <div class="form-group">
                      <label class="control-label col-sm-4">Ammount</label>
                      <div class="col-sm-7">
                        <input type="number" placeholder="Enter Ammount" name="transaction_amount" class="form-control input-custom with-dep-both" value="<?php echo $row['deposit_amount'];?>" required>
                      </div>
                    </div>
                    <?php 
                    }
                    ?>
                    
                    
                    <div class="form-group">
                    </div>
                    <div class="form-group">
                      <div class="col-sm-offset-4 col-sm-3">
                        <button type="submit" name="update_transaction_info" class="btn btn-success-custom with-dep-both">Update</button>
                      </div>
                    </div>
                  </div>
                </form> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php

include("include/footer.php");

?>

<script>
    document.forms['edit_transaction'].elements['transaction_type'].value='<?php echo $transaction_type; ?>';
    document.forms['edit_transaction'].elements['account_id'].value='<?php echo $account_id; ?>';
</script>


<script type="text/javascript">

if($( "#transaction_type" ).val()=="Deposit"){
    $( ".with-only" ).attr("disabled",""); 
}else{
    $( ".with-only" ).removeAttr("disabled","");
}

$( "#transaction_type" ).change(function() {
  if($( "#transaction_type" ).val()=="Deposit"){
    $( ".with-dep-both" ).removeAttr("disabled","");
    $( ".with-only" ).attr("disabled",""); 
  }else if($( "#transaction_type" ).val()=="Withdrawal"){
    $( ".with-only" ).removeAttr("disabled","");
  }
});

</script>
