<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

if(isset($_GET['delete_product'])){
  $action_id = $_GET['product_id'];
  
  $sql = "DELETE FROM tbl_product WHERE product_id = :id";
  $sent_po = "product-all.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);
}


if(isset($_POST['add_bank_account'])){
    $obj_admin->add_new_bank_account($_POST);
}

if(isset($_POST['add_account_transaction'])){
    $obj_admin->add_bank_deposit_or_withdraw($_POST);
}

$page_name="Banking";
include("include/header.php");

// find total available balance 

$sql = "SELECT * FROM tbl_bank_account";
$info = $obj_admin->manage_all_info($sql);
$total_available_balance = 0.00;
$total_withdraw = 0.00;
$due_remain = 0.00;
while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
  $total_available_balance += $row['available_balance'];
}

// total withdraw 

$sql = "SELECT * FROM tbl_balance_withdraw";
$info = $obj_admin->manage_all_info($sql);
while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
  $total_withdraw += $row['withdraw_amount'];
}

$total_deposit = $total_available_balance + $total_withdraw;

?>


<!--modal for account add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog add-category-modal">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Account</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form role="form" action="" method="post" autocomplete="off">
                <div class="form-horizontal">
                  <div class="form-group">
                    <label class="control-label col-sm-5">Account Name</label>
                    <div class="col-sm-7">
                      <input type="text" placeholder="Enter Account Name" name="account_name" list="expense" class="form-control input-custom" id="default" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5">Account No</label>
                    <div class="col-sm-7">
                      <input type="text" placeholder="Enter Account No" name="account_number" class="form-control input-custom" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5">Available Balance</label>
                    <div class="col-sm-7">
                      <input type="number" placeholder="Enter Available Balance" name="available_balance" class="form-control input-custom" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5">Bank Name</label>
                    <div class="col-sm-7">
                      <input type="text" placeholder="Enter Bank Name (Branch)" name="bank_name" class="form-control input-custom" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5">Bank Contact</label>
                    <div class="col-sm-7">
                      <input type="text" placeholder="Enter Bank Contact" name="bank_contact" class="form-control input-custom" required>
                    </div>
                  </div>
                  <div class="form-group">
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-3">
                      <button type="submit" name="add_bank_account" class="btn btn-success-custom">Add Account</button>
                    </div>
                    <div class="col-sm-3">
                      <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                    </div>
                  </div>
                </div>
              </form> 
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

<!--modal for account add-->


<!--modal for transaction add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog add-category-modal">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Transaction</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form role="form" action="" method="post" autocomplete="off">
                <div class="form-horizontal">
                  <div class="form-group">
                    <label class="control-label col-sm-5">Transaction Type</label>
                    <div class="col-sm-7">
                      <select id="transaction_type" name="transaction_type"class="form-control input-custom" required>
                        <option value="">Select</option>
                        <option value="Withdrawal">Withdrawal</option>
                        <option value="Deposit">Deposit</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5">Account Name</label>
                    <div class="col-sm-7">
                      <?php 
                        $sql = "SELECT * FROM tbl_bank_account";
                        $info = $obj_admin->manage_all_info($sql);   
                      ?>
                      <select class="form-control input-custom with-dep-both" name="account_id" required>
                        <option value="">Select</option>

                        <?php while($row = $info->fetch(PDO::FETCH_ASSOC)){ ?>
                        <option value="<?php echo $row['account_id']; ?>"><?php echo $row['account_name']; ?></option>
                        <?php } ?>

                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5">Purpose</label>
                    <div class="col-sm-7">
                      <input type="text" placeholder="Whom :: Purpose" name="withdraw_purpose" class="form-control input-custom with-only" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5">Ammount</label>
                    <div class="col-sm-7">
                      <input type="number" placeholder="Enter Ammount" name="transaction_amount" class="form-control input-custom with-dep-both" required>
                    </div>
                  </div>
                  <div class="form-group">
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-3">
                      <button type="submit" name="add_account_transaction" class="btn btn-success-custom with-dep-both">Add</button>
                    </div>
                    <div class="col-sm-3">
                      <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                    </div>
                  </div>
                </div>
              </form> 
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

<!--modal for transaction add-->



    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="btn-group">
                <div class="btn-group">
                  <button class="btn btn-success btn-menu" data-toggle="modal" data-target="#myModal">Add Account</button>
                </div>
                <div class="btn-group">
                  <button class="btn btn-success btn-menu" data-toggle="modal" data-target="#myModal2">Add Transaction</button>
                </div>
                <div class="btn-group">
                  <a href="admin-banking-accounts.php" class="btn btn-success  btn-menu">Manage Account</a>
                </div>
                <div class="btn-group">
                  <a href="admin-banking-transactions.php" class="btn btn-success  btn-menu">Manage Transaction</a>
                </div>
              </div>
            </div>
          </div>
          <div class="gap"></div>



          <div class="row">
            <div class="col-md-4 col-sm-4">
              <div class="well">
                <h4>Total <span class="banking-avail">Available:</span> <?php echo $obj_admin->formatMoney($total_available_balance, true); ?> BDT</h4>
              </div>
            </div>
            <div class="col-md-4 col-sm-4">
              <div class="well">
                <h4>Total <span class="banking-wid">Withdraw:</span> <?php echo $obj_admin->formatMoney($total_withdraw, true); ?> BDT</h4>
              </div>
            </div>
            <div class="col-md-4 col-sm-4">
              <div class="well">
                <h4>Total <span class="banking-dep">Deposit:</span> <?php echo $obj_admin->formatMoney($total_deposit, true); ?> BDT</h4>
              </div>
            </div>
          </div>
          <div class="gap"></div>

          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Account Name</th>
                  <th>Account No.</th>
                  <th>Bank Name</th>
                  <th>Withdraw</th>
                  <th>Current Balance</th>
                  <th>Statement</th>
                </tr>
              </thead>
              <tbody>

              <?php 
                $sql = "SELECT * FROM tbl_bank_account";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="7">No Data found</td></tr>';
                  }
                  $total_amount = 0.00;
                  $total_paid = 0.00;
                  $due_remain = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['account_name']; ?></td>
                  <td><?php echo $row['account_number']; ?></td>
                  <td><?php echo $row['bank_name']; ?></td>

                  <td>
                  <?php 
                    $account_id = $row['account_id'];
                    $withdraw_amount = 0.00;
                    $sql_withdraw = "SELECT * FROM tbl_balance_withdraw WHERE account_id = '$account_id' ";
                    $info_withdraw = $obj_admin->manage_all_info($sql_withdraw);
                    while($row1 = $info_withdraw->fetch(PDO::FETCH_ASSOC)){
                      $withdraw_amount += $row1['withdraw_amount'];
                    }
                    echo $obj_admin->formatMoney($withdraw_amount, true);
                  ?>
                  </td>
                  <td><?php 
                  
                  $available_balance = $row['available_balance'];

                  
                  
                  echo $obj_admin->formatMoney($available_balance, true); ?></td>
                  <td>
                  <a title="View" href="admin-banking-details.php?account_id=<?php echo $row['account_id'];?>"><span class="glyphicon glyphicon-folder-open"></span></a>
                </tr>
                <?php } ?>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");



?>

<script type="text/javascript">

$( ".with-dep-both" ).attr("disabled","");
$( ".with-only" ).attr("disabled",""); 

$( "#transaction_type" ).change(function() {
  if($( "#transaction_type" ).val()=="Withdrawal"){
    $( ".with-dep-both" ).removeAttr("disabled","");
    $( ".with-only" ).removeAttr("disabled","");
  }else if($( "#transaction_type" ).val()=="Deposit"){
    $( ".with-dep-both" ).removeAttr("disabled","");
    $( ".with-only" ).attr("disabled",""); 
  }else{
    $( ".with-dep-both" ).attr("disabled","");
    $( ".with-only" ).attr("disabled",""); 
  }
});

</script>