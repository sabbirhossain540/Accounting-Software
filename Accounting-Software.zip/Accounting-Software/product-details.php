
<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}
// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  //header('Location: sale-now.php');
}

$product_id = $_GET['product_id'];

if(!$product_id){
  header('Location: product-all.php');
}


$sql = "SELECT * FROM tbl_product WHERE product_id='$product_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);
             
$page_name="Products";
include("include/header.php");

?>


    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="product-available.php">Available</a></li>
            <li><a href="product-stocked.php">Low Stock</a></li>
            <li><a href="product-all.php">All</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="well">
                <h3 class="text-center bg-primary" style="padding: 7px;">Product Details </h3>

                <div class="table-responsive">
                  <table class="table table-bordered table-single-product">
                    <tbody>
                      <tr>
                        <td>Product Name</td><td><?php echo $row['product_name']; ?></td>
                      </tr>
                      <tr>
                        <td>Product Code</td><td><?php echo $row['product_code']; ?></td>
                      </tr>
                      <tr>
                        <td>Product Category</td><td><?php 
                        $pro_cat = $row['product_category'];
                        $sql_cat = "SELECT * FROM tbl_product_category WHERE category_id='$pro_cat' ";
                        $info_cat = $obj_admin->manage_all_info($sql_cat);
                        $row_cat = $info_cat->fetch(PDO::FETCH_ASSOC);
                        echo $row_cat['category_name']; ?></td>
                      </tr>
                      <tr>
                        <td>Product Unit Sale Price</td><td><?php echo $row['unit_sale_price']; ?></td>
                      </tr>
                      <tr>
                        <td>Wholesale minimum Amount</td><td><?php echo $row['unit_per_lot']; ?></td>
                      </tr>
                      <tr>
                        <td>Wholesale Price</td><td><?php echo $row['lot_sale_price']; ?></td>
                      </tr>
                      <tr>
                        <td>Product Initial Quantity</td><td><?php echo $row['initial_product_quantity']; ?></td>
                      </tr>
                      <tr>
                        <td>Product Currrent Quantity</td><td><?php echo $row['product_total_quantity']; ?></td>
                      </tr>
                      <tr>
                        <td>Product Incoming Date</td><td><?php echo $row['product_incoming_date']; ?></td>
                      </tr>
                      <tr>
                        <td>Product Expired Date</td><td><?php echo $row['product_expire_date']; ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

?>