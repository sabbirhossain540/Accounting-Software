<?php
require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

$page_name="Admin";
include("include/header.php");

?>
    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li class="active"><a href="admin-account-panel.php">Account Details</a></li>
            <li><a href="manage-admin.php">Manage Admin</a></li>
            <li><a href="admin-manage-salesman.php">Manage Salesman</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-5">
              <div class="panel panel-default admin-custom">
                <div class="panel-heading tsale">
                  <h3>Total <span>Sale</span></h3>
                </div>
                
                <div class="panel-body">
                  <span>Total:</span> 
                  <?php 
                  /* total sale  */
                  $sql = "SELECT * FROM tbl_sales_product order by sale_id desc";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_sales = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_sales += $row['total_sale_price'];

                  }
                  $remain_amount = $obj_admin->formatMoney($total_sales, true);
                  echo $remain_amount." BDT";

                  ?>
                  <br>
                  <span>Last 30 days:</span> 
                  <?php 

                  $end_date = date('d-m-Y', strtotime('-30 days'));
                  //$end = '12-10-2017';
                  $start_date = date('d-m-Y');
                  $bt_start_date = date('d-m-Y',strtotime('+1 days'));

                  // change date format
                  $start_date_year = substr($start_date, 6, 4);
                  $start_date_month = substr($start_date, 3, 2);
                  $start_date_day = substr($start_date, 0, 2);
                  $new_start_date = $start_date_year.'-'.$start_date_month.'-'.$start_date_day;

                  // new betheen start date 
                  $bt_start_date_year = substr($bt_start_date, 6, 4);
                  $bt_start_date_month = substr($bt_start_date, 3, 2);
                  $bt_start_date_day = substr($bt_start_date, 0, 2);
                  $bt_new_start_date = $bt_start_date_year.'-'.$bt_start_date_month.'-'.$bt_start_date_day;


                  // end date 
                  $end_date_year = substr($end_date, 6, 4);
                  $end_date_month = substr($end_date, 3, 2);
                  $end_date_day = substr($end_date, 0, 2);
                  $new_end_date = $end_date_year.'-'.$end_date_month.'-'.$end_date_day;
                  //echo gettype($end_date);

                  $sql1 = "SELECT * FROM tbl_sales_product WHERE product_sale_date BETWEEN '$new_end_date' AND '$new_start_date' ";
                  $info1 = $obj_admin->manage_all_info($sql1);
                  $total_sales = 0.00;
                  while( $row = $info1->fetch(PDO::FETCH_ASSOC) ){
                    $total_sales += $row['total_sale_price'];
                    //echo "string";
                  }
                  $remain_amount = $obj_admin->formatMoney($total_sales, true);
                  echo $remain_amount." BDT";
                  
                  ?>
                  <br>
                  <span>Today:</span> 
                  <?php 

                  /* total sale count of last 30 days */
                  $sql = "SELECT * FROM tbl_sales_product WHERE product_sale_date = '$new_start_date' ";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_sales = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_sales += $row['total_sale_price'];

                  }
                  $remain_amount = $obj_admin->formatMoney($total_sales, true);
                  echo $remain_amount." BDT";

                  ?>
                  
                </div>
                <div class="panel-footer">
                  <a href="accounts-sales.php">Details</a>
                </div>
              </div>
            </div>
            <div class="col-md-5 col-md-offset-1">
              <div class="panel panel-default admin-custom">
                <div class="panel-heading tdue">
                  <h3>Total <span>Due</span></h3>
                </div>
                <div class="panel-body">
                  <span>Total:</span> 
                  <?php 
                  /* total sale  */
                  $sql = "SELECT * FROM tbl_customer_due order by due_id desc";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_due = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_due += $row['due_remain'];

                  }
                  $remain_amount = $obj_admin->formatMoney($total_due, true);
                  echo $remain_amount." BDT";

                  ?>
                  <br>
                  <span>Last 30 days:</span> 
                  <?php 

                  /* total sale count of last 30 days */
                  

                  $sql1 = "SELECT * FROM tbl_customer_due WHERE sale_date BETWEEN '$new_end_date' AND '$bt_new_start_date' ";
                  $info1 = $obj_admin->manage_all_info($sql1);
                  $total_due = 0.00;
                  while( $row = $info1->fetch(PDO::FETCH_ASSOC) ){
                    $total_due += $row['due_remain'];
                    //echo "string";
                  }
                  $remain_amount = $obj_admin->formatMoney($total_due, true);
                  echo $remain_amount." BDT";
                  
                  ?>
                  <br>
                  <span>Today:</span> 
                  <?php 

                  /* total sale count of last 30 days */
                  $sql = "SELECT * FROM tbl_customer_due WHERE sale_date LIKE '$new_start_date%' ";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_due = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_due += $row['due_remain'];

                  }
                  $remain_amount = $obj_admin->formatMoney($total_due, true);
                  echo $remain_amount." BDT";

                  ?>
                </div>
                <div class="panel-footer">
                  <a href="accounts-due.php">Details</a>
                </div>
              </div>
            </div>
            <div class="col-md-5">
              <div class="panel panel-default admin-custom">
                <div class="panel-heading tprofit">
                  <h3>Total <span>Profit</span></h3>
                </div>
                <div class="panel-body">
                  <span>Total:</span> 
                  <?php 
                  /* total sale  */
                  $sql = "SELECT * FROM tbl_expense_source";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_expense = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_expense += $row['expense_amount'];

                  }
                 
                  $sql = "SELECT * FROM tbl_sales_product order by sale_id desc";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_sales = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_sales += $row['total_sale_price'];

                  }
                  
                  $total_profit = $total_sales - $total_expense;
                  if($total_profit < 0){
                    $total_profit = 0.00;
                  }
                  $total_profit = $obj_admin->formatMoney($total_profit, true);
                  echo $total_profit." BDT";

                  ?>
                  <br>
                  <span>Last 30 days:</span> 
                  <?php 

                  $sql1 = "SELECT * FROM tbl_expense_source WHERE expense_date BETWEEN '$new_end_date' AND '$bt_new_start_date' ";
                  $info1 = $obj_admin->manage_all_info($sql1);
                  $total_expense = 0.00;
                  while( $row = $info1->fetch(PDO::FETCH_ASSOC) ){
                    $total_expense += $row['expense_amount'];
                    //echo "string";
                  }

                  
                  $sql1 = "SELECT * FROM tbl_sales_product WHERE product_sale_date BETWEEN '$new_end_date' AND '$new_start_date' ";
                  $info1 = $obj_admin->manage_all_info($sql1);
                  $total_sales = 0.00;
                  while( $row = $info1->fetch(PDO::FETCH_ASSOC) ){
                    $total_sales += $row['total_sale_price'];
                    //echo "string";
                  }

                  $total_profit = $total_sales - $total_expense;
                  if($total_profit < 0){
                    $total_profit = 0.00;
                  }

                  $total_profit = $obj_admin->formatMoney($total_profit, true);

                  echo $total_profit." BDT";
                  
                  ?>
                  <br>
                  <span>Today:</span> 
                  <?php 

                  /* total sale count of last 30 days */
                  $sql = "SELECT * FROM tbl_expense_source WHERE expense_date LIKE '$new_start_date%' ";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_expense = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_expense += $row['expense_amount'];

                  }

                  $sql = "SELECT * FROM tbl_sales_product WHERE product_sale_date = '$new_start_date' ";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_sales = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_sales += $row['total_sale_price'];

                  }
                  $total_profit = $total_sales - $total_expense;
                  if($total_profit < 0){
                    $total_profit = 0.00;
                  }
                  $total_profit = $obj_admin->formatMoney($total_profit, true);
                  echo $total_profit." BDT";

                  ?>
                </div>
                <div class="panel-footer">
                  <a href="admin-account-profit.php">Details</a>
                </div>
              </div>
            </div>
            <div class="col-md-5 col-md-offset-1">
              <div class="panel panel-default admin-custom">
                <div class="panel-heading texpense">
                  <h3>Total <span>Expense</span></h3>
                </div>
                <div class="panel-body">
                  <span>Total:</span> 
                  <?php 
                  /* total sale  */
                  $sql = "SELECT * FROM tbl_expense_source";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_expense = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_expense += $row['expense_amount'];

                  }
                  $remain_amount = $obj_admin->formatMoney($total_expense, true);
                  echo $remain_amount." BDT";

                  ?>
                  <br>
                  <span>Last 30 days:</span> 
                  <?php 

                  $sql1 = "SELECT * FROM tbl_expense_source WHERE expense_date BETWEEN '$new_end_date' AND '$new_start_date' ";
                  $info1 = $obj_admin->manage_all_info($sql1);
                  $total_due = 0.00;
                  while( $row = $info1->fetch(PDO::FETCH_ASSOC) ){
                    $total_due += $row['expense_amount'];
                    //echo "string";
                  }
                  $remain_amount = $obj_admin->formatMoney($total_due, true);
                  echo $remain_amount." BDT";
                  
                  ?>
                  <br>
                  <span>Today:</span> 
                  <?php 

                  /* total sale count of last 30 days */
                  $sql = "SELECT * FROM tbl_expense_source WHERE expense_date LIKE '$new_start_date%' ";
                  $info = $obj_admin->manage_all_info($sql);
                  $total_due = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_due += $row['expense_amount'];

                  }
                  $remain_amount = $obj_admin->formatMoney($total_due, true);
                  echo $remain_amount." BDT";

                  ?>
                </div>
                <div class="panel-footer">
                  <a href="accounts-expense.php">Details</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

?>