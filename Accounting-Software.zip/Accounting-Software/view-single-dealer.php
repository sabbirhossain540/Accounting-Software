<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}
// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

$customer_id = $_GET['customer_id'];

if(isset($_POST['add_permanent_customer'])){
    $obj_admin->add_new_permanent_customer($_POST);
}

$page_name="Dealers";
include("include/header.php");

?>

<script type="text/javascript">

   function changeFunc() {

     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/accounts-customer-panel.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>

<!--modal for customer add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      
    </div>
  </div>


<!--modal for customer add-->

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li class="active"><a href="accounts-customer-panel.php">Dealer Panel</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="well">
                <h3 class="text-center bg-primary" style="padding: 7px;">Dealer Details </h3>
                <?php 
                  $sql = "SELECT * FROM tbl_permanent_customer WHERE customer_id = '$customer_id' ";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $total_expense = 0.00;
                  $row = $info->fetch(PDO::FETCH_ASSOC);
                ?>
                <div class="table-responsive">
                  <table class="table table-bordered table-single-product">
                    <tbody>
                      <tr>
                        <td>Dealer Name</td><td><?php echo $row['customer_name']; ?></td>
                      </tr>
                      <tr>
                        <td>Dealer Contact</td><td><?php echo $row['customer_contact']; ?></td>
                      </tr>
                      <tr>
                        <td>Dealer E-mail</td><td><?php echo $row['customer_email']; ?></td>
                      </tr>
                      <tr>
                        <td>Other Description</td><td><?php echo $row['customer_description']; ?></td>
                      </tr>

                      
                    </tbody>
                  </table>
                </div>

                
              </div>
            </div>
          </div>
          <div class="row">
          </div>
          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Sale Date</th>
                  <th>sale Amount</th>
                  <th>Paid Amount</th>
                  <th>Due Amount</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                <?php 
                  $sql = "SELECT * FROM tbl_customer_due WHERE customer_id = '$customer_id' ";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $sale_total = 0.00;
                  $paid_total = 0.00;
                  $due_total = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['sale_date'];?></td>
                  <td><?php $sale_total += $row['total_amount'];
                    echo $obj_admin->formatMoney($row['total_amount'], true);
                  ?></td>
                  <td><?php $paid_total += $row['total_paid'];
                    echo $obj_admin->formatMoney($row['total_paid'], true);

                  ?></td>
                  <td><?php $due_total += $row['due_remain'];
                    echo $obj_admin->formatMoney($row['due_remain'], true);
                  ?></td>
                  <td>
                  <a title="Due Adjust" href="pay-due.php?due_id=<?php echo $row['due_id']; ?>"><span class="glyphicon glyphicon-adjust"></span></a></td>
                </tr>
                <?php } ?>
                <tr>
                  <td colspan="2">Total</td>
                  <td ><?php 
                   $remain_amount = $obj_admin->formatMoney($sale_total, true);

                  echo $remain_amount;?></td>
                  <td>
                    <?php 
                      echo $obj_admin->formatMoney($paid_total, true);
                    ?>
                  </td>
                  <td>
                    <?php 
                      echo $obj_admin->formatMoney($due_total, true);
                    ?>
                  </td>
                  <td></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

if(isset($_SESSION['add_permanent_customer'])){
  echo '<script>alert("New Customer Added Successfully");</script>';
  unset($_SESSION['add_permanent_customer']);
}

include("include/footer.php");

if(isset($_SESSION['due_fully_paid'])){
  echo '<script>alert("Due Paid Successfully");</script>';
  unset($_SESSION['due_fully_paid']);
}

if(isset($_SESSION['due_partially_paid'])){
  echo '<script>alert("Due Partially Paid Successfully");</script>';
  unset($_SESSION['due_partially_paid']);
}

?>