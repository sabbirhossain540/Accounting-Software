<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

if(isset($_POST['add_supplier_trans'])){
    $obj_admin->add_supplier_product_transaction($_POST);
}

if(isset($_GET['delete_supplier_trans'])){
  $product_id = $_GET['product_id'];
  
  $obj_admin->delete_supplier_product_transaction($product_id);

}

$page_name="Suppliers";
include("include/header.php");

?>

<script type="text/javascript">

   function changeFunc() {

     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/accounts-supplier-product.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>


<!-- moddal for product category add -->

  <!-- Modal -->
  <div class="modal fade" id="catModal" role="dialog" style="z-index: 2000">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Category</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                <div class="form-group">
                  <label class="control-label col-sm-5">Category Name</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Product Name" name="category_name" list="expense" class="form-control input-custom" id="default" required>
                  </div>
                </div>
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    <button type="submit" name="add_new_category" class="btn btn-success-custom">Add Category</button>
                  </div>
                  <div class="col-sm-3">
                    <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- moddal for product category add -->

<!--modal for supplier product add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg add-category-modal">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Product</h2>

          <div class="pull-right">
            <label class="radio-inline">
              <input type="radio" value="self" name="use_of_product" checked>Self Use
            </label>
            <label class="radio-inline">
              <input type="radio" value="sale" name="use_of_product">For Sale
            </label>
          </div>
          

        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form role="form" action="" method="post" autocomplete="off">
                <div class="form-horizontal">
                  <div class="row">
                    <div class="col-md-6">
                      
                      <div class="form-group">
                        <label class="control-label col-sm-5">Supplier Name</label>
                        <div class="col-sm-7">
                          <input type="text" placeholder="Enter Supplier Name" name="supplier_name" list="languages" class="form-control input-custom" id="default" required>
                          <datalist id="languages">
                          <?php 
                            $sql = "SELECT * FROM tbl_add_supplier";
                            $info = $obj_admin->manage_all_info($sql);
                            while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                          ?>

                          <option value="<?php echo $row['supplier_name']; ?>/<?php echo $row['supplier_id']; ?>">
                          <?php 
                            }
                          ?>        
                        </datalist>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Product Name</label>
                        <div class="col-sm-7">
                          <input type="text" placeholder="Enter Product Name" name="product_name" list="expense" class="form-control input-custom" id="default" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Product Code</label>
                        <div class="col-sm-7">
                          <input type="text" placeholder="Enter Product Code" name="product_code" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group for-sale">
                        <div class='cat-action'>
                          <a class="action-button" style="padding:2px 0px 3px 8px;" data-toggle="modal" data-target="#catModal"><span class='glyphicon glyphicon-plus plus-rotate'></span></a>
                        </div>
                        <label class="control-label col-sm-5">Category</label>
                        <div class="col-sm-7">
                          <select name="product_category" class="form-control input-custom for-sale-input" required>
                          <?php 
                            $sql = "SELECT * FROM tbl_product_category";
                            $info = $obj_admin->manage_all_info($sql);
                            while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                          ?>
                            <option value="<?php echo $row['category_id']; ?>"><?php echo $row['category_name']; ?></option>
                          <?php 
                            }
                          ?>
                          </select>
                          
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Actual Price</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Actual Price" name="original_price" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Discount</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Discount" name="discount_amount" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Due</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Due" name="due_amount" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Short Description</label>
                        <div class="col-sm-7">
                          <input type="text" placeholder="Enter Short Description" name="short_description" list="expense" class="form-control input-custom" id="default" required>
                        </div>
                      </div>
                    </div>

                    <div class="col-md-6">

                      <div class="form-group for-sale">
                        <label class="control-label col-sm-5">Unit Sale Price</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Unit sale Price" name="unit_sale_price" class="form-control input-custom for-sale-input" required>
                        </div>
                      </div>
                      <div class="form-group for-sale">
                        <label class="control-label col-sm-5">Whole Sale Quantity</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Number of Unit" name="whole_sale_quantity" class="form-control input-custom for-sale-input" required>
                        </div>
                      </div>
                      <div class="form-group for-sale">
                        <label class="control-label col-sm-5">Whole Sale Price</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Whole Sale Price" name="whole_sale_price" class="form-control input-custom for-sale-input" required>
                        </div>
                      </div>
                      
                      <div class="form-group">
                        <label class="control-label col-sm-5">Product Total Quantity</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Product Total Quantity" name="product_total_quantity" class="form-control input-custom" required>
                        </div>
                      </div>
                      <div class="form-group for-sale">
                        <label class="control-label col-sm-5">Total Product Buying Price</label>
                        <div class="col-sm-7">
                          <input type="number" placeholder="Enter Total Product Buying Price" name="total_product_buying_price" class="form-control input-custom for-sale-input" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Incoming Date</label>
                        <div class="col-sm-7">
                          <!-- <input type="text" placeholder="Enter Product Incoming Date" name="product_incoming_date" class="form-control input-custom" required> -->
                          <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                              <input class="form-control input-custom" type="text" name="product_incoming_date" placeholder="Enter Product Incoming Date" required>
                              <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                          </div>

                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-5">Expire Date</label>
                        <div class="col-sm-7">
                          <!-- <input type="text" placeholder="Enter Product Expire Date" name="product_expire_date" class="form-control input-custom" required> -->
                          <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                              <input class="form-control input-custom" type="text" name="product_expire_date" placeholder="Enter Product Expire Date" required>
                              <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                          </div>

                        </div>
                      </div>

                    </div>
                  </div>
                  
                  <div class="form-group">
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-3">
                      <button type="submit" name="add_supplier_trans" class="btn btn-success-custom">Add Product</button>
                    </div>
                    <div class="col-sm-3">
                      <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                    </div>
                  </div>
                </div>
              </form> 
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

<div class='multi-action'>
  <button class="action-button" data-toggle="modal" data-target="#myModal"><span class='glyphicon glyphicon-plus plus-rotate'></span></button>
</div>

<!--//modal for supplier product add-->

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="accounts-supplier-panel.php">Manage Supplier</a></li>
            <li class="active"><a href="accounts-supplier-product.php">Manage Supplier Product</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-12">
              <form class="form-inline" action="" name="data_search" id="data_search" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="default">Supplier Name</label>
                  <input type="text" class="form-control" name="category_name" onkeypress="changeFunc();" placeholder="e.g. Biscuit/B-102" list="languages" id="default">
                  <datalist id="languages">
                    <datalist id="languages">
                    <?php 
                    $sql = "SELECT * FROM tbl_permanent_customer";
                    $info = $obj_admin->manage_all_info($sql);
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  ?>
                    <option value="<?php echo $row['customer_name']; ?>">
                  <?php 
                    }
                  ?>
                  </datalist>
                </div>
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker3" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker4" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                
              </form> 
            </div>
          </div>
          <div class="gap"></div>
          <div class="table-responsive">

            <table class="table table-codensed table-custom">
              <?php 
              $sql = "SELECT * FROM tbl_supplier_product";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $total_amount = 0.00;
                  $total_paid = 0.00;
                  $due_remain = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_amount += $row['due_amount'];
                    
                  }
            ?>
            <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Due :
              <?php echo $obj_admin->formatMoney($total_amount, true); ?> BDT  </caption>

              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Supplier Name</th>
                  <th>Supplier Contact</th>
                  <th>Supplier Product</th>
                  <th>Product Code</th>
                  <th>Quantity</th>
                  <th>Due</th>
                  <th>Incoming Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                <?php 
                  $sql = "SELECT * FROM tbl_supplier_product order by product_id desc";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="9">No Data found</td></tr>';
                  }
                  $total_expense = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                    $supplier_id = $row['supplier_id'];
                    $sql_sup = "SELECT * FROM tbl_add_supplier WHERE supplier_id = '$supplier_id' ";
                    $info_sup = $obj_admin->manage_all_info($sql_sup);
                    $row_sup = $info_sup->fetch(PDO::FETCH_ASSOC);
                    echo $row_sup['supplier_name'];

                  ?></td>
                  <td><?php echo $row_sup['supplier_contact']; ?></td>
                  <td><?php echo $row['product_name']; ?></td>
                  <td><?php echo $row['product_code']; ?></td>
                  <td><?php echo $row['product_quantity']; ?></td>
                  <td><?php echo $row['due_amount']; ?></td>
                  <td><?php echo $row['product_incoming_date']; ?></td>
                  <td>
                  <a title="Update Product" href="update-supplier-products.php?product_id=<?php echo $row['product_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>&nbsp;&nbsp;
                  <a title="View" href="product-details-supplier.php?product_id=<?php echo $row['product_id']; ?>"><span class="glyphicon glyphicon-folder-open"></span></a>
                 
                  &nbsp;&nbsp;<a title="Delete" href="?delete_supplier_trans=delete_supplier_trans&product_id=<?php echo $row['product_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>

                  
                  </td>
                </tr>
                <?php } ?>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

if(isset($_SESSION['update_supplier_product'])){
  echo '<script>alert("Supplier product updated");</script>';
  unset($_SESSION['update_supplier_product']);
}

if(isset($_SESSION['add_supplier_product'])){
  echo '<script>alert("Supplier Product Added");</script>';
  unset($_SESSION['add_supplier_product']);
}

?>

<script type="text/javascript">

$(".for-sale-input").removeAttr("required");
  $("input[name='use_of_product']").click(function(){

      var radioValue = $("input[name='use_of_product']:checked").val();

      if(radioValue=="sale"){
        $(".for-sale").show();
        $(".for-sale-input").attr("required","");
      }else{
        $(".for-sale-input").removeAttr("required");
        $(".for-sale").hide();
      }

  });


</script>