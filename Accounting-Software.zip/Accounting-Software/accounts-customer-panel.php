<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

if(isset($_POST['add_permanent_customer'])){
    $obj_admin->add_new_permanent_customer($_POST);
}

if(isset($_GET['delete_customer'])){
  $action_id = $_GET['customer_id'];
  $sql = "DELETE FROM tbl_permanent_customer WHERE customer_id = :id";
  $sent_po = "accounts-customer-panel.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);

}

$page_name="Dealers";
include("include/header.php");

?>

<script type="text/javascript">

   function changeFunc() {

     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/accounts-customer-panel.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>

<!--modal for customer add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Customer</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form class="form-horizontal" role="form" action="" method="post">
                <div class="form-group">
                  <label class="control-label col-sm-5">Customer Name*</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Customer Name" name="customer_name" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Contact Number*</label>
                  <div class="col-sm-7">
                    <input type="number" placeholder="Enter Customer Contact Number" name="customer_contact" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Customer Email</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Customer Email Address" name="customer_email" class="form-control input-custom">
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Customer Description</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Extra Information" name="customer_description" class="form-control input-custom">
                  </div>
                </div>
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    <button type="submit" class="btn btn-success-custom" name="add_permanent_customer">Add Customer</button>
                  </div>
                  <div class="col-sm-3">
                    <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </form> 
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>



<div class='multi-action'>
  <button class="action-button" data-toggle="modal" data-target="#myModal"><span class='glyphicon glyphicon-plus plus-rotate'></span></button>
</div>

<!--modal for customer add-->

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li class="active"><a href="accounts-customer-panel.php">Dealer Panel</a></li>
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-12">
              <form class="form-inline" action="" name="data_search" id="data_search" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="default">Customer Name</label>
                  <input type="text" class="form-control" name="category_name" onkeypress="changeFunc();" placeholder="e.g. Hashem Uddin" list="languages" id="default">
                  <datalist id="languages">
                    <datalist id="languages">
                    <?php 
                    $sql = "SELECT * FROM tbl_permanent_customer";
                    $info = $obj_admin->manage_all_info($sql);
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  ?>

                    <option value="<?php echo $row['customer_name']; ?>">
                  <?php 
                    }
                  ?>
                  </datalist>
                </div>
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                
              </form> 
            </div>
          </div>
          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Customer Name</th>
                  <th>Customer Contact</th>
                  <th>Customer Email</th>
                  <th>Customer Other Details</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                <?php 
                  $sql = "SELECT * FROM tbl_permanent_customer";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="6">No Data found</td></tr>';
                  }
                  $total_expense = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['customer_name'];?></td>
                  <td><?php echo $row['customer_contact'];?></td>
                  <td><?php echo $row['customer_email'];?></td>
                  <td><?php echo $row['customer_description'];?></td>
                  <td>
                  <a title="Update Customer" href="update-permanent-customer.php?customer_id=<?php echo $row['customer_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>&nbsp;&nbsp;
                  <a title="View" href="view-single-dealer.php?customer_id=<?php echo $row['customer_id']; ?>"><span class="glyphicon glyphicon-folder-open"></span></a>
                  <?php 
                    $customer_id = $row['customer_id'];
                    $sql_due = "SELECT * FROM tbl_customer_due WHERE customer_id = '$customer_id' ";
                    $info_due = $obj_admin->manage_all_info($sql_due);
                    $total_due = 0.00;
                    while ( $row_due = $info_due->fetch(PDO::FETCH_ASSOC) ) {
                      $total_due += $row_due['due_remain'];
                    }

                    if($total_due == 0.00){
                    
                  ?>
                  &nbsp;&nbsp;<a title="Delete" href="?delete_customer=delete_customer&customer_id=<?php echo $row['customer_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>

                  <?php 
                    }
                  ?>
                  </td>
                </tr>
                <?php } ?>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

if(isset($_SESSION['adding_permanent_customer'])){
  echo '<script>alert("Product Updated successfully");</script>';
  unset($_SESSION['adding_permanent_customer']);
}

if(isset($_SESSION['update_permanent_customer'])){
  echo '<script>alert("Customer Info Updated Successfully");</script>';
  unset($_SESSION['update_permanent_customer']);
}

?>