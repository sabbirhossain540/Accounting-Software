
<?php

require '../authentication.php';

$category = $_POST['category_name'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

//echo $category . $start_date .$end_date;
if($category == 'Dealer'){
  ?>

<table class="table table-codensed table-custom">
          <?php 
              $sql = "SELECT * FROM tbl_customer_due order by due_id desc";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $total_amount = 0.00;
                  $total_paid = 0.00;
                  $due_remain = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_amount += $row['total_amount'];
                    $total_paid += $row['total_paid'];
                    $due_remain += $row['due_remain'];
                  }
            ?>
            <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Amount :
              <?php echo $obj_admin->formatMoney($total_amount, true); ?> BDT &nbsp;&nbsp;&nbsp; Total Paid : <span style="color: #;"><?php echo $obj_admin->formatMoney($total_paid, true); ?></span> BDT &nbsp;&nbsp;&nbsp; Total Due : <?php echo $obj_admin->formatMoney($due_remain, true); ?> BDT </caption>

              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Customer Details</th>
                  <th>Product Details</th>
                  <th>Total Amount</th>
                  <th>Total Paid</th>
                  <th>Due Remain</th>
                  <th>Due Paid Date</th>
                  <th>Product Buy Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                  if( empty($start_date) OR empty($end_date) ){
                    $sql = "SELECT * FROM tbl_customer_due order by due_id desc";
                  }else{
                    $sql = "SELECT * FROM tbl_customer_due WHERE sale_date BETWEEN '$start_date' AND '$end_date' order by due_id desc ";
                  }
                  
                  
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                      echo '<tr><td colspan="9">No Data found</td></tr>';
                  }
                  $total_amount = 0.00;
                  $total_paid = 0.00;
                  $due_remain = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>

                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  $customer_id = $row['customer_id'];
                  $sql1 = "SELECT * FROM tbl_permanent_customer WHERE customer_id='$customer_id' ";
                  $info1 = $obj_admin->manage_all_info($sql1);
                  $row1 = $info1->fetch(PDO::FETCH_ASSOC);
                  echo $row1['customer_name']. "<br>";
                  echo $row1['customer_contact']. "<br>";
                  ?></td>
                  <td><?php 
                  echo $row['product_name']; ?></td>
                  <td><?php 
                    $total_amount += $row['total_amount'];
                    echo $obj_admin->formatMoney($row['total_amount'], true); ?></td>
                  <td><?php 
                  $total_paid += $row['total_paid'];
                  echo $obj_admin->formatMoney($row['total_paid'], true);  ?></td>
                  <td><?php
                  $due_remain += $row['due_remain'];
                   echo $obj_admin->formatMoney($row['due_remain'], true); ?></td>
                  <td><?php echo $row['due_paid_date']; ?></td>
                  <td><?php echo $row['sale_date']; ?></td>
                  <td><a title="Due Adjust" href="pay-due.php?due_id=<?php echo $row['due_id']; ?>"><span class="glyphicon glyphicon-adjust"></span></a>&nbsp;&nbsp;</td>
                </tr>

                <?php } ?>

                <tr>
                  <td colspan="1"></td>
                  <td colspan="3"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_amount, true);
                  echo "Total Amount: ".$remain_amount;?> BDT</td>
                  <td colspan="3"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_paid, true);
                  echo "Total Paid: ".$remain_amount;?> BDT</td>
                  <td colspan="2"><?php 
                   $remain_amount = $obj_admin->formatMoney($due_remain, true);
                  echo "Total Due: ".$remain_amount;?> BDT</td>
                  
                </tr>

              </tbody>
            </table>

  <?php
}else if($category == 'Irregular'){

?>

<table class="table table-codensed table-custom">
      <?php 
              $sql = "SELECT * FROM tbl_irregular_transaction order by transaction_id desc";;
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $total_amount = 0.00;
                  
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_amount += $row['total_amount'];
                    
                  }
            ?>
            <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Amount :
              <?php echo $obj_admin->formatMoney($total_amount, true); ?> BDT  </caption>
              
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Customer Name</th>
                  <th>Customer Contact</th>
                  <th>Product Name</th>
                  <th>P.Qty</th>
                  <th>Amount</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                  
                  
                  if( empty($start_date) OR empty($end_date) ){
                    $sql = "SELECT * FROM tbl_irregular_transaction order by transaction_id desc";
                  }else{
                    $sql = "SELECT * FROM tbl_irregular_transaction WHERE transaction_date BETWEEN '$start_date' AND '$end_date' order by transaction_id desc";
                  }
                  $info = $obj_admin->manage_all_info($sql);
                  $num_row = $info->rowCount();
                  if($num_row==0){
                      echo '<tr><td colspan="9">No Data found</td></tr>';
                  }
                  $serial  = 1;
                  $total_amount = 0.00;
                  $total_paid = 0.00;
                  $due_remain = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>

                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  echo $row['customer_name'];
                  ?></td>
                  <td><?php 
                  echo $row['customer_contact']; ?></td>
                  <td><?php 
                  echo $row['product_name']; ?></td>
                  <td><?php 
                  echo $row['product_quantity']; ?></td>
                  <td><?php 
                    $total_amount += $row['total_amount'];
                    echo $obj_admin->formatMoney($row['total_amount'], true); ?></td>
                  
                  <td><a title="Due Adjust" href="#pay-due.php?due_id=<?php echo $row['due_id']; ?>"><span class="glyphicon glyphicon-adjust"></span></a>&nbsp;&nbsp;</td>
                </tr>

                <?php } ?>

                <tr>
                  <td colspan="3">Total Amount</td>
                  <td colspan="4"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_amount, true);
                  echo $remain_amount;?> BDT</td>
                                    
                </tr>

              </tbody>
            </table>


<?php 
}

?>


