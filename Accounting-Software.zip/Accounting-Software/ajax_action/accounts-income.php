<?php

require '../authentication.php';

$category = $_POST['category_name'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

//echo $category . $start_date .$end_date;

?>
<table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Income Source</th>
                  <th>Description</th>
                  <th>Amount</th>
                  <th>Responsible Person</th>
                  <th>Designation</th>
                  <th>Time & Dates</th>
                </tr>
              </thead>
              <tbody id="table_body">

              <?php 
                $sql = "SELECT * FROM tbl_income_source WHERE income_source LIKE '%$category%' AND income_date BETWEEN  '$start_date' AND '$end_date' ";
                $info = $obj_admin->manage_all_info($sql);
                $serial  = 1;
                $total_income = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php $serial; $serial++; ?></td>
                  <td>Product Sale</td>
                  <td><?php echo "Product Name: ". $row['income_source']."<br>" ."Product_code: ".$row['income_description']; ?></td>
                  <td><?php 
                  $total_income += $row['income_amount'];
                  echo $row['income_amount']; ?></td>
                  <td><?php echo $row['responsible_person']; ?></td>
                  <td><?php echo $row['person_designation']; ?></td>
                  <td><?php echo $row['income_date']; ?></td>
                </tr>

              <?php } ?>

              <tr>
                  <td colspan="6">Total Income</td>
                  <td colspan="2"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_income, true);

                  echo $remain_amount;?></td>
              </tr>
              </tbody>
            </table>

