<?php

require '../authentication.php';

$category = $_POST['category_name'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$customer_type = $_POST['customer_type'];



if($customer_type == "Irregular"){
?>

  <table class="table table-codensed table-custom">
    <?php 
        if( empty($category) ){
            if(empty($start_date) OR empty($end_date)){
              
              $sql = "SELECT * FROM tbl_sales_product WHERE customer_type = 'Irregular' order by sale_id desc";
          }else{
            
            $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Irregular' AND product_sale_date BETWEEN  '$start_date' AND '$end_date' order by sale_id desc ";
          }
        }else if( !empty($category) ){
          if(empty($start_date) OR empty($end_date)){
            $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Irregular' AND product_name LIKE '%$category%' order by sale_id desc";
          }else{
            $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Irregular' AND product_name LIKE '%$category%' AND product_sale_date BETWEEN  '$start_date' AND '$end_date' order by sale_id desc";
          }
        }
          $info = $obj_admin->manage_all_info($sql);
          $serial  = 1;
          $total_sales = 0.00;
              while( $row = $info->fetch(PDO::FETCH_ASSOC) ){

                $total_sales += $row['total_sale_price'];
              }
        ?>
        <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Sale:
        <?php echo $obj_admin->formatMoney($total_sales, true); ?> BDT </caption>
        <thead>
          <tr>
            <th>S.N.</th>
            <th>Selling Product</th>
            <th>Customer Type</th>
            <th>Product Qty</th>
            <th>Selling Amount (BDT)</th>
            <th>Time & Dates</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="table_body">

        <?php 
          if( empty($category) ){
            if(empty($start_date) OR empty($end_date)){
              
              $sql = "SELECT * FROM tbl_sales_product WHERE customer_type = 'Irregular' order by sale_id desc";
          }else{
            
            $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Irregular' AND product_sale_date BETWEEN  '$start_date' AND '$end_date' order by sale_id desc ";
          }
        }else if( !empty($category) ){
          if(empty($start_date) OR empty($end_date)){
            $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Irregular' AND product_name LIKE '%$category%' order by sale_id desc";
          }else{
            $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Irregular' AND product_name LIKE '%$category%' AND product_sale_date BETWEEN  '$start_date' AND '$end_date' order by sale_id desc";
          }
        }

          
          $info = $obj_admin->manage_all_info($sql);
          $serial  = 1;
          $num_row = $info->rowCount();
          if($num_row==0){
                echo '<tr><td colspan="6">No Data found</td></tr>';
          }
          $total_expense = 0.00;
          while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
        ?>
          <tr>
            <td><?php echo $serial; $serial++; ?></td>
            <td><?php echo $row['product_name']; ?></td>
            <td><?php echo $row['customer_type']; ?></td>
            <td><?php echo $row['product_quantity']; ?></td>
            <td><?php echo $obj_admin->formatMoney($row['total_sale_price'], true); ?></td>
            <td><?php echo $row['sale_date']; ?></td>
            <td><a title="Delete" href="?delete_sale=delete_sale&customer_type=<?php echo $row['customer_type']?>&sale_id=<?php echo $row['sale_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a></td>
          </tr>

        <?php } ?>
        </tbody>
      </table>

<?php 
}else if($customer_type == "Dealer"){
?>

  <table class="table table-codensed table-custom">
          <?php 
              if( empty($category) ){
                  if(empty($start_date) OR empty($end_date)){
                    
                    $sql = "SELECT * FROM tbl_sales_product WHERE customer_type = 'Dealer' order by sale_id desc";
                }else{
                  
                  $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Dealer' AND product_sale_date BETWEEN  '$start_date' AND '$end_date' order by sale_id desc ";
                }
              }else if( !empty($category) ){
                if(empty($start_date) OR empty($end_date)){
                  $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Dealer' AND product_name LIKE '%$category%' order by sale_id desc";
                }else{
                  $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Dealer' AND product_name LIKE '%$category%' AND product_sale_date BETWEEN  '$start_date' AND '$end_date' order by sale_id desc";
                }
              }
                $info = $obj_admin->manage_all_info($sql);
                $serial  = 1;
                $total_sales = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){

                      $total_sales += $row['total_sale_price'];
                    }
              ?>
              <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Sale:
              <?php echo $obj_admin->formatMoney($total_sales, true); ?> BDT </caption>
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Selling Product</th>
                  <th>Customer Type</th>
                  <th>Product Qty</th>
                  <th>Selling Amount (BDT)</th>
                  <th>Time & Dates</th>
                  <th>Action</th>
                  
                </tr>
              </thead>
              <tbody id="table_body">

              <?php 
                if( empty($category) ){
                  if(empty($start_date) OR empty($end_date)){
                    
                    $sql = "SELECT * FROM tbl_sales_product WHERE customer_type = 'Dealer'  order by sale_id desc";
                }else{
                  
                  $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Dealer' AND product_sale_date BETWEEN  '$start_date' AND '$end_date' order by sale_id desc ";
                }
              }else if( !empty($category) ){
                if(empty($start_date) OR empty($end_date)){
                  $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Dealer' AND product_name LIKE '%$category%' order by sale_id desc";
                }else{
                  $sql = "SELECT * FROM tbl_sales_product  WHERE customer_type = 'Dealer' AND product_name LIKE '%$category%' AND product_sale_date BETWEEN  '$start_date' AND '$end_date' order by sale_id desc";
                }
              }

                
                $info = $obj_admin->manage_all_info($sql);
                $serial  = 1;
                $num_row = $info->rowCount();
                if($num_row==0){
                      echo '<tr><td colspan="6">No Data found</td></tr>';
                }
                $total_expense = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['product_name']; ?></td>
                  <td><?php echo $row['customer_type']; ?></td>
                  <td><?php echo $row['product_quantity']; ?></td>
                  <td><?php echo $obj_admin->formatMoney($row['total_sale_price'], true); ?></td>
                  <td><?php echo $row['sale_date']; ?></td>
                  <td><a title="Delete" href="?delete_sale=delete_sale&customer_type=<?php echo $row['customer_type']?>&sale_id=<?php echo $row['sale_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a></td>
                  
                </tr>

              <?php } ?>
              </tbody>
            </table>

<?php
}

?>


