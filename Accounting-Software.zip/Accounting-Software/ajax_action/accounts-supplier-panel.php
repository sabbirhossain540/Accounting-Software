
<?php

require '../authentication.php';

$category = $_POST['category_name'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

//echo $category . $start_date .$end_date;

?>
<table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Supplier Name</th>
                  <th>Supplier Contact</th>
                  <th>Supplier Email</th>
                  <th>Supplier Description</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="table_body">

              <?php 
                
                if( empty($start_date) OR empty($end_date) ){
                    $sql = "SELECT * FROM tbl_add_supplier WHERE supplier_name LIKE '%$category%' order by supplier_id desc ";
                  }else{
                    $sql = "SELECT * FROM tbl_add_supplier WHERE supplier_name LIKE '%$category%' AND add_date BETWEEN '$start_date' AND '$end_date' order by supplier_id desc ";
                  }
                $info = $obj_admin->manage_all_info($sql);
                $num_row = $info->rowCount();
                if($num_row==0){
                      echo '<tr><td colspan="6">No Data found</td></tr>';
                }
                $serial = 1;
                while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['supplier_name'];?></td>
                  <td><?php echo $row['supplier_contact'];?></td>
                  <td><?php echo $row['supplier_email'];?></td>
                  <td><?php echo $row['supplier_details'];?></td>
                  <td>
                  <a title="Update Customer" href="update-supplier.php?supplier_id=<?php echo $row['supplier_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>
                  
                  &nbsp;&nbsp;<a title="Delete" href="?delete_supplier=delete_supplier&supplier_id=<?php echo $row['supplier_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>

                  </td>
                </tr>

              <?php } ?>
              </tbody>
            </table>

