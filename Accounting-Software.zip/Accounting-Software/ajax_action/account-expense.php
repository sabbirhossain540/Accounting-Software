<?php

require '../authentication.php';

$category = $_POST['category_name'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

//echo $category . $start_date .$end_date;

?>
<div id="expense_test">test ok</div>
<table class="table table-codensed table-custom">
            <?php 
              if( empty($category)){
                  if(empty($start_date) OR empty($end_date)){
                    $sql = "SELECT * FROM tbl_expense_source order by expense_id desc";
                }else{
                  $sql = "SELECT * FROM tbl_expense_source WHERE expense_date BETWEEN  '$start_date' AND '$end_date' order by expense_id desc";
                }
              }else if( !empty($category)){
                if(empty($start_date) OR empty($end_date)){
                  $sql = "SELECT * FROM tbl_expense_source WHERE expense_source LIKE '%$category%' order by expense_id desc";
                }else{
                  $sql = "SELECT * FROM tbl_expense_source WHERE expense_source LIKE '%$category%' AND expense_date BETWEEN  '$start_date' AND '$end_date' order by expense_id desc";
                }
              }
                $info = $obj_admin->manage_all_info($sql);
                $num_row = $info->rowCount();
                
                $total_expense = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){

                      $total_expense += $row['expense_amount'];
                    }
              ?>
              <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Expense:
              <?php echo $obj_admin->formatMoney($total_expense, true); ?> BDT </caption>
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Expense Source</th>
                  <th>Total Ammount</th>
                  <th>Responsible Person</th>
                  <th>Person Designation</th>
                  <th>Person Contact</th>
                  <th>Time & Dates</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody id="table_body">

              <?php 
              if( empty($category)){
                  if(empty($start_date) OR empty($end_date)){
                    $sql = "SELECT * FROM tbl_expense_source order by expense_id desc";
                }else{
                  $sql = "SELECT * FROM tbl_expense_source WHERE expense_date BETWEEN  '$start_date' AND '$end_date' order by expense_id desc";
                }
              }else if( !empty($category)){
                if(empty($start_date) OR empty($end_date)){
                  $sql = "SELECT * FROM tbl_expense_source WHERE expense_source LIKE '%$category%' order by expense_id desc";
                }else{
                  $sql = "SELECT * FROM tbl_expense_source WHERE expense_source LIKE '%$category%' AND expense_date BETWEEN  '$start_date' AND '$end_date' order by expense_id desc";
                }
              }
                
                $info = $obj_admin->manage_all_info($sql);
                $serial  = 1;
                $num_row = $info->rowCount();
                if($num_row==0){
                      echo '<tr><td colspan="8">No Data found</td></tr>';
                }
                $total_expense = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php $serial; $serial++; ?></td>
                  <td><?php echo $row['expense_source']; ?></td>
                  <td><?php 
                  $total_expense += $row['expense_amount'];
                  echo $row['expense_amount']; ?></td>
                  <td><?php echo $row['responsible_person']; ?></td>
                  <td><?php echo $row['person_designation']; ?></td>
                  <td><?php echo $row['person_contact']; ?></td>
                  <td><?php echo $row['expense_date']; ?></td>
                  <td><a title="Delete" href="?delete_expense=delete_expense&expense_id=<?php echo $row['expense_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a></td>
                </tr>

              <?php } ?>

              <tr>
                  <td colspan="5">Total Expense</td>
                  <td colspan="3"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_expense, true);

                  echo $remain_amount;?></td>
              </tr>

              </tbody>
            </table>

