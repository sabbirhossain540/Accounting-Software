
<?php

require '../authentication.php';

$category = $_POST['category_name'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

//echo $category . $start_date .$end_date;

?>
<table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Customer Name</th>
                  <th>Customer Contact</th>
                  <th>Customer Email</th>
                  <th>Customer Other Details</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="table_body">

              <?php 
                $sql = "SELECT * FROM tbl_permanent_customer WHERE customer_name LIKE '%$category%' ";
                $info = $obj_admin->manage_all_info($sql);
                $num_row = $info->rowCount();
                if($num_row==0){
                      echo '<tr><td colspan="6">No Data found</td></tr>';
                }
                $serial = 1;
                while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['customer_name'];?></td>
                  <td><?php echo $row['customer_contact'];?></td>
                  <td><?php echo $row['customer_email'];?></td>
                  <td><?php echo $row['customer_description'];?></td>
                  <td>Edit Delete</td>
                </tr>

              <?php } ?>
              </tbody>
            </table>

