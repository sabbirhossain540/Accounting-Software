
<?php

require '../authentication.php';

$category = $_POST['category_name'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

//echo $category . $start_date .$end_date;

?>
<table class="table table-codensed table-custom">
              <?php 
                  $sql = "SELECT * FROM tbl_supplier_product";
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $total_amount = 0.00;
                  $total_paid = 0.00;
                  $due_remain = 0.00;
                  while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                    $total_amount += $row['due_amount'];
                    
                  }
            ?>
            <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Due :
              <?php echo $obj_admin->formatMoney($total_amount, true); ?> BDT  </caption>

              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Supplier Name</th>
                  <th>Supplier Contact</th>
                  <th>Supplier Product</th>
                  <th>Product Code</th>
                  <th>Quantity</th>
                  <th>Due</th>
                  <th>Incoming Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                <?php 
                  if( empty($category) ){
                    
                    if( empty($start_date) or empty($end_date) ){
                      $query = "SELECT * FROM tbl_supplier_product, tbl_add_supplier WHERE tbl_supplier_product.supplier_id = tbl_add_supplier.supplier_id order by product_id desc";
                    }else{
                      $query = "SELECT * FROM tbl_supplier_product, tbl_add_supplier WHERE tbl_supplier_product.supplier_id = tbl_add_supplier.supplier_id AND tbl_supplier_product.supply_date BETWEEN  '$start_date' AND '$end_date' order by product_id desc";
                    }
                  }else{
                    if( empty($start_date) or empty($end_date) ){
                      $query = "SELECT * FROM tbl_supplier_product, tbl_add_supplier WHERE tbl_supplier_product.supplier_id = tbl_add_supplier.supplier_id AND tbl_add_supplier.supplier_name LIKE '%$category%' order by product_id desc";
                    }else{
                      $query = "SELECT * FROM tbl_supplier_product, tbl_add_supplier WHERE tbl_supplier_product.supplier_id = tbl_add_supplier.supplier_id AND tbl_add_supplier.supplier_name LIKE '%$category%' AND AND tbl_supplier_product.supply_date BETWEEN  '$start_date' AND '$end_date' order by product_id desc";
                    }
                  }
                  
                  $info = $obj_admin->manage_all_info($query);
                  $serial  = 1;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="6">No Data found</td></tr>';
                  }
                  $total_expense = 0.00;
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                    $supplier_id = $row['supplier_id'];
                    $sql_sup = "SELECT * FROM tbl_add_supplier WHERE supplier_id = '$supplier_id' ";
                    $info_sup = $obj_admin->manage_all_info($sql_sup);
                    $row_sup = $info_sup->fetch(PDO::FETCH_ASSOC);
                    echo $row_sup['supplier_name'];

                  ?></td>
                  <td><?php echo $row_sup['supplier_contact']; ?></td>
                  <td><?php echo $row['product_name']; ?></td>
                  <td><?php echo $row['product_code']; ?></td>
                  <td><?php echo $row['product_quantity']; ?></td>
                  <td><?php echo $row['due_amount']; ?></td>
                  <td><?php echo $row['product_incoming_date']; ?></td>
                  <td>
                  <a title="Update Product" href="update-supplier-products.php?product_id=<?php echo $row['product_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>&nbsp;&nbsp;
                  <a title="View" href="product-details-supplier.php?product_id=<?php echo $row['product_id']; ?>"><span class="glyphicon glyphicon-folder-open"></span></a>
                 
                  &nbsp;&nbsp;<a title="Delete" href="?delete_supplier_trans=delete_supplier_trans&product_id=<?php echo $row['product_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>

                  
                  </td>
                </tr>
                <?php } ?>
                
              </tbody>
            </table>

