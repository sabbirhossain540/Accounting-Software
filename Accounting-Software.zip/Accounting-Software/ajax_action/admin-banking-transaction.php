<?php
require '../authentication.php';
$transaction_type = $_POST['transaction_type'];
$account_id = $_POST['account_id'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

if(isset($_GET['delete_trans'])){
  //delete transaction
  $taransaction_id = $_GET['transaction_id'];
  $transaction_type = $_GET['transaction_type'];
  $account_id = $_GET['account_id'];
  if($transaction_type=="Withdrawal"){  
    $obj_admin->delete_withdrawal_by_this_method($taransaction_id,$account_id);
  }else if($transaction_type=="Deposit"){
    $obj_admin->delete_deposit_by_this_method($taransaction_id,$account_id);
  } 
}

if($transaction_type == "Withdrawal"){

?>

<div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Account Name</th>
                  <th>Account No.</th>
                  <th>Bank</th>
                  <th>Withdraw Amount</th>
                  <th>Bank Contact</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>

              <?php 

              	if( empty($account_id)){
                  if(empty($start_date) OR empty($end_date)){
                    
                    $sql = "SELECT * FROM tbl_balance_withdraw order by withdraw_id desc";
                }else{
                  
                  $sql = "SELECT * FROM tbl_balance_withdraw  WHERE withdraw_date BETWEEN  '$start_date' AND '$end_date' order by withdraw_id desc ";
                }
              }else if( !empty($account_id)){
                if(empty($start_date) OR empty($end_date)){
                  $sql = "SELECT * FROM tbl_balance_withdraw  WHERE account_id = '$account_id' order by withdraw_id desc";
                }else{
                  $sql = "SELECT * FROM tbl_balance_withdraw  WHERE account_id = '$account_id' AND withdraw_date BETWEEN  '$start_date' AND '$end_date' order by withdraw_id desc";
                }
              }

                //$sql = "SELECT * FROM tbl_balance_withdraw";
                $info = $obj_admin->manage_all_info($sql);
                $total_withdraw = 0.00;
                $num_row = $info->rowCount();
                if($num_row==0){
                      echo '<tr><td colspan="6">No Data found</td></tr>';
                }
                $serial = 1;
                while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  $total_withdraw += $row['withdraw_amount']; 
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  $account_id = $row['account_id'];
                  $sql_acc = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
                  $info_acc = $obj_admin->manage_all_info($sql_acc);
                  $row_acc = $info_acc->fetch(PDO::FETCH_ASSOC);
                  echo $row_acc['account_name'];
                  ?></td>
                  <td><?php echo $row_acc['account_number'];?></td>
                  <td><?php echo $row_acc['bank_name'];?></td>
                  <td><?php echo $row['withdraw_amount']; ?></td>
                  <td><?php echo $row_acc['bank_contact'];?></td> 
                  <td>
                  <a title="View" href="admin-banking-trans-edit.php?transaction_id=<?php echo $row['withdraw_id']; ?>&transaction_type=Withdrawal&account_id=<?php echo $row_acc['account_id'];?>"><span class="glyphicon glyphicon-"></span></a>
                  <a title="Delete" href="?delete_trans=delete_trans&transaction_id=<?php echo $row['withdraw_id']; ?>&transaction_type=Withdrawal&account_id=<?php echo $row_acc['account_id'];?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>
                </tr>

                <?php } ?>
                

              </tbody>
            </table>
          </div>


<?php 
}else if($transaction_type == "Deposit"){
?>


<div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Account Name</th>
                  <th>Account No.</th>
                  <th>Bank</th>
                  <th>Deposit Amount</th>
                  <th>Bank Contact</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>

              <?php 
                $sql = "SELECT * FROM tbl_bank_deposit";
                if( empty($account_id)){
                  if(empty($start_date) OR empty($end_date)){
                    
                    $sql = "SELECT * FROM tbl_bank_deposit order by transaction_id desc";
                }else{
                  
                  $sql = "SELECT * FROM tbl_bank_deposit  WHERE transaction_date BETWEEN  '$start_date' AND '$end_date' order by transaction_id desc ";
                }
              }else if( !empty($account_id)){
                if(empty($start_date) OR empty($end_date)){
                  $sql = "SELECT * FROM tbl_bank_deposit  WHERE account_id = '$account_id' order by transaction_id desc";
                }else{
                  $sql = "SELECT * FROM tbl_bank_deposit  WHERE account_id = '$account_id' AND transaction_date BETWEEN  '$start_date' AND '$end_date' order by transaction_id desc";
                }
              }
                $info = $obj_admin->manage_all_info($sql);
                $total_deposit = 0.00;
                $serial = 1;
                while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  $total_deposit += $row['deposit_amount']; 
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  $account_id = $row['account_id'];
                  $sql_acc = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
                  $info_acc = $obj_admin->manage_all_info($sql_acc);
                  $row_acc = $info_acc->fetch(PDO::FETCH_ASSOC);
                  echo $row_acc['account_name'];
                  ?></td>
                  <td><?php echo $row_acc['account_number'];?></td>
                  <td><?php echo $row_acc['bank_name'];?></td>
                  <td><?php echo $row['deposit_amount']; ?></td>
                  <td><?php echo $row_acc['bank_contact'];?></td> 
                  <td>
                  <a title="View" href="admin-banking-trans-edit.php?transaction_id=<?php echo $row['transaction_id']; ?>&transaction_type=Deposit&account_id=<?php echo $row_acc['account_id'];?>"><span class="glyphicon glyphicon-"></span></a>
                  <a title="Delete" href="?delete_trans=delete_trans&transaction_id=<?php echo $row['transaction_id']; ?>&transaction_type=Deposit&account_id=<?php echo $row_acc['account_id'];?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>
                </tr>

                <?php } ?>
                

              </tbody>
            </table>
          </div>


<?php
}
?>