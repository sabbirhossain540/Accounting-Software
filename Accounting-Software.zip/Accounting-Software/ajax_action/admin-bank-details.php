<?php
require '../authentication.php';
$transaction_type = $_POST['transaction_type'];
$account_id = $_POST['account_id'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

$sql = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);

if($transaction_type == "Withdrawal"){
?>

	<table class="table table-codensed table-custom">
              <caption><span class="acc-det-cat">Account Name:</span> <?php echo $row['account_name']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Account No.:</span> <?php echo $row['account_number']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Bank:</span> <?php echo $row['bank_name']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Type:</span> Withdrawal</caption>
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Ammount</th>
                  <th>Purpose</th>
                  <th>Time & Dates</th>
                </tr>
              </thead>
              <tbody id="table_body">
                <?php
                $sql = "SELECT * FROM tbl_balance_withdraw WHERE account_id='$account_id' ";
                
                 if(empty($start_date) OR empty($end_date)){
                    
                    $sql = "SELECT * FROM tbl_balance_withdraw WHERE account_id='$account_id'";
                }else{
                  
                  $sql = "SELECT * FROM tbl_balance_withdraw  WHERE account_id='$account_id' AND withdraw_date BETWEEN  '$start_date' AND '$end_date' ";
                }
              
                $info = $obj_admin->manage_all_info($sql);
                $serial = 1;
                $num_row = $info->rowCount();
                if($num_row==0){
                      echo '<tr><td colspan="6">No Data found</td></tr>';
                }
                $total_withdraw = 0.00;
                while ( $row = $info->fetch(PDO::FETCH_ASSOC) ) {
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  $total_withdraw += $row['withdraw_amount'];
                  echo $obj_admin->formatMoney($row['withdraw_amount'], true); ?></td>
                  <td><?php echo $row['withdraw_purpose']; ?></td>
                  <td><?php echo $row['withdraw_date']; ?></td>
                </tr>

                <?php 
                }      
                ?>
                <tr>
                  <td colspan="2">Total Amount</td>
                  <td colspan="2"><?php echo $obj_admin->formatMoney($total_withdraw, true);  ?></td>
                </tr>
              </tbody>
            </table>
          

<?php 
}else if($transaction_type == "Deposit"){
?>

	<table class="table table-codensed table-custom">
              <caption><span class="acc-det-cat">Account Name:</span> <?php echo $row['account_name']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Account No.:</span> <?php echo $row['account_number']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Bank:</span> <?php echo $row['bank_name']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Type:</span> Deposit</caption>
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Ammount</th>
                  
                  <th>Time & Dates</th>
                </tr>
              </thead>
              <tbody id="table_body">
                <?php
                $sql = "SELECT * FROM tbl_bank_deposit WHERE account_id='$account_id' ";
                if(empty($start_date) OR empty($end_date)){
                    
                    $sql = "SELECT * FROM tbl_bank_deposit WHERE account_id='$account_id' ";
                }else{
                  
                  $sql = "SELECT * FROM tbl_bank_deposit  WHERE account_id='$account_id' AND transaction_date BETWEEN  '$start_date' AND '$end_date' ";
                }
                $info = $obj_admin->manage_all_info($sql);
                $serial = 1;
                $num_row = $info->rowCount();
                if($num_row==0){
                      echo '<tr><td colspan="6">No Data found</td></tr>';
                }
                $total_deposit = 0.00;
                while ( $row = $info->fetch(PDO::FETCH_ASSOC) ) {
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  $total_deposit += $row['deposit_amount'];
                  echo $obj_admin->formatMoney($row['deposit_amount'], true); ?></td>
                  
                  <td><?php echo $row['transaction_date']; ?></td>
                </tr>

                <?php 
                }
                
                ?>

                <tr>
                  <td colspan="2">Total Amount</td>
                  <td colspan="2"><?php echo $obj_admin->formatMoney($total_deposit, true);  ?></td>
                </tr>
              </tbody>
            </table>

<?php
}
?>