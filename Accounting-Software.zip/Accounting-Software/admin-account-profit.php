<?php
require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}
// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

$page_name="Admin";
include("include/header.php");
    
    $sql1 = "SELECT * FROM tbl_expense_source";

    if(isset($_POST['btn_take_date'])){
      $new_start_date = $_POST['start_date'];
      $new_end_date = $_POST['end_date'];
      $sql1 = "SELECT * FROM tbl_expense_source WHERE expense_date BETWEEN '$new_start_date' AND '$new_end_date' ";
    }
    
    $info1 = $obj_admin->manage_all_info($sql1);
    $total_expense = 0.00;
    while( $row = $info1->fetch(PDO::FETCH_ASSOC) ){
      $total_expense += $row['expense_amount'];
      //echo "string";
    }
  
    $sql1 = "SELECT * FROM tbl_sales_product";

    if(isset($_POST['btn_take_date'])){
      $bt_new_start_date = $_POST['start_date'];
      $new_end_date = $_POST['end_date'];
      $sql1 = "SELECT * FROM tbl_sales_product WHERE product_sale_date BETWEEN '$new_start_date' AND '$new_end_date' ";
    }
    $info1 = $obj_admin->manage_all_info($sql1);
    $total_sales = 0.00;
    while( $row = $info1->fetch(PDO::FETCH_ASSOC) ){
      $total_sales += $row['total_sale_price'];
      //echo "string";
    }

    $total_profit = $total_sales - $total_expense;
    if($total_profit < 0){
      $total_profit = 0.00;
    }
    $total_profit = $obj_admin->formatMoney($total_profit, true);    

?>

<!--modal for customer add-->


    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="admin-account-panel.php">Back Home</a></li>
            <li class="active"><a href="admin-account-profit.php">Admin Account Profit</a></li>
            
            
          </ul>
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <form class="form-inline"  name="data_search" id="data_search" action="" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <button type="submit" class="btn btn-default" name="btn_take_date">Submit</button>
              </form> 
            </div>
          </div>
          <br><br>
          <div class="row">
            <div class="col-md-6 col-md-offset-3">
              <div class="panel panel-default admin-custom">
                <div class="panel-heading tprofit">
                  <h3 class="text-center"><?php 
                  if(isset($_POST['btn_take_date'])){
                    ?>

                    Date : <?php echo $new_start_date . " -- ".$new_end_date ?>
                    <?php

                  }else{
                    ?>
                      Select Date to See <span>Profit</span></h3>
                    <?php 
                  }
                  ?>
                </div>
                <div class="panel-body">
                  <h1 class="text-center">Profit: <?php echo $total_profit." BDT"; ?></h1>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

?>