<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

$customer_id = $_GET['customer_id'];
if(isset($_POST['update_permanent_customer'])){
    $obj_admin->update_permanent_customer($_POST,$customer_id);
}

$page_name="Dealers";
include("include/header.php");

$sql = "SELECT * FROM tbl_permanent_customer WHERE customer_id='$customer_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);

?>

<!--modal for customer add-->

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li class="active"><a href="accounts-customer-panel.php">Dealer Panel</a></li>
          </ul>
          <div class="gap"></div>
          
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="well">
                <h3 class="text-center bg-primary" style="padding: 7px;">Edit Customer </h3><br>


                      <div class="row">
                        <div class="col-md-12">
                          <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                            <div class="form-group">
                              <label class="control-label col-sm-5">Customer Name</label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['customer_name']; ?>" placeholder="Enter Customer Name" name="customer_name" list="expense" class="form-control input-custom" id="default" required>
                              </div>
                            </div>
                             
                            <div class="form-group">
                              <label class="control-label col-sm-5">Customer E-mail</label>
                              <div class="col-sm-7">
                                <input type="email" value="<?php echo $row['customer_email']; ?>" placeholder="Enter customer E-mail" name="customer_email" class="form-control input-custom">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-5">Customer Contact</label>
                              <div class="col-sm-7">
                                <input type="number" value="<?php echo $row['customer_contact']; ?>" placeholder="Enter Customer Contact" name="customer_contact" class="form-control input-custom" required>
                              </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-sm-5">Customer Description</label>
                              <div class="col-sm-7">
                                <input type="text" value="<?php echo $row['customer_description']; ?>" placeholder="Enter customer Description" name="customer_description" class="form-control input-custom" >
                              </div>
                            </div>
                            
                            <div class="form-group">
                            </div>
                            <div class="form-group">
                              <div class="col-sm-offset-3 col-sm-3">
                                
                              </div>
                              <div class="col-sm-3">
                                <button type="submit" name="update_permanent_customer" class="btn btn-success-custom">Update Now</button>
                              </div>
                            </div>
                          </form> 
                        </div>
                      </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </div>


<?php

if(isset($_SESSION['add_permanent_customer'])){
  echo '<script>alert("New Customer Added Successfully");</script>';
  unset($_SESSION['add_permanent_customer']);
}

include("include/footer.php");

?>