<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

$account_id = $_GET['account_id'];
$sql = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);

$page_name="Banking";
include("include/header.php");

if(isset($_POST['update_account_info'])){
    $obj_admin->update_bank_account_info($_POST,$account_id);
}

?>

<div class="row">
  <div class="col-md-12">
    <div class="well well-custom">

      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="well">
            <div class="gap"></div>
            <div class="row">
              <div class="col-md-6 col-md-offset-3">
                <div class="btn-group btn-group-justified">
                  
                  <div class="btn-group">
                    <a href="admin-banking.php" class="btn btn-success">Banking Home</a>
                  </div>
                  <div class="btn-group">
                    <a href="admin-banking-accounts.php" class="btn btn-success">Manage Account</a>
                  </div>
                  <div class="btn-group">
                    <a href="admin-banking-transactions.php" class="btn btn-success">Manage Transaction</a>
                  </div>
                </div>
              </div>
            </div>
            <h1 class="text-center">Account Information Update</h1>
            <h3 class="text-center bg-primary" style="padding: 7px;">Account Name: <?php echo $row['account_name'];
            ?><br>Acc. No: <?php echo $row['account_number']; ?></h3><br>
            <div class="row">
              <div class="col-md-12">
                <form role="form" action="" method="post" autocomplete="off">
                  <div class="form-horizontal">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Account Name</label>
                      <div class="col-sm-7">
                        <input type="text" value="<?php echo $row['account_name']; ?>" placeholder="Enter Account Name" name="account_name" list="expense" class="form-control input-custom" id="default" value="Mustafizur Rahman" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-4">Account No</label>
                      <div class="col-sm-7">
                        <input type="text" value="<?php echo $row['account_number']; ?>" placeholder="Enter Account No" name="account_number" class="form-control input-custom" value="110.130.11098" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-4">Available Balance</label>
                      <div class="col-sm-7">
                        <input type="number" value="<?php echo $row['available_balance']; ?>" placeholder="Enter Available Balance" name="available_balance" class="form-control input-custom" value="200000" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-4">Bank Name</label>
                      <div class="col-sm-7">
                        <input type="text" value="<?php echo $row['bank_name']; ?>" placeholder="Enter Bank Name (Branch)" name="bank_name" class="form-control input-custom" value="BRAC (Branch)" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-4">Bank Contact</label>
                      <div class="col-sm-7">
                        <input type="text" value="<?php echo $row['bank_contact']; ?>" placeholder="Enter Bank Contact" name="bank_contact" class="form-control input-custom" value="+880 2143213" required>
                      </div>
                    </div>
                    <div class="form-group">
                    </div>
                    <div class="form-group">
                      <div class="col-sm-offset-4 col-sm-3">
                        <button type="submit" name="update_account_info" class="btn btn-success-custom">Update</button>

                      </div>
                    </div>
                  </div>
                </form> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php

include("include/footer.php");

?>