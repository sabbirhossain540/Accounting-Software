<?php 
require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

$page_name="Sale Now";
include("include/header.php");
// receive get data

$product_code = $_GET['product_code'];
$product_quantity = $_GET['product_quantity'];
$product_discount = $_GET['product_discount'];
$customer_id = $_GET['customer_id'];
$due_amount = $_GET['due_amount'];

// find customer details....
$sql = "SELECT * FROM tbl_permanent_customer WHERE customer_id ='$customer_id' ";
$info = $obj_admin->manage_all_info($sql);
$customer_details = $info->fetch(PDO::FETCH_ASSOC);


?>

<?php

// showing data into money format
function formatMoney($number, $fractional=false) {
  if ($fractional) {
    $number = sprintf('%.2f', $number);
  }
  while (true) {
    $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
    if ($replaced != $number) {
      $number = $replaced;
    } else {
      break;
    }
  }
  return $number;
}

?>

<script language="javascript">
/* for printing purphose*/
function Clickheretoprint()
{ 
  
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=800, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('</head><body onLoad="self.print()" style="width: 800px; font-size: 13px; font-family: arial;">');          
   docprint.document.write(content_vlue); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>

<div class="span10" style="background-color: white;">
  <a href="sale-now.php"><button class="btn btn-default"><i class="icon-arrow-left"></i> Back to Sales</button></a>

<div class="content" id="content">
<div style="margin: 0 auto; padding: 20px; width: 900px; font-weight: normal;">
  <div style="width: 100%; height: 190px;" >
  <div style="width: 900px; float: left;">
  <center><div style="font:bold 25px 'Aleo';">Sales Receipt</div>
  Wave-Brand IT Services  <br>
  7/D, Shahajadpur, Gulshan, Dhaka <br>  <br>
  </center>
  <div>
  
  </div>
  </div>
  <div style="width: 300px; float: left; height: 70px;">
  <table cellpadding="3" cellspacing="0" style="font-family: arial; font-size: 12px;text-align:left;width : 100%;">
  
    <tr>
      <td>Customer Name :</td>
      <td><?php echo $customer_details['customer_name']; ?></td>
    </tr>
    <tr>
      <td>Customer Contact :</td>
      <td><?php echo $customer_details['customer_contact']; ?></td>
    </tr>
    <tr>
      <td>Date :</td>
      <td><?php echo date('d-m-Y'); ?></td>
    </tr>
  </table>
  
  </div>
  <div class="clearfix"></div>
  </div>
  <div style="width: 100%; margin-top:-70px;">
  <table border="1" cellpadding="4" cellspacing="0" style="font-family: arial; font-size: 12px; text-align:left;" width="100%">
    <thead>
      <tr>
        <th> Product Name </th>
        <th> Product Code </th>
        <th> Product Quantity </th>
        <th> Product Price </th>
      </tr>
    </thead>
    <tbody>

      <?php

      $sql = "SELECT * FROM tbl_product WHERE product_code='$product_code' ";
      $info = $obj_admin->manage_all_info($sql);
      $product_details = $info->fetch(PDO::FETCH_ASSOC);

      ?>

      <tr>
        <td><?php echo $product_details['product_name']; ?></td>
        <td><?php echo $product_details['product_code']; ?></td>
        <td><?php echo $product_quantity; ?></td>
        <td><?php echo $product_details['unit_sale_price']; ?></td>
      </tr>

      <tr>
        <td colspan="3"style=" text-align:right;"><strong style="font-size: 12px; color: #222222;">Sub Total: &nbsp;</strong></td>
        <td colspan="2"><strong style="font-size: 12px; color: #222222;">
        <?php
        $sub_total = $product_details['unit_sale_price'] * $product_quantity;
        //echo $sub_total;
        echo formatMoney($sub_total, true);
        ?>
        </strong></td>
      </tr>
      <tr>
        <td colspan="3"style=" text-align:right;"><strong style="font-size: 12px; color: #222222;">Discount: &nbsp;</strong></td>
        <td colspan="2"><strong style="font-size: 12px; color: #222222;">
        <?php

        echo formatMoney($product_discount, true);
        ?>
        </strong></td>
      </tr>

      <tr>
        <td colspan="3"style=" text-align:right;"><strong style="font-size: 12px; color: #222222;">Grand Total: &nbsp;</strong></td>
        <td colspan="2"><strong style="font-size: 12px; color: #222222;">
        <?php
        $grand_total = $sub_total - $product_discount;
        echo formatMoney($grand_total, true);
        ?>
        </strong></td>
      </tr>

      <tr>
        <td colspan="3"style=" text-align:right;"><strong style="font-size: 12px; color: #222222;">Due Remain: &nbsp;</strong></td>
        <td colspan="2"><strong style="font-size: 12px; color: #222222;">
        <?php
        
        echo formatMoney($due_amount, true);
        ?>
        </strong></td>
      </tr>

      <tr>
        <td colspan="3"style=" text-align:right;"><strong style="font-size: 12px; color: #222222;">Total Paid: &nbsp;</strong></td>
        <td colspan="2"><strong style="font-size: 12px; color: #222222;">
        <?php
        $total_paid = $grand_total - $due_amount;
        echo formatMoney($total_paid, true);
        ?>
        </strong></td>
      </tr>



    </tbody>
  </table>
  
  </div>
  </div>
  </div>
  </div>
<div class="pull-right" style="margin-right:100px; background-color: white;">
    <a href="javascript:Clickheretoprint()" style="font-size:20px;"><button class="btn btn-success btn-large"><i class="icon-print"></i> Print</button></a>
    </div>


<?php

include("include/footer.php");

?>


