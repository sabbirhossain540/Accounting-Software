<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

$page_name="Products";
include("include/header.php");

?>

<!--   ===   add stock modal ===== -->
  <!-- Modal -->
  <div class="modal fade in" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title text-center">Add Stock</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
            <div class="form-group">
              <label class="control-label col-sm-3">Quantity</label>
              <div class="col-sm-7">
                <input type="number" name="product_quantity" value="1" min="1" class="form-control input-custom" required>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <div class="col-sm-6">
            <button type="submit" name="add_new_product" class="btn btn-success-custom">Add Stock</button>
          </div>
          <div class="col-sm-3">
            <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  </div>
<!--   ===   //add stock modal ===== -->

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="product-available.php">Available</a></li>
            <li class="active"><a href="">Low Stock</a></li>
            <li><a href="product-all.php">All</a></li>
            <li class=""><a href="product-category.php">Manage Category</a></li>
          </ul>
          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Product Name</th>
                  <th>Product Code</th>
                  <th>Unit Sale Price</th>
                  <th>Quantity</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              <?php 
                $sql = "SELECT * FROM tbl_product WHERE product_total_quantity<=5";
                $info = $obj_admin->manage_all_info($sql);
                $serial  = 1;
                $num_row = $info->rowCount();
                if($num_row==0){
                      echo '<tr><td colspan="6">No Data found</td></tr>';
                }
                $total_expense = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php echo $serial; ?></td>
                  <td><?php echo $row['product_name']; ?></td>
                  <td><?php echo $row['product_code']; ?></td>
                  <td><?php echo $row['unit_sale_price']; ?></td>
                  <td>

                  <?php
                    $total_quantity = $row['product_total_quantity'];
                    if($total_quantity==0){
                      echo "Out of Stock";
                    }else{
                      echo $row['product_total_quantity'];
                    }
                     ?></td>
                    
                  <td><a title="Add Stock" href="add-stock.php?product_id=<?php echo $row['product_id']; ?>" ><span class="glyphicon glyphicon-plus"></span></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="product-details.php?product_id=<?php echo $row['product_id']; ?>" title="Details"><span class="glyphicon glyphicon-folder-open"></span></a></td>
                </tr>
                <?php } ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

if(isset($_SESSION['quantity_added'])){
  echo '<script>alert("Product Stock Updated successfully");</script>';
  unset($_SESSION['quantity_added']);
}

?>