<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}
// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

if(isset($_GET['delete_expense'])){
  $action_id = $_GET['expense_id']; 
  $sql = "DELETE FROM tbl_expense_source WHERE expense_id = :id";
  $sent_po = "accounts-expense.php";
  $obj_admin->delete_data_by_this_method($sql, $action_id, $sent_po);
}

if(isset($_POST['btn_add_expense'])){
    $obj_admin->add_expense_data($_POST);
}

$page_name="Accounts";
include("include/header.php");

?>

<script type="text/javascript">
   function changeFunc() {

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/account-expense.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){

           //$('#expense_test').fadeOut('slow', function(){
           // $('#expense_test').fadeIn('slow').html(response);
           //});
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }
  </script>



<!--modal for customer add-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title text-center">Add Expense</h2>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                <div class="form-group">
                  <label class="control-label col-sm-5">Expense Name</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Expense Sorce" name="expense_source" list="expense" class="form-control input-custom" id="default" required>
                  <datalist id="expense">
                  <?php 
                    $sql = "SELECT * FROM tbl_expense_source";
                    $info = $obj_admin->manage_all_info($sql);
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  ?>

                    <option value="<?php echo $row['expense_source']; ?>">
                  <?php 
                    }
                  ?>
                    
                  </datalist>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Ammount</label>
                  <div class="col-sm-7">
                    <input type="number" placeholder="Enter Expense Ammount" name="expense_amount" class="form-control input-custom" min="0" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Responsible Person</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Responsible Person" name="responsible_person" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Person Designation</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Person Designation" name="person_designation" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Person Contact</label>
                  <div class="col-sm-7">
                    <input type="text" placeholder="Enter Person Contact" name="person_contact" class="form-control input-custom" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-sm-5">Time & Dates</label>
                  <div class="col-sm-7">
                    <div id="datepicker3" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control input-custom" type="text" name="expense_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                    
                  </div>
                </div>
                <div class="form-group">
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-3 col-sm-3">
                    <button type="submit" name="btn_add_expense" class="btn btn-success-custom">Add Expense</button>
                  </div>
                  <div class="col-sm-3">
                    <button type="submit" class="btn btn-danger-custom" data-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </form> 
            </div>
          </div>


        </div>
      </div>
    </div>
  </div>


<div class='multi-action'>
  <button class="action-button" data-toggle="modal" data-target="#myModal"><span class='glyphicon glyphicon-plus plus-rotate'></span></button>
</div>

<!--modal for customer add-->

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li class="active"><a href="accounts-expense.php">Expense</a></li>
            <li><a href="accounts-due.php">Transaction</a></li>
            <li><a href="accounts-sales.php">Sales</a></li>
          </ul>
          <div class="gap"></div>

          <div id="expense_test"></div>

          <div class="row">
            <div class="col-md-12">
              <form class="form-inline" id="data_search" action="" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="default">Expense Name</label>
                  <input type="text" name="category_name" onkeypress="changeFunc();" class="form-control" placeholder="e.g. Product Name" list="languages" id="default">
                  <datalist id="languages">

                    <?php 
                    $sql = "SELECT * FROM tbl_expense_source";
                    $info = $obj_admin->manage_all_info($sql);
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  ?>

                    <option value="<?php echo $row['expense_source']; ?>">
                  <?php 
                    }
                  ?>
                    
                  </datalist>
                </div>
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                
              </form> 
            </div>
          </div>

          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
            <?php 
              $sql = "SELECT * FROM tbl_expense_source order by expense_id desc";
                $info = $obj_admin->manage_all_info($sql);
                
                $total_expense = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                      $total_expense += $row['expense_amount'];
                    }
              ?>
              <caption style="text-align: center; padding: 7px; margin-bottom: 10px;" class="bg-primary">Total Expense:
              <?php echo $obj_admin->formatMoney($total_expense, true); ?> BDT </caption>
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>Expense Source</th>
                  <th>Responsible Person</th>
                  <th>Person Designation</th>
                  <th>Person Contact</th>
                  <th>Expense Ammount</th>
                  <th>Time & Dates</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>

                <?php 
                $sql = "SELECT * FROM tbl_expense_source order by expense_id desc";
                $info = $obj_admin->manage_all_info($sql);
                $serial  = 1;
                $num_row = $info->rowCount();
                if($num_row==0){
                  echo '<tr><td colspan="8">No Data found</td></tr>';
                }
                $total_expense = 0.00;
                    while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['expense_source']; ?></td>
                  
                  <td><?php echo $row['responsible_person']; ?></td>
                  <td><?php echo $row['person_designation']; ?></td>
                  <td><?php echo $row['person_contact']; ?></td>
                  <td><?php 
                  $total_expense += $row['expense_amount'];
                  echo $obj_admin->formatMoney($row['expense_amount'], true); ?></td>
                  <td><?php echo $row['expense_date']; ?></td>
                  <td>
                    <a title="Delete" href="?delete_expense=delete_expense&expense_id=<?php echo $row['expense_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>
                  </td>
                </tr>

                <?php } ?>

                <tr>
                  <td colspan="5">Total Expense</td>
                  <td colspan="3"><?php 
                   $remain_amount = $obj_admin->formatMoney($total_expense, true);

                  echo $remain_amount;?> BDT</td>
                </tr>
                
              </tbody>
            </table>
          </div>
          
        </div>
      </div>
    </div>


<?php

include("include/footer.php");
if(isset($_SESSION['add_expense'])){
  echo '<script>alert("Expense Added Successfully");</script>';
  unset($_SESSION['add_expense']);
}
?>