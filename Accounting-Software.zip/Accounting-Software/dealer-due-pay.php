<?php
require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

$page_name="Accounts";
include("include/header.php");

$due_id = $_GET['due_id'];

$sql = "SELECT * FROM tbl_customer_due WHERE due_id='$due_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['btn_due_payment'])){
  $obj_admin->dealer_due_amount_paid($_POST,$due_id);
}

?>

    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <ul class="nav nav-tabs nav-justified nav-tabs-custom">
            <li><a href="accounts-sales.php">Sales</a></li>
            <li><a href="accounts-expense.php">Expense</a></li>
            <li><a href="accounts-income.php">Income</a></li>
            <li class="active"><a href="accounts-due.php">Due</a></li>
            <li><a href="accounts-customer-panel.php">Customer Panel</a></li>
          </ul>
          <div class="gap"></div>

              <div class="row">
            <div class="col-md-10 col-md-offset-1">
              <div class="well">
                <h3 class="text-center bg-primary" style="padding: 10px;" >Pay Due<br> (<?php 

                $customer_id = $row['customer_id']; 
                $cus_sql = "SELECT * FROM tbl_permanent_customer WHERE customer_id = '$customer_id' ";
                $info_cus = $obj_admin->manage_all_info($cus_sql);
                $row_cus = $info_cus->fetch(PDO::FETCH_ASSOC);

                echo $row_cus['customer_name'];

                ?>  <?php echo ", Due Remain: ".$row['due_remain']; ?>)</h3><br>


                      <div class="row">
                        <div class="col-md-8">
                          <form class="form-horizontal" role="form" action="" method="post" autocomplete="off">
                            <div class="form-group">
                              <label class="control-label col-sm-4">Paying Amount</label>
                              <div class="col-sm-8">
                                <input type="number" placeholder="0.00" name="paying_amount" id="admin_old_password" list="expense" class="form-control input-custom" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-4">Next Payment Date</label>
                              <div class="col-sm-8">
                                <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                                    <input class="form-control input-custom" type="text" name="next_payment_date" placeholder="Next Payment Date" required>
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-group">
                            </div>
                            <div class="form-group">
                              <div class="col-sm-offset-4 col-sm-3">
                                <button type="submit" name="btn_due_payment" class="btn btn-success-custom">Pay Now</button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

              </div>
            </div>
          </div>

              </div>
            </div>
          </div>

          
        </div>
      </div>
    </div>


<?php

include("include/footer.php");


?>

