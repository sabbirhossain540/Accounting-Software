<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}


if(isset($_GET['delete_trans'])){
  //delete transaction
  $taransaction_id = $_GET['transaction_id'];
  $transaction_type = $_GET['transaction_type'];
  $account_id = $_GET['account_id'];
  if($transaction_type=="Withdrawal"){  
    $obj_admin->delete_withdrawal_by_this_method($taransaction_id,$account_id);
  }else if($transaction_type=="Deposit"){
    $obj_admin->delete_deposit_by_this_method($taransaction_id,$account_id);
  } 
}


if(isset($_POST['add_new_product'])){
    $obj_admin->add_product_or_services_data($_POST);
}

if(isset($_POST['add_new_category'])){
    $obj_admin->add_product_category($_POST);
}

$page_name="Banking";
include("include/header.php");

?>

<script type="text/javascript">

   function changeFunc() {
     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/admin-banking-transaction.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>


    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">

          <div class="gap"></div>
          <div class="row">
            <div class="col-md-6 col-md-offset-3">
              <div class="btn-group btn-menu-css">
                
                <div class="btn-group">
                  <a href="admin-banking.php" class="btn btn-success btn-menu">Banking Home</a>
                </div>
                <div class="btn-group">
                  <a href="admin-banking-accounts.php" class="btn btn-success btn-menu">Manage Account</a>
                </div>
                <div class="btn-group">
                  <a href="admin-banking-transactions.php" class="btn btn-success btn-menu active">Manage Transaction</a>
                </div>
              </div>
            </div>
          </div>

          <h1 class="text-center">All Transactions</h1>
          <div class="gap"></div>
          <form class="form-inline" action="" name="data_search" id="data_search" method="POST" autocomplete="off">
            <div class="form-group">
              <label for="default">Account Name</label>
              <select class="form-control banking-acc" name="account_id" onchange="changeFunc();">
                        <option value="">Select</option>
                        <?php 
                          $sql = "SELECT * FROM tbl_bank_account";
                          $info = $obj_admin->manage_all_info($sql);
                          while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                            
                        ?>
                        <option value="<?php echo $row['account_id'];?>"><?php echo $row['account_name']. " (".$row['account_number']. ")" ; ?></option>
                        <?php } ?>
                        
                      </select>
            </div>
            <div class="form-group">
              <label for="default">Transaction Type</label>
              <select class="form-control" name="transaction_type" onchange="changeFunc();"> 
                <option value="Withdrawal">Withdrawal</option>
                <option value="Deposit">Deposit</option>
              </select>
            </div>
            <div class="form-group">
              <label for="date_from">From:</label>
              <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                    <input class="form-control banking-date" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
              </div>
            </div>
            <div class="form-group">
              <label for="date_to">To:</label>
              <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                    <input class="form-control banking-date" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
              </div>
            </div>
          </form>


          <div class="gap"></div>
          <div class="table-responsive">
            <table class="table table-codensed table-custom">
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Account Name</th>
                  <th>Account No.</th>
                  <th>Bank</th>
                  <th>Withdraw Amount</th>
                  <th>Bank Contact</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>

              <?php 
                $sql = "SELECT * FROM tbl_balance_withdraw";
                $info = $obj_admin->manage_all_info($sql);
                $total_withdraw = 0.00;
                $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="9">No Data found</td></tr>';
                  }
                $serial = 1;
                while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
                  $total_withdraw += $row['withdraw_amount']; 
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  $account_id = $row['account_id'];
                  $sql_acc = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
                  $info_acc = $obj_admin->manage_all_info($sql_acc);
                  $row_acc = $info_acc->fetch(PDO::FETCH_ASSOC);
                  echo $row_acc['account_name'];
                  ?></td>
                  <td><?php echo $row_acc['account_number'];?></td>
                  <td><?php echo $row_acc['bank_name'];?></td>
                  <td><?php echo $row['withdraw_amount']; ?></td>
                  <td><?php echo $row_acc['bank_contact'];?></td> 
                  <td>
                  <a title="Update" href="admin-banking-trans-edit.php?transaction_id=<?php echo $row['withdraw_id']; ?>&transaction_type=Withdrawal&account_id=<?php echo $row_acc['account_id'];?>"><span class="glyphicon glyphicon-"></span></a>
                  <a title="Delete" href="?delete_trans=delete_trans&transaction_id=<?php echo $row['withdraw_id']; ?>&transaction_type=Withdrawal&account_id=<?php echo $row_acc['account_id'];?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"></span></a>
                </tr>

                <?php } ?>
                

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

if(isset($_SESSION['balance_withdraw'])){
  echo '<script>alert("Balance Withdraw Added successfully");</script>';
  unset($_SESSION['balance_withdraw']);
}

if(isset($_SESSION['add_deposit'])){
  echo '<script>alert("Deposit Added successfully");</script>';
  unset($_SESSION['add_deposit']);
}

?>