<?php

require 'authentication.php'; // admin authentication check 

// auth check
$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['admin_name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

// check admin or sales man
$user_role = $_SESSION['user_role'];
if ($user_role != 1) {
  header('Location: sale-now.php');
}

$page_name="Banking";
include("include/header.php");
$account_id = $_GET['account_id'];

$sql = "SELECT * FROM tbl_bank_account WHERE account_id = '$account_id' ";
$info = $obj_admin->manage_all_info($sql);
$row = $info->fetch(PDO::FETCH_ASSOC);

?>

<script type="text/javascript">

   function changeFunc() {

     //event.preventDefault();

     var mydata = $('#data_search').serializeArray();
     jQuery.ajax({
        type: "POST",
        url: "ajax_action/admin-bank-details.php",
        data: mydata,
        dataType: 'html',
        success: function(response) {
      
          $('table').fadeOut('slow', function(){
           
      //$('#mydiv').fadeIn('slow').html(response);
          $('table').fadeIn('slow').html(response);
    });
        }
        
    });

    }

  </script>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
      <div class="btn-group btn-group-justified">
        
        <div class="btn-group">
          <a href="admin-banking.php" class="btn btn-success">Banking Home</a>
        </div>
        <div class="btn-group">
          <a href="admin-banking-accounts.php" class="btn btn-success">Manage Account</a>
        </div>
        <div class="btn-group">
          <a href="admin-banking-transactions.php" class="btn btn-success">Manage Transaction</a>
        </div>
      </div>
    </div>
  </div>
  
    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <div class="row">
            <div class="col-md-12">
              <form class="form-inline banking-details-form" action="" name="data_search" id="data_search" method="POST" autocomplete="off">
                <div class="form-group">
                  <label for="default">Transaction Type</label>
                  <select class="form-control" name="transaction_type" onchange="changeFunc();">
                    <option value="Withdrawal">Withdrawal</option>
                    <option value="Deposit">Deposit</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="date_from">From:</label>
                  <div id="datepicker" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="start_date" type="text" name="start_date" placeholder="Enter Start Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                        <input type="hidden" name="account_id" id="account_id" value="<?php echo $account_id; ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="date_to">To:</label>
                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">
                        <input class="form-control" id="end_date" type="text" name="end_date" placeholder="Enter End Date" required>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
                
              </form> 
            </div>
          </div>
          <div class="gap"></div>
          <div class="table-responsive">

            <table class="table table-codensed table-custom">
              <caption><span class="acc-det-cat">Account Name:</span> <?php echo $row['account_name']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Account No.:</span> <?php echo $row['account_number']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Bank:</span> <?php echo $row['bank_name']; ?> &nbsp;&nbsp;<span class="acc-det-cat">Type:</span> Withdrawal</caption>
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Ammount</th>
                  <th>Purpose</th>
                  <th>Time & Dates</th>
                </tr>
              </thead>
              <tbody id="table_body">
                <?php
                $sql = "SELECT * FROM tbl_balance_withdraw WHERE account_id='$account_id' ";
                $info = $obj_admin->manage_all_info($sql);
                $serial = 1;
                $total_withdraw = 0.00;
                while ( $row = $info->fetch(PDO::FETCH_ASSOC) ) {
                ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php 
                  $total_withdraw += $row['withdraw_amount'];
                  echo $obj_admin->formatMoney($row['withdraw_amount'], true); ?></td>
                  <td><?php echo $row['withdraw_purpose']; ?></td>
                  <td><?php echo $row['withdraw_date']; ?></td>
                </tr>

                <?php 
                }
                
                ?>

                <tr>
                  <td colspan="2">Total Amount</td>
                  <td colspan="2"><?php echo $obj_admin->formatMoney($total_withdraw, true);  ?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php

include("include/footer.php");

?>